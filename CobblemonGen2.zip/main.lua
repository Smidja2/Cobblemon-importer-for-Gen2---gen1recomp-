local mod = ...
local function liveGame()
  local g=mod and mod.game
  return type(g)=="table" and g or nil
end
local Game=setmetatable({}, {
  __index=function(_,k)
    local g=liveGame()
    if not g then return nil end
    if k=="overworld" then return g.overworld or g.world end
    return g[k]
  end,
  __newindex=function(_,k,v)
    local g=liveGame(); if g then g[k]=v end
  end
})
local V={mod=mod,path=mod.path}
local modules={}
local function chunkFor(rel)
  local source=mod:read(rel)
  if not source then error("COBBLEMON_MAIN: missing "..rel,0) end
  local chunk,err=load(source,"@"..mod.path.."/"..rel)
  if not chunk then error("COBBLEMON_MAIN compile error in "..rel..": "..tostring(err),0) end
  return chunk
end
function V.require(name)
  if modules[name]~=nil then return modules[name] end
  local value=chunkFor("lib/"..name..".lua")(V)
  modules[name]=value
  return value
end
V.log = mod.log

local Pack=V.require("CobblePack")
local Rig=V.require("CobbleRig")
local Mat4=V.require("Mat4")
local actors={}

-- Unified Cobblemon option: renderer-provided model shadows.
local SHADOW_KEY="cobblemon_shadow"
local OUTLINE_KEY="cobblemon_toon_outline"
local BATTLE_SCENE_KEY="cobblemon_battle_scene"
local SMOOTH_KEY="cobblemon_model_smoothing"
local function storedOption(key,default)
  local loader=Game and Game.mods
  local stored=loader and loader.modOptions and loader.modOptions[mod.id]
  if stored and stored[key]~=nil then return stored[key] end

  local opts=Game and Game.save and Game.save.options
  stored=opts and opts.modOptions and opts.modOptions[mod.id]
  if stored and stored[key]~=nil then return stored[key] end

  return default
end

local function shadowEnabled()
  local v=storedOption(SHADOW_KEY,true)
  return v~=false and v~=0 and v~="OFF" and v~="NO"
end

local function outlineEnabled()
  local v=storedOption(OUTLINE_KEY,false)
  return v~=false and v~=0 and v~="OFF" and v~="NO"
end
local function battleSceneEnabled()
  local v=storedOption(BATTLE_SCENE_KEY,true)
  return v~=false and v~=0 and v~="OFF" and v~="NO"
end
local function modelSmoothingEnabled()
  local v=storedOption(SMOOTH_KEY,false)
  return v==true or v==1 or v=="ON" or v=="YES" or v=="SMOOTH"
end
local function setShadow(game,value)
  local opts=game and game.save and game.save.options
  if opts then
    opts.modOptions=opts.modOptions or {}; opts.modOptions[mod.id]=opts.modOptions[mod.id] or {}
    opts.modOptions[mod.id][SHADOW_KEY]=value
  end
  local loader=game and game.mods
  if loader then
    loader.modOptions=loader.modOptions or {}; loader.modOptions[mod.id]=loader.modOptions[mod.id] or {}
    loader.modOptions[mod.id][SHADOW_KEY]=value
  end
  if game and game.writeOptions then pcall(game.writeOptions,game) end
end

local nextId=1
local companionHandle=nil
local rendererMod=nil
local rendererId=nil
local Voxel3D=nil

-- Lightweight companion adapter for renderers that expose Voxel3D but do not
-- expose the native voxel_companion service (PotatoVoxel, Ascendant, Gen2).
local localSpecs={}
local localLastWorld=nil
local localCompanion=nil

local function liveGame()
  local ok,g=pcall(function() return mod.game end)
  if ok and type(g)=="table" then return g end
  local ok2,G=pcall(require,"src.core.Game")
  if ok2 and type(G)=="table" then return G end
  return nil
end

local function worldSnapshot()
  local g=liveGame()
  local ow=g and (g.overworld or g.world)
  local map=ow and ow.map
  local p=ow and ow.player
  if not (map and p) then return nil end

  -- Gen1Recomp/Potato entities are fundamentally 2D: px/py are world-pixel
  -- coordinates and cellX/cellY are map cells.  Cobblemon companion mods use
  -- x/z for the horizontal ground plane and y strictly for vertical height.
  -- Never feed the engine's map-Y into Cobblemon's vertical Y axis.
  local cx=tonumber(p.cellX)
  local cz=tonumber(p.cellY) or tonumber(p.cellZ)
  local px=tonumber(p.px)
  local pz=tonumber(p.py)
  local x=tonumber(p.x)
  local z=tonumber(p.z)
  if px~=nil then x=px+8 elseif x==nil and cx~=nil then x=cx*16+8 end
  if pz~=nil then z=pz+8 elseif z==nil and cz~=nil then z=cz*16+8 end

  return {
    id=tostring(map.id or map.name or map),
    map=map,
    player={
      x=x or 0,
      y=tonumber(p.worldY) or tonumber(p.height) or 0,
      z=z or 0,
      cellX=cx,
      cellY=cz, -- compatibility alias for older specs
      cellZ=cz, -- Cobblemon follower/wild/flying ground-plane axis
      facing=p.facing or "down",
    },
  }
end

local function makeLocalCompanion(host,lib)
  if localCompanion then return localCompanion end
  local OverworldBattle=nil
  if lib and type(lib.require)=="function" then
    local okb,b=pcall(lib.require,"OverworldBattle")
    if okb then OverworldBattle=b end
  end
  localCompanion={api=1}
  function localCompanion.register(spec)
    if type(spec)~="table" then return nil,"invalid companion spec" end
    localSpecs[#localSpecs+1]=spec
    table.sort(localSpecs,function(a,b) return (tonumber(a.priority) or 0)<(tonumber(b.priority) or 0) end)
    if type(spec.attach)=="function" then pcall(spec.attach,{}) end
    local handle={}
    function handle.dispose()
      for i=#localSpecs,1,-1 do if localSpecs[i]==spec then table.remove(localSpecs,i) break end end
      if type(spec.dispose)=="function" then pcall(spec.dispose) end
    end
    return handle
  end

  if Voxel3D and type(Voxel3D.endScene)=="function" and not Voxel3D.rumbleUniversalEndScene then
    Voxel3D.rumbleUniversalEndScene=true
    local inner=Voxel3D.endScene
    Voxel3D.endScene=function(...)
      local staged=false
      if OverworldBattle and type(OverworldBattle.arena)=="function" then
        local oka,a=pcall(OverworldBattle.arena)
        staged=oka and a~=nil
      end
      if not staged then
        local world=worldSnapshot()
        if world then
          if localLastWorld~=world.id then
            localLastWorld=world.id
            for _,spec in ipairs(localSpecs) do if type(spec.worldChanged)=="function" then pcall(spec.worldChanged,world) end end
          end
          local dt=1/60
          local okdt,g=pcall(function() return liveGame() end)
          if okdt and g then
            dt=tonumber(g.dt) or tonumber(g.deltaTime) or dt
          end
          dt=math.max(0,math.min(0.1,dt))
          local context={world=world,frame={dt=dt}}
          for _,spec in ipairs(localSpecs) do
            if type(spec.update)=="function" then pcall(spec.update,context.frame) end
            -- Gameplay companion specs draw themselves directly through Voxel3D.
            -- Skip the importer's generic packet renderer to avoid duplicate actors.
            if spec.id~="cobblemon.main" and spec.id~="cobblemon.importer" and spec.render and type(spec.render.opaque_after_terrain)=="function" then
              pcall(spec.render.opaque_after_terrain,context)
            end
          end
        end
      end
      return inner(...)
    end
  end
  return localCompanion
end

local function hostApi()
  if not (mod and type(mod.find)=="function") then return nil,"mod.find unavailable" end
  for _,id in ipairs({"BATTLE_ART_VOXEL_GEN2","BATTLE_ART_VOXEL_FORK","potato_voxel","VOXEL_ASCENDANT","DRAMALESS_SHAPE"}) do
    local ok,host=pcall(mod.find,id)
    if ok and host then
      local lib=host.exports and host.exports.lib
      local direct=host.exports and host.exports.Voxel3D
      local v3d=nil
      if lib and type(lib.require)=="function" then
        local okv,v=pcall(lib.require,"Voxel3D")
        if okv and v and type(v.draw)=="function" then v3d=v end
      elseif direct and type(direct.draw)=="function" then
        v3d=direct
      end
      local api=host.exports and host.exports.voxel_companion

      -- Battle Art Voxel Fork 1.10.4 has its own strict companion dispatcher.
      -- Cobblemon's v1.3.9 gameplay systems predate that dispatcher and render
      -- their follower/wild/flying actors directly through Voxel3D. Registering
      -- them into the Fork's native provider can leave the callbacks inactive
      -- even though battle integration itself works.
      --
      -- For Battle Art, keep using its PUBLIC Voxel3D implementation, but run
      -- Cobblemon's existing v1.3.9 overworld feature callbacks through Cobblemon's
      -- lightweight endScene adapter. This preserves the exact follower/wild/
      -- ecology code path that already works with Potato/Dramaless.
      if id=="BATTLE_ART_VOXEL_FORK" and v3d then
        Voxel3D=v3d
        rendererMod,rendererId=host,id
        return makeLocalCompanion(host,lib)
      end

      if api and tonumber(api.api)==1 and type(api.register)=="function" then
        Voxel3D=v3d or Voxel3D
        rendererMod,rendererId=host,id
        return api
      end
      if v3d then
        Voxel3D=v3d
        rendererMod,rendererId=host,id
        return makeLocalCompanion(host,lib)
      end
    end
  end
  return nil,"no supported voxel renderer found"
end

local Actor={}; Actor.__index=Actor

local function stateFor(model,name)
  if name=="idle" or name=="stand" then return model.states.stand and "stand" or "idle" end
  if name=="walk" then return model.states.walk and "walk" or (model.states.stand and "stand" or "idle") end
  if name=="run" then return model.states.run and "run" or (model.states.walk and "walk" or "stand") end
  if name=="fly" then return model.states.fly and "fly" or (model.states.airidle and "airidle" or (model.states.walk and "walk" or "stand")) end
  if name=="air_idle" then return model.states.airidle and "airidle" or (model.states.stand and "stand" or "idle") end
  if name=="water_idle" then return model.states.wateridle and "wateridle" or (model.states.stand and "stand" or "idle") end
  if name=="water_swim" then return model.states.waterswim and "waterswim" or (model.states.surfaceswim and "surfaceswim" or (model.states.surf and "surf" or (model.states.walk and "walk" or "stand"))) end
  if name=="surf" then return model.states.surf and "surf" or (model.states.surfaceswim and "surfaceswim" or (model.states.stand and "stand" or "idle")) end
  if name=="cry" or name=="entrance" or name=="battle_enter" or name=="battle_start" then return model.states.cryoverlay and "cryoverlay" or (model.states.cry and "cry" or (model.states.stand and "stand" or "idle")) end
  if name=="physical" then return model.states.physical and "physical" or (model.states.attack and "attack" or "stand") end
  if name=="special" then return model.states.special and "special" or (model.states.attack and "attack" or "stand") end
  if name=="status" then return model.states.status and "status" or (model.states.attack and "attack" or "stand") end
  if name=="attack" or name=="action" then return model.states.attack and "attack" or (model.states.physical and "physical" or (model.states.special and "special" or "stand")) end
  if name=="hurt" then return model.states.hurt and "hurt" or (model.states.recoil and "recoil" or "stand") end
  if name=="recoil" then return model.states.recoil and "recoil" or (model.states.hurt and "hurt" or "stand") end
  if name=="faint" then return model.states.faint and "faint" or "stand" end
  if name=="sleep" then return model.states.sleep and "sleep" or "stand" end
  return model.states.stand and "stand" or "idle"
end

function Actor:setPosition(x,y,z)
  local nx=x~=nil and x or self.x; local ny=y~=nil and y or self.y; local nz=z~=nil and z or self.z
  local dx,dy,dz=(nx or 0)-(self.x or 0),(ny or 0)-(self.y or 0),(nz or 0)-(self.z or 0)
  if dx*dx+dy*dy+dz*dz>0.000001 then self._stillFor=0 end
  self.x,self.y,self.z=nx,ny,nz; return self
end
function Actor:setGroundY(v)
  self._groundY=tonumber(v)
  return self
end

function Actor:isAirborne()
  if self._groundY==nil then return false end
  return (tonumber(self.y) or 0) > self._groundY + 0.35
end

function Actor:setYaw(v) self.yaw=tonumber(v) or 0; return self end
function Actor:setPitch(v) self.pitch=tonumber(v) or 0; return self end
function Actor:setRoll(v) self.roll=tonumber(v) or 0; return self end
-- Compatibility no-op. COBBLEMON_MAIN deliberately uses native model scale.
function Actor:setScale(_) return self end
function Actor:setVisible(v) self.visible=v~=false; return self end

local function applyState(self,state,force)
  if force or self.state~=state then
    self.state=state; self.time=0; self.rig:setState(state); self.rig:skin(0)
  end
end

function Actor:setAnimation(name)
  name=name or "idle"
  -- Tentacruel's authored aquatic/aerial locomotion clips collapse into a
  -- bind/T-pose in this renderer. Keep its normal animated ground idle for
  -- every Surf/Fly-style presentation (followers, ecology, carry, etc.).
  -- Battle entrance/cry is intentionally NOT intercepted here: it resolves to
  -- the normal idle pose plus cry overlay when one exists.
  if tonumber(self.species)==73 and (name=="surf" or name=="fly" or name=="water_swim"
      or name=="water_idle" or name=="air_idle") then
    name="idle"
  end
  self.animName=name; self.requestedAnim=name; self.done=false
  local st=stateFor(self.model,name)
  applyState(self,st,true)
  return self
end

function Actor:update(dt)
  if self.dead then return self end
  dt=math.max(0,math.min(.1,tonumber(dt) or 0))
  self.time=(self.time or 0)+dt
  self._stillFor=(self._stillFor or 0)+dt
  local name=self.requestedAnim or "idle"
  -- Safety: gameplay modules normally send IDLE themselves. If a movement
  -- request stops receiving position changes, native ground idle takes over.
  if (name=="walk" or name=="run") and self._stillFor>.12 then
    local st=stateFor(self.model,"idle")
    if self.state~=st then applyState(self,st,true) end
  elseif (name=="walk" or name=="run") and self._stillFor<=.12 then
    local wanted=name
    if self.model.states and self.model.states.fly and self:isAirborne() then
      wanted="fly"
    end
    local st=stateFor(self.model,wanted)
    if self.state~=st then applyState(self,st,true) end
  end
  local one=(name=="cry" or name=="entrance" or name=="battle_enter" or name=="battle_start" or name=="physical" or name=="special" or name=="status" or name=="attack" or name=="action" or name=="hurt" or name=="recoil" or name=="faint")
  if one then
    local d=self.rig:duration()
    -- For the idle+cry overlay, finish on the authored cry clip duration, not
    -- the looping idle clip duration. Faint handling below remains unchanged.
    local currentState=self.model.states and self.model.states[self.state]
    if (name=="cry" or name=="entrance" or name=="battle_enter" or name=="battle_start")
       and currentState and currentState._oneShotDuration then
      d=currentState._oneShotDuration
    end
    if name=="faint" and currentState and currentState._oneShotDuration then
      d=currentState._oneShotDuration
    end
    if d<=0 then d=(name=="faint") and .9 or .8 end
    if self.time>=d then
      if name=="faint" then self.time=d; self.done=true
      else self:setAnimation("idle") end
    end
  end
  self.rig:skin(self.time)
  return self
end

function Actor:matrix()
  -- Floor anchor is locked from the base pose. Never derive translation from
  -- the current animated frame: wing tips / tucked feet otherwise move the
  -- entire actor up and down while flapping.
  local floor=tonumber(self.model.baseFloor) or tonumber(self.model.floor) or 0
  local rot=Mat4.mul(Mat4.mul(Mat4.rotateY((self.yaw or 0)+math.pi),Mat4.rotateX(self.pitch or 0)),Mat4.rotateZ(self.roll or 0))
  -- Native proportions with one uniform requested display multiplier.
  -- No target-height curve, lore buckets, species caps, or limiter.
  local k=0.6*(tonumber(self.renderScale) or 1)
  return Mat4.mul(
    Mat4.mul(
      Mat4.mul(Mat4.translate(self.x or 0,self.y or 0,self.z or 0),rot),
      Mat4.scale(k,k,k)),
    Mat4.translate(0,-floor,0))
end
function Actor:destroy()
  if self.dead then return end
  self.dead=true; actors[self.id]=nil
  if self.rig and self.rig.release then pcall(self.rig.release,self.rig) end
end
function Actor:render(context,phase,seq)
  if self.dead or not self.visible then return seq end
  local packets,nextSeq=self.rig:drawPackets(self:matrix(),phase,"cobblemon.main",seq)
  for _,cmd in ipairs(packets) do
    cmd.cacheKey=("cobblemon:%d:%d:%d"):format(self.id,self.model.species or 0,cmd.sequence)
    context.draw.mesh(cmd,context)
  end
  return nextSeq
end

local API={api=1,version="0.2.0"}
function API.available() return true end
function API.load(species) return Pack.load(species) end
function API.createActor(species,opts)
  opts=opts or {}; species=tonumber(species)
  if not species or species<1 or species>493 then return nil,"Cobblemon species outside supported range" end
  local model,err=Pack.load(species); if not model then return nil,err or "Cobblemon model unavailable" end
  local rig=Rig.new(model); if not rig then return nil,"could not create Cobblemon rig" end
  local id=nextId; nextId=nextId+1
  local a=setmetatable({id=id,species=species,model=model,rig=rig,x=opts.x or 0,y=opts.y or 0,z=opts.z or 0,yaw=opts.yaw or 0,pitch=opts.pitch or 0,roll=opts.roll or 0,visible=opts.visible~=false,manual=opts.manual==true,state="stand",animName="idle",requestedAnim="idle",time=0,_stillFor=999,dead=false},Actor)
  actors[id]=a; rig._actor=a; a:setAnimation("idle"); return a
end
function API.destroyActor(actor) if actor and actor.destroy then actor:destroy() end end
API.Mat4=Mat4
API.Voxel3D=function() return Voxel3D end
API.renderer=function() return rendererId end
API.shadowEnabled=shadowEnabled
API.outlineEnabled=outlineEnabled
API.battleSceneEnabled=battleSceneEnabled
API.modelSmoothingEnabled=modelSmoothingEnabled
function API.nativeScale() return true end

_G.COBBLEMONE_GEN2_API=API
_G.COBBLEMON_API=API
mod.exports.cobblemone_gen2=API
mod.exports.cobblemon_151=API
mod.exports.cobblemon_main=API
mod.exports.cobblemon_importer=API

local host,err=hostApi()
-- Export the resolved companion service through the importer so all Cobblemon
-- gameplay modules use one renderer-neutral registration point.
mod.exports.voxel_companion=host

-- Unified gameplay modules. Keeping the COBBLEMON_MAIN id/API means Quest continues
-- to hook the same importer exactly as before.
local function loadFeature(rel)
  local source=mod:read(rel)
  if not source then error("COBBLEMON_MAIN: missing embedded feature "..rel,0) end
  local chunk,err=load(source,"@"..mod.path.."/"..rel)
  if not chunk then error("COBBLEMON_MAIN feature compile error in "..rel..": "..tostring(err),0) end
  return chunk(mod)
end
loadFeature("features/Follower.lua")
loadFeature("features/StaticMapPokemonSafe.lua")
loadFeature("features/OverworldWilds.lua")
loadFeature("features/FlyingOverworld.lua")
loadFeature("features/WaterEcology.lua")
loadFeature("features/GroundEcology.lua")

if host then
  local spec={
    api=1,id="cobblemon.main",name="CobblemoneGen2",version="0.9.1-gen2",priority=20,
    requires={"render_phases","world_snapshot"}, optional={},
    update=function(frame)
      local dt=(type(frame)=="table" and tonumber(frame.dt)) or 1/60
      for _,a in pairs(actors) do if not a.manual then a:update(dt) end end
    end,
    render={
      opaque_after_terrain=function(context)
        local seq=1; for _,a in pairs(actors) do seq=a:render(context,"opaque_after_terrain",seq) end
      end,
    },
    dispose=function() for _,a in pairs(actors) do if a.rig then a.rig:release() end end; actors={} end,
  }
  local ok,h=pcall(host.register,spec)
  if ok then companionHandle=h elseif mod.log then mod.log:error("Cobblemon Main companion registration failed: %s",tostring(h)) end
elseif mod.log then mod.log:error("Cobblemon Main disabled: %s",tostring(err)) end


-- Renderer-specific battle bridge. Battle Art Voxel Fork exposes a public
-- drawActors seam while its voxel camera/depth target are active.
do
  if rendererId=="BATTLE_ART_VOXEL_GEN2" and rendererMod then
    local okBridge,Bridge=pcall(V.require,"CobbleBattleArtGen2")
    if okBridge and Bridge then
      local ok,why=Bridge.install(rendererMod,API)
      if not ok and mod.log then mod.log:error("CobblemoneGen2 Battle Art Gen2 bridge unavailable: %s",tostring(why)) end
    elseif mod.log then
      mod.log:error("CobblemoneGen2 Battle Art Gen2 bridge load failed: %s",tostring(Bridge))
    end
  elseif rendererId=="BATTLE_ART_VOXEL_FORK" and rendererMod then
    local okBridge,Bridge=pcall(V.require,"CobbleBattleArtFork")
    if okBridge and Bridge then
      local ok,why=Bridge.install(rendererMod,API)
      if not ok and mod.log then mod.log:error("Cobblemon Battle Art Fork bridge unavailable: %s",tostring(why)) end
    elseif mod.log then
      mod.log:error("Cobblemon Battle Art Fork bridge load failed: %s",tostring(Bridge))
    end
  elseif rendererId=="potato_voxel" and rendererMod then
    local okBridge,Bridge=pcall(V.require,"CobblePotatoBattle")
    if okBridge and Bridge then
      local ok,why=Bridge.install(rendererMod,API)
      if not ok and mod.log then mod.log:error("Cobblemon Potato battle bridge unavailable: %s",tostring(why)) end
    elseif mod.log then
      mod.log:error("Cobblemon Potato battle bridge load failed: %s",tostring(Bridge))
    end
  elseif rendererId=="DRAMALESS_SHAPE" and rendererMod then
    local okBridge,Bridge=pcall(V.require,"CobbleBattleBridge")
    if okBridge and Bridge then
      local ok,why=Bridge.install(rendererMod,API)
      if not ok and mod.log then mod.log:error("Cobblemon Dramaless battle bridge unavailable: %s",tostring(why)) end
    end
  end
end


-- Gen2 loaders may finish exporting Battle Art's staged-battle modules after
-- content mods have entered main.lua. Retry once at mods.loaded; Bridge.install
-- is idempotent, so this is harmless when the eager install already succeeded.
if mod.events and type(mod.events.on)=="function" then
  mod.events:on("mods.loaded",function()
    if rendererId~="BATTLE_ART_VOXEL_GEN2" or not rendererMod then return end
    local okBridge,Bridge=pcall(V.require,"CobbleBattleArtGen2")
    if okBridge and Bridge then
      local ok,why=Bridge.install(rendererMod,API)
      if not ok and mod.log then mod.log:error("CobblemoneGen2 delayed Battle Art bridge unavailable: %s",tostring(why)) end
    end
  end)
end
