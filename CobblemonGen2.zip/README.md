v0.7.2.66: Ground Ecology flying height increased to 3x the previous range. Flying-capable birds only switch to fly animation once clearly airborne (>3.0 above ground); otherwise they use normal idle/walk. No spawn, route ecology, play/prey, touch, or battle logic changed.

v0.7.2.65 Ground/air animation correction
- Flying-capable Ground Ecology birds are no longer forced into flight during PLAY/PREDATOR/ROUGH_PLAY.
- At or near ground height they use normal idle/walk. Once their actual Y rises more than 0.35 above groundY they use fly; landing switches them back automatically.
- Per-route ecology data, spawning, touch encounters, battles, event logic and cleanup are unchanged from v0.7.2.64.


### v0.7.2.64 ecology motion test
Per-route Ground Ecology data and its spawn/touch/battle/event logic are unchanged from v0.7.2.63. This build only adds visual motion profiles: true flying birds lift and use fly while playing/chasing, levitating species hover/bob, and selected small ground species hop during ecology interactions.

CobblemoneGen2 v0.7.2

Standalone Cobblemon runtime for the Gen2/GSC recomp. Uses the original BATTLE_ART_VOXEL_GEN2 2.1.1 as its voxel renderer; Battle Art itself is not modified.

This build fixes native Gen2 species lookup for battles, route wilds, and flying ecology. Ground ecology on Johto maps now chooses its play groups and predator/prey actors from the current map's actual Gen2 grass encounter table first, with Gen2-only Johto fallbacks. Kanto postgame keeps Kanto-compatible ecology.

Battle Art settings for Cobble battles:
- 3D-BTL: ON (required)
- BACK SPRITES: OFF
- BATTLE ART: ROM is fine; STATIC/ANIMATED are also fine because CobblemoneGen2 replaces the staged battler cards only after its 3D actors are valid.

If 3D-BTL is OFF, Battle Art intentionally uses the native 2D battle screen and CobblemoneGen2 will not have a voxel stage to draw into.


v0.7.1 ecology/battle pass:
- ground ecology is now only predator/prey or playing; species come from the current map encounter table
- removed rival/scuffle ecology and regional fallback species
- normal overworld wilds are denser and spawn closer on large Johto maps
- flying ecology reads current + connected adjacent map encounter birds; non-family birds can form their own flocks instead of defaulting to Pidgey
- battle bridge now uses Battle Art Gen2's own species resolver and retries after mods.loaded; when Cobble actors are ready it removes only the two flat battler cards


v0.7.2 fixes:
- Battle bridge now reads Gen2 battlers through BattleState:activeMon(side), not Gen1 battle.player/battle.enemy fields.
- Normal OverworldWilds spawn behavior restored to the last known-working v0.7.0 logic.
- Ground ecology remains route-encounter based and limited to predator/prey + playing.
- Flying ecology keeps current + adjacent numbered-route encounter birds, but no longer depends on an unreliable world.neighbors field.

v0.7.2.7 battle hotfix: keeps the proven hosted Cobble 3D battle renderer from v0.7.2, uses the Gen2 presentation battler for faint/send-out state, locks faint until its clip completes, and hides Cobble actors during trainer frames while preserving trainer cards. Overworld behavior is unchanged.


### v0.7.2.10 HP-zero faint fix
Battle fainting now uses HP <= 0 directly from the live Gen2 battler/active mon. When HP reaches zero, the existing Cobble faint animation is started and locked until it finishes; no onFaint/faint-FX hook is required. Overworld behavior is unchanged.

### v0.7.2.11 idle + cry overlay
Battle send-out now keeps the normal idle pose running underneath the authored cry clip, preventing partial cry clips from snapping unkeyed bones into bind/T-pose. The working HP-zero faint path from v0.7.2.10 is unchanged.

### v0.7.2.12
Battle fainting now uses the other authored Cobblemon faint clips when a Pokémon has no plain `faint` animation (battle/ground/water/WIP variants where present). The working HP-zero trigger and idle+cry overlay are unchanged.



v0.7.2.13: Pokemon without an authored faint clip now use a skeleton-based faint fallback. Bipeds buckle at the knees and bow the head, quadrupeds fold their legs and lower the body/head, and floating/legless Pokemon drop with limp arms and a small settling bounce. When an authored blink exists, the eyes are held closed during the collapse. Real faint clips still take priority, and the existing HP=0 faint trigger and idle+cry overlay are unchanged.

v0.7.2.18 ecology rebuild:
- battle side stays on the working v0.7.2.13 baseline
- GroundEcology.lua is restored directly from the user-confirmed v0.6.2 ecology build (prey/predator + playing behavior preserved)
- flying ecology is restored from v0.6.2, with normal flock size 1-6; Hoothoot/Noctowl groups are capped at 3 total and never more than 2 Noctowl
- route overworld population is a separate layer: 3 wilds stay in grass and 5 stay on safe non-grass tiles
- overworld species still come from the route's real Gen2 grass encounter distribution through the existing Gen2 effectiveEncounters API
- removed the unused Gen1 src.world.Map dependency from OverworldWilds and use the Gen2 mod.world:current() player position seam with the normal world.player fallback

v0.7.2.29 route distribution test
- Built directly from the confirmed-working v0.7.2.18 baseline.
- Normal overworld population is pre-scaled per route from a stored route-size table (about 1 wild per 25 map blocks, 3-18 total, roughly 70% grass / 30% outside).
- Route 29 is set to 39x9 as requested, giving a target of 14 normal overworld wilds (10 grass / 4 outside).
- Placement now samples the whole live map using the existing widthCells/heightCells + the same v0.7.2.18 grass/walkable/occupied checks. If those map fields are unavailable, it falls back to the exact old 3-8 tile candidate logic.
- Player-distance despawning is disabled so far-end wilds remain populated. Ground Ecology, Flying Ecology, battle code, model loading, species selection and encounter triggers are unchanged from v0.7.2.18.

Water ecology test
- Water encounter species now appear across actual water cells using the current map's effective water encounter table.
- Pure Water types sit roughly half-submerged. Tentacool/Tentacruel can drift at the surface or below it. Water/Flying species such as Gyarados and Mantine hover/fly over the water.
- Water Pokémon swim between water cells. Pidgeot/Fearow can occasionally circle and swoop at sea Pokémon, which flee through the water.
- WATER ECOLOGY has its own settings toggle. Existing land, flying, follower and battle code is otherwise unchanged from v0.7.2.31.

Water ecology v0.2
- Water population is still taken from the current map's effective water encounter table, then restricted to: Tentacool, Tentacruel, Chinchou, Lanturn, Remoraid, Magikarp, Qwilfish, Corsola, Horsea, Seadra, Azumarill, Goldeen, Seaking and Mantine.
- Krabby/Kingler and other shoreline-capable Water types are not water-only ecology members.
- Tentacool/Tentacruel can drift at the surface or underneath. Mantine hovers over water. Pidgeot/Fearow water-hunt events only target members of this same encounter-based water population.


### v0.7.2.34
- Fixed Tentacruel going into a T-pose while moving in Water Ecology. Tentacruel now keeps its complete animated water pose while translating across water.


Water ecology audit (v0.7.2.35): water actors now keep safe water-idle/stand poses while translating, avoiding partial water-swim clips that can expose bind/T-poses. Mantine stays elevated but uses its authored water animation rather than a nonexistent flight clip. Pidgeot/Fearow predator flight is unchanged.


Water ecology hotfix: Tentacruel (#073) is forced to use normal idle while moving on water to avoid the broken T-pose locomotion clip.

v0.7.2.38 sea-route ecology patch:
- Fearow/Pidgeot water strikes no longer make Tentacool/Tentacruel visually disappear. A struck target is kept alive, forced to the surface for 4 seconds, and flees through connected water while the bird escapes.
- Ground Ecology now detects water-dominant routes with sparse grass and, on those maps, builds shoreline groups only from the live water encounter table.
- Sea-route Ground Ecology is restricted to Psyduck, Golduck, Poliwag, Poliwhirl, Poliwrath, Slowpoke, Slowbro, Seel, Dewgong, Shellder, Cloyster, Krabby, Kingler, Omanyte, Omastar, Wooper, Quagsire and Octillery, and only if that species is actually present in the current map's effective water encounters.
- These sea-route groups spawn on walkable cells close to water; normal Ground Ecology behavior is unchanged on ordinary routes, forests and caves.


### Surf follower filtering (v0.7.2.39)
- While the trainer is Surfing, Water-type party followers remain visible. Flying-type followers remain visible only if their Cobblemon model actually provides a `fly` animation/state. All other followers are temporarily hidden and automatically return when the trainer steps back onto land. This does not change the selected follower count or party order.

v0.7.2.42: Restores follower positioning to the proven render-world player while reading only the Surfing flag from the live overworld player. This fixes the no-follower regression from v0.7.2.40/41 while keeping the Surf follower filter.


v0.7.2.43: Followers now respect the live map collision grid while catching up. Interior/warp entry no longer seeds the follower chain into black filler tiles, and catch-up movement no longer cuts diagonally through blocked wall corners.

### v0.7.2.44 Surf follower fix
- Surf detection now falls back to the player's actual water cell, so non-water followers such as Ampharos cannot keep following just because the render snapshot missed the Surf flag.
- While Surfing, follower animation priority is `surf` first, then `fly`, then the normal ground animation only for allowed exceptions/fallbacks.
- Spinarak and Ariados are explicitly allowed to follow while Surfing.
- Existing follower wall-collision behavior from v0.7.2.43 is retained.


v0.7.2.45: Surf followers now use Gen2 FieldMoves Surf state first. While Surfing there is no idle/walk fallback: followers must use an authored surf animation, otherwise fly. Added Ekans, Arbok, Onix, Dratini, Dragonair, and Steelix as Surf follower exceptions; non-water land followers such as Arcanine are suppressed.

v0.7.2.46 follower transition fix:
- Followers now stack on the trainer when entering a door/map warp instead of preserving a train into black/out-of-bounds space.
- Followers also stack on the trainer when stepping from Surf onto land, so returning followers do not respawn back in the water.
- Fresh valid trail cells spread the stack naturally after the trainer starts moving.
- Removed Onix and Steelix from Surf follower exceptions; Ekans, Arbok, Dratini, and Dragonair remain.


v0.7.2.47 connected-map follower transition fix:
- Door/cave/warp transitions still stack followers on the trainer so no trail is drawn into black/out-of-bounds filler.
- Seamless map connections (for example New Bark Town <-> Route 29) no longer use the stack reset. Followers are rebuilt as a valid behind-player formation on the new map.
- Surf-to-land stacking from v0.7.2.46 is preserved.
- Strict Surf follower filtering and Surf/Fly animation rules are unchanged.


v0.7.2.48 water predator carry pass:
- Tentacool (#072) is forced to normal idle in Water Ecology.
- Pidgeot/Fearow now continue forward through the strike instead of reversing backward.
- Water-ecology prey can be visibly carried away beneath the bird, matching Flying Ecology.
- Tentacruel (#073) is explicitly too large to carry; it remains in the water and flees after the strike.


v0.7.2.49 nocturnal water hunter + Tentacruel animation audit:
- Noctowl (#164) can now perform Water Ecology predator/carry hunts, but only while the native Gen2 night encounter cycle is active. Pidgeot/Fearow remain daytime/night predators.
- Flying Ecology now explicitly treats Noctowl as the Hoothoot-family hunter; Hoothoot itself does not detach for predator attacks. Noctowl hunting is night-only.
- Tentacruel (#073) is globally forced to its normal idle pose whenever a system requests Surf/Fly/water/air locomotion. This covers Water Ecology and Surf followers without reintroducing its T-pose.
- Battle-start audit: every supported Cobblemon battle adapter requests `entrance`; `entrance` resolves through the idle+cry overlay when an authored cry clip exists, otherwise normal idle. Tentacruel has no authored cry animation in the imported model, so it stays in animated idle while the game's normal cry audio plays instead of entering a bad pose.


v0.7.2.50 flying ecology locality pass
- Xatu is Flying Ecology only and is restricted to Ruins of Alph map IDs. It is not a Water Ecology hunter.
- Skarmory remains Flying Ecology only. It now requires the current map encounter table to actually provide Skarmory; the old Route 45 fallback injection was removed. Existing solo/small-pair behavior is retained.
- Noctowl remains a night-only hunter in both Flying and Water Ecology. Hoothoot does not hunt.
- Water hunters remain Pidgeot, Fearow, and Noctowl at night; Xatu and Skarmory were not added to Water Ecology.
- Tentacruel safeguards from v0.7.2.49 are retained: forced idle for surf/fly/water locomotion requests, idle-safe battle entrance, and no water carry.

v0.7.2.51 encounter-driven ground play
- Removed the hard-coded normal Ground Ecology play species pools.
- Normal route/forest/cave play participants now come only from that map's live grass encounter table.
- Play pairing is generated by evolution stage: base+base or base+immediate-evolution. Third-stage species are excluded from normal play pairing.
- The encounter table decides where a species may appear; evolution metadata is used only to classify the interaction.
- Duplicate ecology scenes with the same species/event signature cannot run at the same time on one map.
- A finished scene gets a random 18-40 second per-scene replay cooldown, which starts only after that scene has ended.
- Active ecology scene centers are kept at least 5 cells apart to avoid duplicate/stacked scenes around the player.
- Existing battle, followers, Flying Ecology, Water Ecology, normal overworld wilds, Xatu/Skarmory locality, and native night logic are unchanged.

### v0.7.2.53 Ground Ecology first-scene retry
- The first Ground Ecology scene after entering a valid route/forest/cave no longer has to win the normal 68% spawn roll.
- If the first placement/pair attempt fails, Ground Ecology retries every ~1.25-2.5 seconds until one valid scene is actually created.
- After the first scene exists, the normal 6-14 second probabilistic respawn cadence is unchanged.
- Existing duplicate-event spacing and post-event replay cooldowns remain unchanged.


## v0.7.2.53
Rolled Ground Ecology play/prey behavior back to the v0.7.2.50 implementation. Normal overworld wild spawning and all other v0.7.2.52 systems are unchanged.


v0.7.2.54 overworld touch encounter hotfix
- Fixed normal route-populated OverworldWilds touch detection on Gen2/Johto.
- The collision check no longer requires `Game.overworld.player`; it uses the existing `mod.world:current()` player-cell path that already drives the working Gen2 route population.
- Touching a visible normal overworld wild still starts a battle against that exact displayed species/level.
- Ground Ecology play/prey rollback from v0.7.2.53 is unchanged. Flying Ecology, Water Ecology, followers and battle rendering are unchanged.


v0.7.2.55 overworld touch acceptance fix
- Fixed a second touch-encounter failure in OverworldWilds: pcall success was incorrectly treated as queueScript/startBattle acceptance.
- Gen2 queueScript can reject a foreground script while busy without throwing; the old code then removed the visible wild and locked the encounter even though no battle started.
- A visible wild is now removed only after the engine actually accepts the battle request. Rejected requests leave the actor present and retry while the player remains on its tile.
- No spawn/ecology/follower/battle-render changes.

v0.7.2.63 test note
- Based on v0.7.2.57 known-good ecology baseline.
- GroundEcology.lua is byte-for-byte unchanged from v0.7.2.57.
- No second route actor manager is added.
- Normal OverworldWilds remains independent.
- Route 29/30/38 keep the hardcoded visible species test from v0.7.2.60.
- Normal wild touch borrows only Ground Ecology's world X/Z radius contact idea and calls the existing exported startDexEncounter path.


## v0.7.2.63 per-map Ground Ecology
Ground Ecology species/group selection is now hardcoded per route/area from the supplied ecology list. PLAY entries spawn as the listed 2-3 Pokemon groups; PREDATOR entries use the listed predator/prey pair; ROUGH_PLAY entries use the listed pair. The known-good actor creation, movement, touch battle, event lifecycle, and rendering code remains unchanged.

v0.7.2.79 test: route overworld touch now uses the existing OverworldWilds actor and the exact WaterEcology-style tracked-position contact lifecycle. No new module. GroundEcology is unchanged from v0.7.2.77.

v0.7.2.81
- Built from the working v0.7.2.79 base.
- Existing GroundEcology PLAY members that are small/first-stage, plus existing PREY members, can now be selected by the existing FlyingOverworld hunt controller.
- No duplicate prey is spawned: the flying hunter targets and carries the already-visible GroundEcology actor.
- PLAY/PREY spawning remains GroundEcology-owned; normal route roaming remains OverworldWilds-owned.
- If a flying hunter steals the prey from a ground hunt, the ground predator stops chasing, pauses briefly, then roams instead of retargeting immediately.
- Existing v0.7.2.79 overworld touch-to-battle path is retained.

v0.7.2.82 flying hunter eligibility:
- Built from the working v0.7.2.81 branch (which itself is based on the approved v0.7.2.79 touch-battle build).
- Ground PLAY/PREY swoop hunters are explicitly limited to Pidgeotto (#17), Pidgeot (#18), Fearow (#22), Noctowl (#164), Xatu (#178), and Skarmory (#227).
- Hunter capability does not spawn these species. Existing FlyingOverworld route/time selection still determines whether each bird is present on the current map.
- Noctowl keeps the existing native-night restriction. Xatu/Skarmory keep their existing locality/encounter restrictions.

v0.7.2.84
- Flying hunters can now choose from the full approved small/basic Gen I-II prey pool, not only Caterpie/Weedle/Rattata.
- Applies to both existing Ground Ecology PLAY targets and ordinary route-roaming fallback prey.
- PLAY remains first priority, PREDATOR/PREY prey second, ordinary route roamers last.
- This does not hard-spawn prey; route/time spawning remains unchanged.

### v0.7.2.85
- Removed Diglett, Pidgey, Voltorb, Koffing, Hoothoot, Natu, and Slugma from flying-hunt prey eligibility.
- Flying hunter species and route/time spawning are unchanged.
- PLAY -> PREDATOR/PREY -> normal route prey priority is unchanged.



v0.7.2.87 SURF MOUNT TEST
- Built from the proven v0.7.2.85 base (not the experimental v0.7.2.86 terrain-navigation build).
- While Surfing, follower slot 1 is reused as the mount and pinned to the trainer's exact X/Z position.
- No duplicate Pokemon is spawned. Native Surf movement/collision is unchanged.
- Other followers retain their normal trail behavior.
- This is intentionally a presentation test; it does not add the abandoned follower terrain-collision experiment.


v0.7.2.88 Surf mount render test
- Keeps .87 follower-as-mount lock.
- On Surf, overrides only the render-world player snapshot to use cached normal trainer presentation instead of native Surf/Lapras presentation.
- Does not alter Game.overworld.playerState / FieldMoves Surf physics.
- Lowers the mount 6 world units beneath the trainer to reduce clipping.


v0.7.2.89 Surf render pass: keeps the existing Surf follower mount alive across overworld/battle transitions where the follower renderer is available, applies the cached normal trainer presentation to both render/live player objects without changing Surf physics, and adds mirrored water reflections for Cobblemon followers.


v0.7.2.91
Rebuilt from v0.7.2.89. Only GroundEcology change: Pidgeotto, Pidgeot, Fearow, Noctowl, Xatu and Skarmory are excluded from GroundEcology predator spawning so FlyingOverworld owns their aerial hunts.

v0.7.2.92
- Ground Ecology events no longer pop out immediately when their normal lifetime expires. Members first run toward the nearest passable foliage/tree edge, stagger their destinations when possible, and disappear after reaching it. If no foliage edge is available, the existing exit behavior is used as fallback.
- FlyingOverworld-claimed/carried prey remains protected from Ground Ecology cleanup.
- Raised Hoppip, Skiploom and Jumpluff flight/hover altitude with species-specific offsets to reduce tree-canopy clipping. Other species flight heights are unchanged.
- Based on v0.7.2.91; no Surf/battle/ecology-selection changes in this pass.


Expanded-dex compatibility: runtime model/ecology acceptance is extended through #493. Species not supplied by the active Gen2 game/mod data are not created merely by this compatibility layer.
