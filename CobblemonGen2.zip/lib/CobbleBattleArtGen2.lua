local V = ...
local B = {}
local installed=false
local slots={player=nil,enemy=nil}
local lastBattler={player=nil,enemy=nil}
local API,Voxel3D,BattleScene,BattleArtAPI
local lastTime=nil
local BLACK_TEXTURE=nil

local function log(level,fmt,...)
  local L=V.log; if L and type(L[level])=="function" then pcall(L[level],L,fmt,...) end
end
local function blackTexture()
  if BLACK_TEXTURE then return BLACK_TEXTURE end
  if not (love and love.image and love.graphics and love.image.newImageData and love.graphics.newImage) then return nil end
  local ok,data=pcall(love.image.newImageData,1,1); if not ok or not data then return nil end
  pcall(data.setPixel,data,0,0,0,0,0,1)
  local ok2,img=pcall(love.graphics.newImage,data); if ok2 then BLACK_TEXTURE=img end
  return BLACK_TEXTURE
end
local function outlineEnabled()
  if API and type(API.outlineEnabled)=="function" then local ok,v=pcall(API.outlineEnabled); if ok then return v~=false end end
  return true
end
local function battleEnabled()
  if API and type(API.battleSceneEnabled)=="function" then local ok,v=pcall(API.battleSceneEnabled); if ok then return v~=false end end
  return true
end

-- Model identity: use the active Gen2 mon first. This is what tells us which
-- Cobble model belongs in the slot.
local function modelBattler(battle,side)
  if not battle then return nil end
  if type(battle.activeMon)=="function" then
    local ok,mon=pcall(battle.activeMon,battle,side)
    if ok and mon then return mon end
  end
  return battle[side]
end

-- Presentation state: Battle Art's own Gen2 battle code drives send-out,
-- pic-FX and faint using battle.player / battle.enemy.
local function presentationBattler(battle,side)
  return battle and battle[side] or nil
end

local function safeBattleCall(battle,name,arg)
  local f=battle and battle[name]
  if type(f)~="function" then return nil end
  local ok,v=pcall(f,battle,arg)
  if ok then return v end
  return nil
end

local function dexOf(battle,battler)
  if not battler then return nil end
  local species=nil
  if BattleArtAPI and type(BattleArtAPI.speciesFor)=="function" then
    local ok,v=pcall(BattleArtAPI.speciesFor,battler)
    if ok then species=v end
  end
  species=species or (battler.mon and battler.mon.species) or battler.species
      or (battler.data and battler.data.species)
  if type(species)=="number" then
    local n=math.floor(species)
    if n>=1 and n<=493 then return n end
  end
  local content=V.mod and V.mod.content and V.mod.content.pokemon
  if content and type(content.get)=="function" and species~=nil then
    local ok,rec=pcall(content.get,content,species)
    local dex=ok and rec and tonumber(rec.dex) or nil
    dex=dex and math.floor(dex) or nil
    if dex and dex>=1 and dex<=493 then return dex end
  end
  local pokemon=battle and battle.data and battle.data.pokemon
  local def=type(pokemon)=="table" and species and (pokemon[species] or pokemon[tostring(species):upper()]) or nil
  local dex=def and tonumber(def.dex or def.index)
  dex=dex and math.floor(dex) or nil
  return dex and dex>=1 and dex<=493 and dex or nil
end

local function showingTrainerFlag(battle,side)
  if not battle then return false end
  if side=="enemy" then
    return battle.showEnemyTrainer and true or false
  end
  -- Keep the established Gen2 back-pic flag, plus showPlayerTrainer when a
  -- build exposes it. Texture.trainer is checked again at draw time.
  return (battle.showPlayerTrainer and true or false)
      or (battle.showPlayerBack and battle.playerBackPic and true or false)
end

local function textureIsTrainer(textures,side)
  local t=textures and textures[side]
  return t and t.trainer and true or false
end

local function destroySide(side)
  local a=slots[side]; if a then pcall(a.destroy,a) end
  slots[side]=nil; lastBattler[side]=nil
end

local function hpZero(b)
  if not b then return false end
  local hp=tonumber(b.hp)
  if hp~=nil and hp<=0 then return true end
  local mon=b.mon
  hp=mon and tonumber(mon.hp) or nil
  return hp~=nil and hp<=0 or false
end

local function faintSignal(battle,side)
  -- HP=0 is authoritative. Check both objects Gen2 exposes: the active mon
  -- used to choose the Cobble model, and the presentation battler.
  local active=modelBattler(battle,side)
  local presented=presentationBattler(battle,side)
  return hpZero(active) or hpZero(presented)
end

-- Match the native battle sprite visibility during capture/send-out FX.
-- In particular, a successful Poké Ball capture hides the enemy battler via
-- fxHidden/enemyHidden before the battle object itself is discarded.
local function gen2CapturePicCleared(battle,side)
  if side~="enemy" or not (battle and battle.ballThrow) then return false end
  if type(battle.picBoxCleared)=="function" then
    local ok,v=pcall(battle.picBoxCleared,battle,"enemy")
    if ok then return v and true or false end
  end
  -- Fallback for the Gen 2 presenter if the method is not exposed through
  -- a wrapper but its public presentation fields are.
  if battle.picHidden and battle.picHidden.enemy then return true end
  local anim=battle.anim
  local bg=anim and anim.bg
  return bg and bg.hidden and bg.hidden.enemy and true or false
end

local function battleFxHidden(battle,side)
  if not battle then return false end
  if side=="enemy" and battle.enemySendingOut then return true end
  if side=="enemy" and not battle.ballThrow and battle.enemyHidden then return true end
  if side=="player" and battle.sendingOut then return true end
  local b=presentationBattler(battle,side) or modelBattler(battle,side)
  if side=="enemy" and battle.ballThrow then return false end
  if b and type(battle.fxHidden)=="function" then
    local ok,v=pcall(battle.fxHidden,battle,b)
    if ok and v then return true end
  end
  return false
end

local function syncSide(battle,side)
  if not battleEnabled() then destroySide(side); return nil end
  local battler=modelBattler(battle,side)
  local a=slots[side]

  -- During the actual faint, activeMon can disappear before the visual is
  -- finished. Preserve the existing actor instead of destroying it.
  if not battler then
    if a then
      if a.requestedAnim=="faint" then
        a:setVisible(not a.done)
      elseif side=="enemy" and battle and battle.ballThrow then
        a.renderScale=gen2CapturePicCleared(battle,side) and 0.001 or 1
        a:setVisible(true)
      else
        a:setVisible(false)
      end
    end
    return a
  end

  local dex=dexOf(battle,battler)
  if not dex then return a end
  if not a or not a.model or a.model.species~=dex or lastBattler[side]~=battler then
    destroySide(side)
    local made,err=API.createActor(dex,{manual=true,visible=true,fullLore=true})
    if not made then
      log("warn","CobblemoneGen2 model unavailable for %s dex=%s: %s",side,tostring(dex),tostring(err))
      return nil
    end
    a=made; slots[side]=a; lastBattler[side]=battler
    a._faintStarted=false
    a.renderScale=1
    a._lastGrow=false
    a:setAnimation("entrance")
  end

  local fainting=faintSignal(battle,side)
  if fainting and not a._faintStarted then
    a._faintStarted=true
    a:setAnimation("faint")
  end

  if a._faintStarted then
    a.renderScale=1
    a:setVisible(not a.done)
  elseif side=="enemy" and battle and battle.ballThrow then
    -- Gen 2: ANIM_THROW_POKE_BALL owns the native pic state.
    -- Hidden during absorption/shakes => tiny 3D actor.
    -- Break-free reveals the pic => full-size actor again.
    -- Successful catch latches picHidden.enemy => actor remains tiny.
    a.renderScale=gen2CapturePicCleared(battle,side) and 0.001 or 1
    a:setVisible(true)
  elseif showingTrainerFlag(battle,side) or battleFxHidden(battle,side) then
    -- Follow the native sprite's hidden state during trainer/send-out/capture
    -- effects. This prevents a caught wild Cobblemon model remaining outside
    -- the Poké Ball while the normal enemy sprite is already hidden.
    a:setVisible(false)
  else
    a.renderScale=1
    a:setVisible(true)
  end
  return a
end

local function updatePresentation(battle,side,a)
  if not (battle and a) then return end
  -- Faint has absolute priority once it has begun.
  if a._faintStarted or a.requestedAnim=="faint" then return end
  local b=presentationBattler(battle,side)
  local grow=nil
  if b and type(battle.growInScale)=="function" then
    local ok,v=pcall(battle.growInScale,battle,b)
    if ok then grow=v end
  end
  if grow and not a._lastGrow then a:setAnimation("entrance") end
  a._lastGrow=grow and true or false
end

local function step(battle)
  syncSide(battle,"enemy"); syncSide(battle,"player")
  local now=(love and love.timer and love.timer.getTime and love.timer.getTime()) or os.clock()
  local dt=lastTime and math.max(0,math.min(.1,now-lastTime)) or 1/60; lastTime=now

  local playing=battle and battle.animPlaying and true or false
  if playing and not B._animWasPlaying then
    local side=battle.animAttackerIsPlayer and "player" or "enemy"
    local a=slots[side]
    if a and not a._faintStarted and a.requestedAnim~="faint" then
      -- Preserve the authored battle animation selected by performMove.
      -- animPlaying is a fallback signal only; it must not replace a real
      -- physical/special/status animation with generic "attack".
      local cur=a.requestedAnim
      if cur~="physical" and cur~="special" and cur~="status" and cur~="attack" and cur~="action" then
        a:setAnimation("attack")
      end
    end
  end
  B._animWasPlaying=playing

  for _,side in ipairs({"enemy","player"}) do
    local a=slots[side]
    if a then
      updatePresentation(battle,side,a)
      pcall(a.update,a,dt)
      if a._faintStarted then a:setVisible(not a.done) end
    end
  end
end

local function sideOf(self,battler)
  if not self or not battler then return nil end
  if battler==self.player then return "player" end
  if battler==self.enemy then return "enemy" end
end

local function moveAnim(...)
  local args={...}
  for _,v in ipairs(args) do
    if type(v)=="table" then
      local c=v.category or v.damageClass or v.damage_class or v.kind or v.class
      c=c and tostring(c):lower() or nil
      if c and c:find("special",1,true) then return "special" end
      if c and (c:find("status",1,true) or c:find("other",1,true)) then return "status" end
      if c and (c:find("physical",1,true) or c:find("attack",1,true)) then return "physical" end
    elseif type(v)=="string" then
      local c=v:lower()
      if c=="special" or c=="physical" or c=="status" then return c end
    end
  end
  return "attack"
end

local function installHooks()
  local ok,BattleState=pcall(require,"src.battle.BattleState")
  if not (ok and BattleState) or BattleState.cobblemonGen2BattleHook then return end
  BattleState.cobblemonGen2BattleHook=true
  if type(BattleState.performMove)=="function" then
    local inner=BattleState.performMove
    BattleState.performMove=function(self,user,...)
      local side=sideOf(self,user)
      local a=battleEnabled() and side and slots[side]
      if a and not a._faintStarted then a:setAnimation(moveAnim(...)) end
      return inner(self,user,...)
    end
  end
  if type(BattleState.startGrowIn)=="function" then
    local inner=BattleState.startGrowIn
    BattleState.startGrowIn=function(self,battler,...)
      local side=sideOf(self,battler); local a=side and slots[side]
      if a and not a._faintStarted then a:setAnimation("entrance") end
      return inner(self,battler,...)
    end
  end
  if type(BattleState.onFaint)=="function" then
    local inner=BattleState.onFaint
    BattleState.onFaint=function(self,battler,...)
      local side=sideOf(self,battler); local a=side and slots[side]
      if a then a._faintStarted=true; a:setAnimation("faint") end
      return inner(self,battler,...)
    end
  end
end

local function drawActor(actor,side,arena,ctx)
  if not (actor and actor.visible and arena and ctx and Voxel3D and type(Voxel3D.draw)=="function") then return false end
  local own=arena[side]; local other=arena[side=="player" and "enemy" or "player"]; if not own then return false end
  local fx,fz=0,(side=="player" and -1 or 1); if other then fx,fz=other[1]-own[1],other[2]-own[2] end
  local yaw=(math.atan2 and math.atan2(fx,fz)) or math.atan(fx,fz)
  actor:setPosition(own[1],tonumber(ctx.groundY) or 0,own[2]); actor:setYaw(yaw); actor.rig:skin(yaw)
  local matrix=actor:matrix(); if type(Voxel3D.seams)=="function" then pcall(Voxel3D.seams,false) end; if type(Voxel3D.glass)=="function" then pcall(Voxel3D.glass,false) end
  local black=blackTexture()
  if outlineEnabled() and black and love and love.graphics and love.graphics.setDepthMode then
    pcall(love.graphics.setDepthMode,"lequal",false)
    for _,part in ipairs(actor.rig.parts or {}) do if part.outlineMesh then pcall(Voxel3D.draw,part.outlineMesh,black,matrix,0,matrix) end end
    pcall(love.graphics.setDepthMode,"lequal",true)
  end
  local drew=false
  for _,part in ipairs(actor.rig.parts or {}) do if part.mesh and part.texture then local ok=pcall(Voxel3D.draw,part.mesh,part.texture,matrix,0,matrix); if ok then drew=true end end end
  if type(Voxel3D.glass)=="function" then pcall(Voxel3D.glass,true) end; if type(Voxel3D.seams)=="function" then pcall(Voxel3D.seams,true) end
  return drew
end

function B.install(host,api)
  if installed then return true end; API=api
  installHooks()

  -- gen1recomp exposes the final result of every Ball throw directly.
  -- Lock the enemy actor off as soon as a successful capture is confirmed;
  -- failed throws do nothing, so the Pokémon remains/restores normally.
  local events=V.mod and V.mod.events
  if events and type(events.on)=="function" then
    events:on("battle.ended",function(ev)
    end)
  end
  BattleArtAPI=host and host.exports and host.exports.battleArt
  local lib=host and host.exports and host.exports.lib
  if not (lib and type(lib.require)=="function") then return false,"Battle Art Gen2 lib export unavailable" end
  local okv,v=pcall(lib.require,"Voxel3D"); if not okv or not v then return false,"Voxel3D unavailable" end; Voxel3D=v
  local okb,bs=pcall(lib.require,"BattleScene"); if not okb or not bs or type(bs.render)~="function" then return false,"BattleScene unavailable" end; BattleScene=bs
  local original=BattleScene.render
  BattleScene.render=function(state,arena,textures,token,battle,animTex,animAnchors,externalCamera,externalModelShadow,drawActors)
    if not battleEnabled() then
      destroySide("player"); destroySide("enemy"); lastTime=nil; B._animWasPlaying=false
      return original(state,arena,textures,token,battle,animTex,animAnchors,externalCamera,externalModelShadow,drawActors)
    end

    step(battle)
    if drawActors then
      return original(state,arena,textures,token,battle,animTex,animAnchors,externalCamera,externalModelShadow,drawActors)
    end

    local ownPlayer=slots.player~=nil
    local ownEnemy=slots.enemy~=nil
    if not (ownPlayer or ownEnemy) then
      return original(state,arena,textures,token,battle,animTex,animAnchors,externalCamera,externalModelShadow,drawActors)
    end

    local provider={}
    provider.draw=function(ctx)
      -- Texture metadata is Battle Art's most reliable final answer about
      -- whether this side is currently a trainer frame. Preserve that card
      -- and simply do not draw the Cobble actor underneath it.
      if not textureIsTrainer(textures,"enemy") and not showingTrainerFlag(battle,"enemy") then
        drawActor(slots.enemy,"enemy",arena,ctx)
      end
      if not textureIsTrainer(textures,"player") and not showingTrainerFlag(battle,"player") then
        drawActor(slots.player,"player",arena,ctx)
      end
    end

    local shadowArg=externalModelShadow
    if API and type(API.shadowEnabled)=="function" and not API.shadowEnabled() then shadowArg=nil end

    local clean={}
    for k,v in pairs(textures or {}) do clean[k]=v end
    -- Suppress the ROM Pokemon card only for a side for which Cobble owns an
    -- actor. Trainer cards are intentionally kept, eliminating trainer/model
    -- overlap without giving up the proven hosted 3D renderer.
    if ownPlayer and not textureIsTrainer(textures,"player") then clean.player=nil end
    if ownEnemy and not textureIsTrainer(textures,"enemy") then clean.enemy=nil end

    return original(state,arena,clean,token,battle,animTex,animAnchors,externalCamera,shadowArg,provider)
  end
  installed=true; log("info","CobblemoneGen2 Battle Art Voxel Gen2 hosted bridge installed (HP-zero faint/trainer fix)"); return true
end
return B
