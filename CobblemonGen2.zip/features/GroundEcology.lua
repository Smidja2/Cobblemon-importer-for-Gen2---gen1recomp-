local GROUND_ECOLOGY_KEY="cobblemon_ground_ecology"
local OVERWORLD_WILDS_KEY="overworld_wilds"

local mod=...
local function liveGame()
  local g=mod and mod.game
  return type(g)=="table" and g or nil
end
local Game=setmetatable({}, {
  __index=function(_,k)
    local g=liveGame()
    if not g then return nil end
    if k=="overworld" then return g.overworld or g.world end
    return g[k]
  end,
  __newindex=function(_,k,v)
    local g=liveGame(); if g then g[k]=v end
  end
})

local function optionValue(key,default)
  local loader=Game and Game.mods
  local st=loader and loader.modOptions and loader.modOptions[mod.id]
  local v=st and st[key]
  if v==nil then
    local opts=Game and Game.save and Game.save.options
    st=opts and opts.modOptions and opts.modOptions[mod.id]
    v=st and st[key]
  end
  if v==nil then return default end
  return v
end
local function optionOn(key,default)
  local v=optionValue(key,default)
  return v~=false and v~=0 and v~="OFF" and v~="NO"
end
local function groundEcologyEnabled()
  return optionOn(OVERWORLD_WILDS_KEY,true) and optionOn(GROUND_ECOLOGY_KEY,true)
end

-- Ground ecology test layer: one ambient event at a time, independent of the
-- four normal OverworldWilds. Touching any participant starts a real battle.
local CELL=16
-- Gen2 maps are larger and transitions are more frequent. Keep ecology visible
-- without flooding the map: a first event appears quickly, then respawns settle.
local EVENT_CHANCE=0.68
local RESPAWN_MIN=6.0
local RESPAWN_MAX=14.0
local EVENT_LIFE=22.0
local WALK=27
local RUN=72
local TOUCH_RADIUS=10
local PLAY_ALERT_RADIUS=CELL*3.4
local PLAY_FLEE_SPEED=88 -- deliberately faster than the trainer
local PLAY_REGROUP_RADIUS=CELL*1.65
local MIN_R=4
local MAX_R=8
local ECOLOGY_EXIT_TREE_RADIUS=12
local ECOLOGY_EXIT_REACH=6.0
local ECOLOGY_EXIT_TIMEOUT=8.0
local HOPPIP_FAMILY_FLIGHT_BONUS=8.0

-- Short random flights for species that actually expose a native fly state.
-- Ground ecology remains ground-first; these are occasional takeoff/hover/
-- landing cycles rather than permanent hovering.
local RANDOM_FLY_MIN_GAP=5.0
local RANDOM_FLY_MAX_GAP=13.0
local RANDOM_FLY_MIN_TIME=4.0
local RANDOM_FLY_MAX_TIME=9.0
local RANDOM_FLY_MIN_HEIGHT=6.0
local RANDOM_FLY_MAX_HEIGHT=13.5
local RANDOM_FLY_VERTICAL_SPEED=6.0

-- Visual-only ecology motion profiles. These do not change event selection,
-- spawning, touch/battle logic, targets, cleanup, or per-route ecology data.
local ECOLOGY_BIRDS={
  [16]=true,[17]=true,[18]=true,       -- Pidgey line
  [21]=true,[22]=true,                -- Spearow line
  [83]=true,                          -- Farfetch'd
  [84]=true,[85]=true,                -- Doduo line (hop/run; no sustained flight below)
  [163]=true,[164]=true,              -- Hoothoot line
  [177]=true,[178]=true,              -- Natu line
  [198]=true,                         -- Murkrow
  [225]=true,                         -- Delibird
  [227]=true,                         -- Skarmory
}
local TRUE_FLYING_BIRDS={
  [16]=true,[17]=true,[18]=true,[21]=true,[22]=true,[83]=true,
  [163]=true,[164]=true,[177]=true,[178]=true,[198]=true,[225]=true,[227]=true,
}
local LEVITATORS={
  [81]=true,[82]=true,                -- Magnemite line
  [92]=true,[93]=true,[94]=true,      -- Gastly line
  [100]=true,[101]=true,              -- Voltorb line: subtle bob
  [109]=true,[110]=true,              -- Koffing line
}
local HOPPERS={
  [10]=true,[11]=true,[13]=true,[14]=true, -- Caterpie/Metapod/Weedle/Kakuna
  [19]=true,[20]=true,[161]=true,     -- Rattata line / Sentret
  [187]=true,                         -- Hoppip
  [194]=true,                         -- Wooper
  [206]=true,[209]=true,[216]=true,   -- Dunsparce/Snubbull/Teddiursa
}
local PLAY_FLY_HEIGHT=3.0
local LEVITATE_HEIGHT=1.35
local PLAY_HOP_HEIGHT=0.85

local PREDATOR_PREY_BY_BIOME={
  -- Johto-first pools. Kanto species remain because GSC revisits Kanto.
  route={
    {pred=23,prey=19,name="Ekans / Rattata"},
    {pred=52,prey=161,name="Meowth / Sentret"},
    {pred=58,prey=161,name="Growlithe / Sentret"},
    {pred=53,prey=19,name="Persian / Rattata"},
    {pred=228,prey=19,name="Houndour / Rattata"},
    {pred=215,prey=161,name="Sneasel / Sentret"},
  },
  forest={
    {pred=167,prey=10,name="Spinarak / Caterpie"},
    {pred=48,prey=10,name="Venonat / Caterpie"},
    {pred=23,prey=13,name="Ekans / Weedle"},
    {pred=46,prey=10,name="Paras / Caterpie"},
  },
  cave={
    {pred=41,prey=46,name="Zubat / Paras"},
    {pred=42,prey=46,name="Golbat / Paras"},
    {pred=95,prey=74,name="Onix / Geodude"},
    {pred=215,prey=41,name="Sneasel / Zubat"},
  },
}
local PREDATOR_PREY=PREDATOR_PREY_BY_BIOME.route
local PLAY_POOLS={
  route={19,161,179,187,194,203,209,216,234}, -- Rattata,Sentret,Mareep,Hoppip,Wooper,Girafarig,Snubbull,Teddiursa,Stantler
  forest={10,13,43,46,48,165,167,204},         -- bugs/plants incl. Ledyba,Spinarak,Pineco
  cave={41,74,95,194,206,213,220},             -- Zubat,Geodude,Onix,Wooper,Dunsparce,Shuckle,Swinub
}
local PLAY_DEX=PLAY_POOLS.route

-- Rival-vs-rival ambient battles. Pools are biome-scoped instead of choosing
-- arbitrary species everywhere. These are visual scuffles, not trainer battles.
local RIVAL_POOLS={
  route={
    {19,161},{161,161},{179,179},{187,187},{194,194},{209,161},{216,161},{23,19},
  },
  forest={
    {10,13},{165,167},{167,204},{43,46},{46,48},{204,204},
  },
  cave={
    {41,74},{74,74},{95,74},{194,74},{206,213},{220,74},
  },
  building={
    {19,52},{52,56},{63,19},{88,19},{100,52},
  },
}

-- Per-map ecology data supplied by the user. This only replaces species/group
-- selection. Actor creation, movement, touch battles, event lifecycle, and
-- rendering below remain the known-good Ground Ecology implementation.
local ROUTE_ECOLOGY={
  ["ROUTE_29"]={
    play={{161,19},{161,16},{19,16},{161,161,19},{16,161,19},{17,16,161}},
    hunt={{pred=17,prey=19,name="Pidgeotto / Rattata"},{pred=17,prey=161,name="Pidgeotto / Sentret"}},
    rival={{17,16},{20,19}},
  },
  ["ROUTE_30"]={
    play={{10,13},{10,165},{13,165},{16,10},{16,13},{10,13,165},{11,10,10},{14,13,13}},
    hunt={{pred=17,prey=10,name="Pidgeotto / Caterpie"},{pred=17,prey=13,name="Pidgeotto / Weedle"},{pred=167,prey=10,name="Spinarak / Caterpie"},{pred=167,prey=13,name="Spinarak / Weedle"}},
    rival={{11,10},{14,13}},
  },
  ["ROUTE_31"]={
    play={{10,13},{10,165},{69,10},{16,69},{187,69},{165,10,13},{11,10,10},{14,13,13}},
    hunt={{pred=167,prey=10,name="Spinarak / Caterpie"},{pred=167,prey=13,name="Spinarak / Weedle"},{pred=92,prey=19,name="Gastly / Rattata"}},
    rival={{11,10},{14,13}},
  },
  ["ROUTE_32"]={
    play={{19,69},{187,69},{16,187},{179,187},{179,69},{194,179},{194,69},{179,187,194}},
    hunt={{pred=23,prey=19,name="Ekans / Rattata"},{pred=23,prey=194,name="Ekans / Wooper"},{pred=23,prey=187,name="Ekans / Hoppip"}},
    rival={{20,19}},
  },
  ["ROUTE_33"]={
    play={{19,21},{74,19},{187,21},{56,21},{56,74},{19,21,187}},
    hunt={{pred=23,prey=19,name="Ekans / Rattata"},{pred=21,prey=187,name="Spearow / Hoppip"}},
    rival={{20,19}},
  },
  ["ILEX_FOREST"]={
    play={{10,13},{10,46},{13,46},{16,10},{16,13},{46,43},{10,13,46},{11,10,10},{14,13,13}},
    hunt={{pred=16,prey=10,name="Pidgey / Caterpie"},{pred=16,prey=13,name="Pidgey / Weedle"},{pred=48,prey=10,name="Venonat / Caterpie"},{pred=48,prey=13,name="Venonat / Weedle"}},
    rival={{11,10},{14,13}},
  },
  ["ROUTE_34"]={
    play={{19,96},{63,96},{132,19},{39,63},{19,63,96}},
    hunt={{pred=17,prey=19,name="Pidgeotto / Rattata"},{pred=17,prey=63,name="Pidgeotto / Abra"}},
    rival={{20,19}},
  },
  ["ROUTE_35"]={
    play={{32,29},{96,32},{96,29},{16,32},{16,29},{193,16},{32,29,96}},
    hunt={{pred=17,prey=32,name="Pidgeotto / Nidoran_M"},{pred=17,prey=29,name="Pidgeotto / Nidoran_F"},{pred=17,prey=96,name="Pidgeotto / Drowzee"}},
    rival={{33,32},{30,29}},
  },
  ["NATIONAL_PARK"]={
    play={{32,29},{10,13},{165,10},{191,10},{16,191},{10,13,165},{33,32,29},{30,29,32}},
    hunt={{pred=16,prey=10,name="Pidgey / Caterpie"},{pred=16,prey=13,name="Pidgey / Weedle"},{pred=167,prey=10,name="Spinarak / Caterpie"},{pred=48,prey=10,name="Venonat / Caterpie"}},
    rival={{33,32},{30,29}},
  },
  ["ROUTE_36"]={
    play={{32,29},{234,32},{234,29},{58,234},{37,234},{16,32},{32,29,234}},
    hunt={{pred=58,prey=19,name="Growlithe / Rattata"},{pred=37,prey=19,name="Vulpix / Rattata"}},
    rival={{33,32},{30,29}},
  },
  ["ROUTE_37"]={
    play={{234,234},{58,234},{37,234},{16,234},{163,234},{58,37,234}},
    hunt={{pred=58,prey=19,name="Growlithe / Rattata"},{pred=37,prey=19,name="Vulpix / Rattata"}},
    rival={{164,163}},
  },
  ["ROUTE_38"]={
    play={{209,52},{209,19},{52,19},{81,209},{241,209},{128,209},{209,52,19},{20,19,52}},
    hunt={{pred=52,prey=19,name="Meowth / Rattata"}},
    rival={{20,19},{53,52}},
  },
  ["ROUTE_39"]={
    play={{209,52},{52,19},{241,209},{128,209},{241,241,128},{209,52,19}},
    hunt={{pred=52,prey=19,name="Meowth / Rattata"}},
    rival={{20,19},{53,52}},
  },
  ["ROUTE_40"]={
    play={{19,21},{81,19},{21,81}},
    hunt={{pred=21,prey=19,name="Spearow / Rattata"}},
    rival={{20,19}},
  },
  ["ROUTE_41"]={
    play={},
    hunt={},
    rival={},
  },
  ["ROUTE_42"]={
    play={{179,56},{179,21},{179,41},{56,21},{56,41},{179,56,21},{180,179,179}},
    hunt={{pred=21,prey=19,name="Spearow / Rattata"},{pred=42,prey=19,name="Golbat / Rattata"}},
    rival={{180,179},{57,56},{42,41}},
  },
  ["MOUNT_MORTAR"]={
    play={{66,74},{66,41},{74,19},{183,66},{183,74},{66,74,183},{67,66,74}},
    hunt={{pred=42,prey=19,name="Golbat / Rattata"}},
    rival={{67,66},{75,74},{42,41},{20,19}},
  },
  ["ROUTE_43"]={
    play={{179,203},{179,48},{203,48},{16,179},{180,179,203}},
    hunt={{pred=17,prey=48,name="Pidgeotto / Venonat"}},
    rival={{180,179},{49,48}},
  },
  ["LAKE_OF_RAGE"]={
    play={{48,203},{16,48},{203,16}},
    hunt={{pred=17,prey=48,name="Pidgeotto / Venonat"}},
    rival={{49,48}},
  },
  ["ROUTE_44"]={
    play={{69,114},{108,114},{223,114},{69,108},{69,114,108},{70,69,114}},
    hunt={},
    rival={{70,69}},
  },
  ["ICE_PATH"]={
    play={{220,220},{220,225},{220,215},{225,225},{220,220,225},{221,220,220}},
    hunt={{pred=215,prey=220,name="Sneasel / Swinub"},{pred=215,prey=225,name="Sneasel / Delibird"}},
    rival={{221,220},{42,41}},
  },
  ["ROUTE_45"]={
    play={{74,231},{231,207},{216,231},{227,231},{74,231,207},{232,231,74}},
    hunt={{pred=227,prey=231,name="Skarmory / Phanpy"}},
    rival={{75,74},{232,231}},
  },
  ["DARK_CAVE_BLACKTHORN"]={
    play={{74,216},{74,41},{216,41},{216,74,41},{217,216,74}},
    hunt={{pred=42,prey=19,name="Golbat / Rattata"}},
    rival={{75,74},{42,41},{217,216}},
  },
  ["ROUTE_46"]={
    play={{74,19},{21,19},{231,74},{216,74},{74,19,231}},
    hunt={{pred=21,prey=19,name="Spearow / Rattata"}},
    rival={{75,74},{20,19}},
  },
  ["DARK_CAVE_VIOLET"]={
    play={{74,41},{216,74},{206,74},{216,74,41}},
    hunt={},
    rival={{75,74},{42,41}},
  },
  ["SPROUT_TOWER"]={
    play={{19,19},{19,92},{19,19,92}},
    hunt={{pred=92,prey=19,name="Gastly / Rattata"}},
    rival={{20,19}},
  },
  ["RUINS_OF_ALPH"]={
    play={{177,235},{177,194},{235,194},{177,235,194},{195,194,177}},
    hunt={},
    rival={{195,194}},
  },
  ["UNION_CAVE"]={
    play={{74,27},{74,19},{27,19},{194,74},{194,27},{74,27,194},{75,74,27}},
    hunt={{pred=42,prey=19,name="Golbat / Rattata"}},
    rival={{75,74},{42,41},{20,19}},
  },
  ["SLOWPOKE_WELL"]={
    play={{79,79},{79,41},{79,79,41},{42,41,79}},
    hunt={{pred=42,prey=79,name="Golbat / Slowpoke"}},
    rival={{42,41}},
  },
  ["BURNED_TOWER"]={
    play={{19,41},{19,109},{41,109},{19,41,109},{42,41,109}},
    hunt={{pred=42,prey=19,name="Golbat / Rattata"}},
    rival={{20,19},{42,41},{110,109}},
  },
  ["ROUTE_27"]={
    play={{19,77},{84,77},{77,77},{84,19},{77,84,19},{78,77,84}},
    hunt={{pred=84,prey=19,name="Doduo / Rattata"}},
    rival={{20,19},{78,77}},
  },
  ["TOHJO_FALLS"]={
    play={{19,41},{79,19},{41,79},{79,19,41}},
    hunt={{pred=42,prey=19,name="Golbat / Rattata"}},
    rival={{42,41},{20,19}},
  },
  ["ROUTE_26"]={
    play={{84,77},{19,84},{77,19},{84,77,19},{78,77,84}},
    hunt={{pred=84,prey=19,name="Doduo / Rattata"}},
    rival={{20,19},{78,77}},
  },
  ["VICTORY_ROAD"]={
    play={{74,111},{74,41},{111,41},{74,111,41},{75,74,111}},
    hunt={{pred=42,prey=19,name="Golbat / Rattata"}},
    rival={{75,74},{42,41},{112,111}},
  },
  ["ROUTE_23"]={
    play={},
    hunt={},
    rival={},
  },
  ["ROUTE_28"]={
    play={{77,114},{84,77},{215,114},{77,84,114},{78,77,84}},
    hunt={{pred=215,prey=114,name="Sneasel / Tangela"}},
    rival={{78,77}},
  },
  ["MT_SILVER_OUTSIDE"]={
    play={{77,114},{84,77},{215,84},{77,84,114},{78,77,84}},
    hunt={{pred=215,prey=84,name="Sneasel / Doduo"}},
    rival={{78,77}},
  },
  ["MT_SILVER_CAVE"]={
    play={{74,246},{246,216},{74,216},{246,74,216},{75,74,246},{217,216,246}},
    hunt={{pred=215,prey=246,name="Sneasel / Larvitar"},{pred=42,prey=246,name="Golbat / Larvitar"}},
    rival={{75,74},{42,41},{217,216},{247,246}},
  },
  ["ROUTE_1"]={
    play={{19,16},{19,161},{16,161},{19,16,161},{17,16,19}},
    hunt={{pred=17,prey=19,name="Pidgeotto / Rattata"},{pred=17,prey=161,name="Pidgeotto / Sentret"}},
    rival={{20,19},{17,16}},
  },
  ["ROUTE_2"]={
    play={{19,16},{10,16},{13,16},{163,19},{10,13,16},{17,16,19}},
    hunt={{pred=17,prey=10,name="Pidgeotto / Caterpie"},{pred=17,prey=13,name="Pidgeotto / Weedle"},{pred=164,prey=19,name="Noctowl / Rattata"}},
    rival={{20,19},{17,16},{164,163}},
  },
  ["ROUTE_3"]={
    play={{19,21},{23,19},{27,19},{21,23},{19,21,27}},
    hunt={{pred=23,prey=19,name="Ekans / Rattata"},{pred=21,prey=19,name="Spearow / Rattata"}},
    rival={{20,19}},
  },
  ["MT_MOON"]={
    play={{41,74},{27,74},{35,41},{41,74,35},{42,41,74}},
    hunt={{pred=42,prey=19,name="Golbat / Rattata"}},
    rival={{42,41},{75,74}},
  },
  ["ROUTE_4"]={
    play={{19,21},{23,19},{27,19},{21,27},{19,21,27}},
    hunt={{pred=23,prey=19,name="Ekans / Rattata"},{pred=21,prey=19,name="Spearow / Rattata"}},
    rival={{20,19}},
  },
  ["ROUTE_5"]={
    play={{16,52},{52,63},{16,63},{163,52},{16,52,63}},
    hunt={{pred=52,prey=19,name="Meowth / Rattata"},{pred=17,prey=19,name="Pidgeotto / Rattata"}},
    rival={{53,52},{17,16}},
  },
  ["ROUTE_6"]={
    play={{16,52},{52,63},{69,52},{43,52},{16,52,69}},
    hunt={{pred=52,prey=19,name="Meowth / Rattata"},{pred=17,prey=19,name="Pidgeotto / Rattata"}},
    rival={{53,52},{17,16}},
  },
  ["ROUTE_7"]={
    play={{52,198},{228,198},{52,228},{209,52},{52,228,198}},
    hunt={{pred=228,prey=19,name="Houndour / Rattata"},{pred=198,prey=19,name="Murkrow / Rattata"}},
    rival={{53,52},{229,228}},
  },
  ["ROUTE_8"]={
    play={{58,63},{37,63},{58,209},{37,209},{58,63,209}},
    hunt={{pred=58,prey=19,name="Growlithe / Rattata"},{pred=37,prey=19,name="Vulpix / Rattata"}},
    rival={{59,58},{38,37}},
  },
  ["ROUTE_9"]={
    play={{19,21},{19,56},{21,56},{19,21,56},{57,56,21}},
    hunt={{pred=21,prey=19,name="Spearow / Rattata"}},
    rival={{20,19},{57,56},{22,21}},
  },
  ["ROUTE_10"]={
    play={{100,21},{19,100},{81,100},{21,81},{100,81,21}},
    hunt={{pred=21,prey=19,name="Spearow / Rattata"}},
    rival={{101,100},{82,81}},
  },
  ["ROCK_TUNNEL"]={
    play={{41,74},{66,74},{104,74},{66,104},{41,66,74},{67,66,74}},
    hunt={{pred=42,prey=104,name="Golbat / Cubone"}},
    rival={{42,41},{75,74},{67,66},{105,104}},
  },
  ["ROUTE_11"]={
    play={{96,19},{81,96},{19,81},{96,19,81}},
    hunt={},
    rival={{20,19},{82,81},{97,96}},
  },
  ["ROUTE_12"]={
    play={{69,43},{69,48},{43,48},{69,43,48},{70,69,43}},
    hunt={{pred=48,prey=69,name="Venonat / Bellsprout"}},
    rival={{70,69},{44,43},{49,48}},
  },
  ["ROUTE_13"]={
    play={{69,43},{187,69},{187,43},{32,29},{69,43,187}},
    hunt={{pred=17,prey=187,name="Pidgeotto / Hoppip"}},
    rival={{70,69},{44,43},{33,32},{30,29}},
  },
  ["ROUTE_14"]={
    play={{32,29},{187,32},{187,29},{132,187},{32,29,187}},
    hunt={{pred=17,prey=187,name="Pidgeotto / Hoppip"}},
    rival={{33,32},{30,29}},
  },
  ["ROUTE_15"]={
    play={{32,29},{187,32},{187,29},{132,187},{32,29,187}},
    hunt={{pred=17,prey=187,name="Pidgeotto / Hoppip"}},
    rival={{33,32},{30,29}},
  },
  ["ROUTE_16"]={
    play={{88,198},{198,218},{88,218},{198,88,218}},
    hunt={{pred=198,prey=19,name="Murkrow / Rattata"}},
    rival={{89,88},{219,218}},
  },
  ["ROUTE_17"]={
    play={{88,218},{88,88},{218,218},{88,88,218},{89,88,218}},
    hunt={},
    rival={{89,88},{219,218}},
  },
  ["ROUTE_18"]={
    play={{88,218},{19,88},{19,218},{19,88,218}},
    hunt={},
    rival={{89,88},{20,19},{219,218}},
  },
  ["ROUTE_19"]={
    play={},
    hunt={},
    rival={},
  },
  ["ROUTE_20"]={
    play={},
    hunt={},
    rival={},
  },
  ["ROUTE_21"]={
    play={{19,114},{16,114},{19,16,114},{17,16,19}},
    hunt={{pred=17,prey=19,name="Pidgeotto / Rattata"}},
    rival={{20,19},{17,16}},
  },
  ["ROUTE_22"]={
    play={{19,21},{60,19},{21,60},{19,21,60}},
    hunt={{pred=21,prey=19,name="Spearow / Rattata"}},
    rival={{20,19},{22,21}},
  },
  ["ROUTE_24"]={
    play={{10,13},{43,69},{63,10},{63,13},{10,13,63},{11,10,13}},
    hunt={{pred=17,prey=10,name="Pidgeotto / Caterpie"},{pred=17,prey=13,name="Pidgeotto / Weedle"}},
    rival={{11,10},{14,13},{44,43},{70,69}},
  },
  ["ROUTE_25"]={
    play={{10,13},{43,69},{63,43},{63,69},{10,13,63}},
    hunt={{pred=17,prey=10,name="Pidgeotto / Caterpie"},{pred=17,prey=13,name="Pidgeotto / Weedle"}},
    rival={{11,10},{14,13},{44,43},{70,69}},
  },
  ["DIGLETTS_CAVE"]={
    play={{50,50},{50,50,50},{51,50,50}},
    hunt={},
    rival={{51,50}},
  },
  ["VIRIDIAN_FOREST__SLASH__ROUTE_2_FOREST_AREA"]={
    play={{10,13},{10,16},{13,16},{163,10},{10,13,16},{11,10,10},{14,13,13}},
    hunt={{pred=16,prey=10,name="Pidgey / Caterpie"},{pred=16,prey=13,name="Pidgey / Weedle"},{pred=163,prey=10,name="Hoothoot / Caterpie"}},
    rival={{11,10},{14,13}},
  },
  ["CERULEAN_CAVE"]={
    play={},
    hunt={},
    rival={},
  },
  ["SEAFOAM_ISLANDS"]={
    play={},
    hunt={},
    rival={},
  },
}



-- MORNING/DAY/NIGHT availability from the user's spawns.txt. This does not
-- create new ecology actors or change touch/battle handling. It only filters
-- the existing PLAY / PREDATOR / ROUGH_PLAY groups so every participant is
-- actually available on the current map at the current time of day.
local SPAWN_AVAILABILITY={
  ["SPROUT_TOWER_2F"]={
    MORNING={19},
    DAY={19},
    NIGHT={92,19},
  },
  ["SPROUT_TOWER_3F"]={
    MORNING={19},
    DAY={19},
    NIGHT={92,19},
  },
  ["TIN_TOWER_2F"]={
    MORNING={19},
    DAY={19},
    NIGHT={92,19},
  },
  ["TIN_TOWER_3F"]={
    MORNING={19},
    DAY={19},
    NIGHT={92,19},
  },
  ["TIN_TOWER_4F"]={
    MORNING={19},
    DAY={19},
    NIGHT={92,19},
  },
  ["TIN_TOWER_5F"]={
    MORNING={19},
    DAY={19},
    NIGHT={92,19},
  },
  ["TIN_TOWER_6F"]={
    MORNING={19},
    DAY={19},
    NIGHT={92,19},
  },
  ["TIN_TOWER_7F"]={
    MORNING={19},
    DAY={19},
    NIGHT={92,19},
  },
  ["TIN_TOWER_8F"]={
    MORNING={19},
    DAY={19},
    NIGHT={92,19},
  },
  ["TIN_TOWER_9F"]={
    MORNING={19},
    DAY={19},
    NIGHT={92,19},
  },
  ["BURNED_TOWER_1F"]={
    MORNING={19,109,41,20},
    DAY={19,109,41,20},
    NIGHT={19,109,41,20},
  },
  ["BURNED_TOWER_B1F"]={
    MORNING={19,109,41,126},
    DAY={19,109,41,126},
    NIGHT={19,109,41,126},
  },
  ["NATIONAL_PARK"]={
    MORNING={10,11,13,14,16,165,32,29},
    DAY={10,11,13,14,16,191,32,29},
    NIGHT={163,54,167,48},
  },
  ["RUINS_OF_ALPH_OUTSIDE"]={
    MORNING={177,235},
    DAY={177,235},
    NIGHT={177,235,194,195},
  },
  ["RUINS_OF_ALPH_INNER_CHAMBER"]={
    MORNING={201},
    DAY={201},
    NIGHT={201},
  },
  ["UNION_CAVE_1F"]={
    MORNING={74,27,19,41,95},
    DAY={74,27,19,41,95},
    NIGHT={74,27,19,41,95,194},
  },
  ["UNION_CAVE_B1F"]={
    MORNING={74,27,19,41,95},
    DAY={74,27,19,41,95},
    NIGHT={74,27,19,41,95,194},
  },
  ["UNION_CAVE_B2F"]={
    MORNING={41,20,42,74,19,95},
    DAY={41,20,42,74,19,95},
    NIGHT={41,20,42,74,19,95,195},
  },
  ["SLOWPOKE_WELL_B1F"]={
    MORNING={41,79},
    DAY={41,79},
    NIGHT={41,79},
  },
  ["SLOWPOKE_WELL_B2F"]={
    MORNING={41,79,42},
    DAY={41,79,42},
    NIGHT={41,79,42},
  },
  ["ILEX_FOREST"]={
    MORNING={10,11,13,14,46,41,16},
    DAY={10,11,13,14,46,41,16},
    NIGHT={43,48,54,163,46,41},
  },
  ["MOUNT_MORTAR_1F_OUTSIDE"]={
    MORNING={19,41,66,42,74,20},
    DAY={19,41,66,42,74,20},
    NIGHT={19,41,183,42,74,20},
  },
  ["MOUNT_MORTAR_1F_INSIDE"]={
    MORNING={74,19,66,20,41,42},
    DAY={74,19,66,20,41,42},
    NIGHT={74,19,20,41,183,42},
  },
  ["MOUNT_MORTAR_2F_INSIDE"]={
    MORNING={75,67,74,20,66,42},
    DAY={75,67,74,20,66,42},
    NIGHT={75,74,20,42,183},
  },
  ["MOUNT_MORTAR_B1F"]={
    MORNING={41,42,66,74,20},
    DAY={41,42,66,74,20},
    NIGHT={41,42,183,74,20},
  },
  ["ICE_PATH_1F"]={
    MORNING={220,41,42},
    DAY={220,41,42},
    NIGHT={225,41,42},
  },
  ["ICE_PATH_B1F"]={
    MORNING={220,41,42,124},
    DAY={220,41,42,124},
    NIGHT={225,41,42,124,215},
  },
  ["ICE_PATH_B2F_MAHOGANY_SIDE"]={
    MORNING={220,41,42,124},
    DAY={220,41,42,124},
    NIGHT={225,41,42,124,215},
  },
  ["ICE_PATH_B2F_BLACKTHORN_SIDE"]={
    MORNING={220,41,42,124},
    DAY={220,41,42,124},
    NIGHT={225,41,42,124,215},
  },
  ["ICE_PATH_B3F"]={
    MORNING={220,41,42,124},
    DAY={220,41,42,124},
    NIGHT={225,41,42,124,215},
  },
  ["WHIRL_ISLAND_NW"]={
    MORNING={98,41,42,86},
    DAY={98,41,42,86},
    NIGHT={98,41,42,86},
  },
  ["WHIRL_ISLAND_NE"]={
    MORNING={98,41,42,86},
    DAY={98,41,42,86},
    NIGHT={98,41,42,86},
  },
  ["WHIRL_ISLAND_SW"]={
    MORNING={98,41,42,86},
    DAY={98,41,42,86},
    NIGHT={98,41,42,86},
  },
  ["WHIRL_ISLAND_CAVE"]={
    MORNING={98,41,42,86},
    DAY={98,41,42,86},
    NIGHT={98,41,42,86},
  },
  ["WHIRL_ISLAND_B1F"]={
    MORNING={98,41,42,86},
    DAY={98,41,42,86},
    NIGHT={98,41,42,86},
  },
  ["WHIRL_ISLAND_B2F"]={
    MORNING={98,41,42,86},
    DAY={98,41,42,86},
    NIGHT={98,41,42,86},
  },
  ["DARK_CAVE_VIOLET_ENTRANCE"]={
    MORNING={74,41,216,206},
    DAY={74,41,206},
    NIGHT={74,41,206},
  },
  ["DARK_CAVE_BLACKTHORN_ENTRANCE"]={
    MORNING={74,41,75,202,217,216,42},
    DAY={74,41,75,202,217,42},
    NIGHT={74,41,75,202,42},
  },
  ["ROUTE_29"]={
    MORNING={16,161,19,187},
    DAY={16,161,19,187},
    NIGHT={163,19},
  },
  ["ROUTE_30"]={
    MORNING={16,10,11,165,13,14,187},
    DAY={16,10,11,13,14,187},
    NIGHT={167,19,163,60,41},
  },
  ["ROUTE_31"]={
    MORNING={16,10,11,165,13,14,69,187},
    DAY={16,10,11,13,14,69,187},
    NIGHT={167,19,69,163,60,41,92},
  },
  ["ROUTE_32"]={
    MORNING={69,19,179,187,194,41,23,16},
    DAY={69,19,179,187,23,16},
    NIGHT={194,19,69,179,41,23,163,92},
  },
  ["ROUTE_33"]={
    MORNING={19,21,74,187,23},
    DAY={19,21,74,187,23},
    NIGHT={19,41,74},
  },
  ["ROUTE_34"]={
    MORNING={19,63,96,132},
    DAY={19,63,96,132},
    NIGHT={19,96,63,132},
  },
  ["ROUTE_35"]={
    MORNING={32,29,96,16,132,193},
    DAY={32,29,96,16,132,193},
    NIGHT={163,96,132,32,29,193},
  },
  ["ROUTE_36"]={
    MORNING={16,32,29,58,37,234},
    DAY={16,32,29,58,37,234},
    NIGHT={163,58,37,234},
  },
  ["ROUTE_37"]={
    MORNING={16,234,58,37,165},
    DAY={16,234,58,37,17},
    NIGHT={163,234,58,37,167},
  },
  ["ROUTE_38"]={
    MORNING={19,52,20,81,83,241,128,209},
    DAY={19,52,20,81,83,241,128,209},
    NIGHT={19,52,20,81,241,128,209},
  },
  ["ROUTE_39"]={
    MORNING={19,52,20,81,83,241,128},
    DAY={19,52,20,81,83,241,128},
    NIGHT={19,52,20,81,241,128},
  },
  ["ROUTE_42"]={
    MORNING={21,19,56,179,180},
    DAY={21,19,56,179,180},
    NIGHT={19,41,42,179,180},
  },
  ["ROUTE_43"]={
    MORNING={203,179,180,48,17},
    DAY={203,179,180,48,17},
    NIGHT={48,164,203,179,180},
  },
  ["ROUTE_44"]={
    MORNING={114,70,69,108},
    DAY={114,70,69,108},
    NIGHT={114,70,69,108},
  },
  ["ROUTE_45"]={
    MORNING={74,75,207,216,231,227},
    DAY={74,75,207,216,231,227},
    NIGHT={74,75,207,216,231,227},
  },
  ["ROUTE_46"]={
    MORNING={74,21,19,39},
    DAY={74,21,19,39},
    NIGHT={74,19,39},
  },
  ["SILVER_CAVE_OUTSIDE"]={
    MORNING={114,77,217,232,78,84,85},
    DAY={114,77,217,232,78,84,85},
    NIGHT={114,77,217,232,78,215},
  },
  ["SILVER_CAVE_ROOM_1"]={
    MORNING={42,75,217,232,67},
    DAY={42,75,217,232,67},
    NIGHT={42,75,217,232,215},
  },
  ["SILVER_CAVE_ROOM_2"]={
    MORNING={42,75,95,217,232},
    DAY={42,75,95,217,232},
    NIGHT={42,75,95,217,232,215},
  },
  ["SILVER_CAVE_ROOM_3"]={
    MORNING={42,75,95,217,232},
    DAY={42,75,95,217,232},
    NIGHT={42,75,95,217,232,215},
  },
  ["DIGLETTS_CAVE"]={
    MORNING={50,51},
    DAY={50,51},
    NIGHT={50,51},
  },
  ["MOUNT_MOON"]={
    MORNING={41,74,27,46,28,35},
    DAY={41,74,27,46,28,35},
    NIGHT={41,74,27,46,28,35},
  },
  ["ROCK_TUNNEL_1F"]={
    MORNING={41,74,66,104,75},
    DAY={41,74,66,104,75},
    NIGHT={41,74,66,104,75},
  },
  ["ROCK_TUNNEL_B1F"]={
    MORNING={41,74,66,104,75,115},
    DAY={41,74,66,104,75,115},
    NIGHT={41,74,66,104,75,115},
  },
  ["VICTORY_ROAD"]={
    MORNING={42,75,95,111,112},
    DAY={42,75,95,111,112},
    NIGHT={42,75,95,111,112},
  },
  ["TOHJO_FALLS"]={
    MORNING={41,20,42,79,19},
    DAY={41,20,42,79,19},
    NIGHT={41,20,42,79,19},
  },
  ["ROUTE_1"]={
    MORNING={16,19,161,162},
    DAY={16,19,161,162},
    NIGHT={163,19,20},
  },
  ["ROUTE_2"]={
    MORNING={10,11,12,13,14,15,16,17,165,166,25},
    DAY={10,11,13,14,16,17,25,12},
    NIGHT={163,167,164,168,25},
  },
  ["ROUTE_3"]={
    MORNING={21,19,23,24,27,20},
    DAY={21,19,23,24,27,20},
    NIGHT={19,20,41,35},
  },
  ["ROUTE_4"]={
    MORNING={19,21,23,27,24,20},
    DAY={19,21,23,27,24,20},
    NIGHT={19,20,41},
  },
  ["ROUTE_5"]={
    MORNING={16,69,43,52},
    DAY={16,69,43,52},
    NIGHT={163,69,43,52},
  },
  ["ROUTE_6"]={
    MORNING={19,69,43,52},
    DAY={19,69,43,52},
    NIGHT={19,69,43,52},
  },
  ["ROUTE_7"]={
    MORNING={19,21,58,37,198,228},
    DAY={19,21,58,37},
    NIGHT={19,198,228,58,37},
  },
  ["ROUTE_8"]={
    MORNING={16,19,58,37,63,64},
    DAY={16,19,58,37,63,64},
    NIGHT={163,19,58,37,63,93},
  },
  ["ROUTE_9"]={
    MORNING={19,21,22,20},
    DAY={19,21,22,20},
    NIGHT={19,20,48,49},
  },
  ["ROUTE_10_NORTH"]={
    MORNING={21,100,19,22,125},
    DAY={21,100,19,22,125},
    NIGHT={19,100,20,125},
  },
  ["ROUTE_11"]={
    MORNING={19,96,81,20},
    DAY={19,96,81,20},
    NIGHT={19,96,81,20,97},
  },
  ["ROUTE_13"]={
    MORNING={32,29,16,187,188},
    DAY={32,29,16,187,188},
    NIGHT={32,29,163,195},
  },
  ["ROUTE_14"]={
    MORNING={32,29,16,188},
    DAY={32,29,16,188},
    NIGHT={32,29,163,195},
  },
  ["ROUTE_15"]={
    MORNING={32,29,16,187,188},
    DAY={32,29,16,187,188},
    NIGHT={32,29,163,195},
  },
  ["ROUTE_16"]={
    MORNING={88,89,22,218,198},
    DAY={88,89,22,218},
    NIGHT={88,89,198,218},
  },
  ["ROUTE_17"]={
    MORNING={88,89,22,218},
    DAY={88,89,22,218},
    NIGHT={88,89,198,218},
  },
  ["ROUTE_18"]={
    MORNING={19,20,22,84},
    DAY={19,20,22,84},
    NIGHT={19,20},
  },
  ["ROUTE_21"]={
    MORNING={114,19,20,122},
    DAY={114,19,20,122},
    NIGHT={114,19,20,122},
  },
  ["ROUTE_22"]={
    MORNING={19,21,77,84},
    DAY={19,21,77,84},
    NIGHT={19,60},
  },
  ["ROUTE_24"]={
    MORNING={69,43,16,191,63},
    DAY={69,43,16,191,63},
    NIGHT={69,43,163,48,63},
  },
  ["ROUTE_25"]={
    MORNING={69,43,16,191,63},
    DAY={69,43,16,191,63},
    NIGHT={69,43,163,48,63},
  },
  ["ROUTE_26"]={
    MORNING={20,84,24,28,77},
    DAY={20,84,24,28,77},
    NIGHT={20,164,24,28},
  },
  ["ROUTE_27"]={
    MORNING={20,84,24,28,77},
    DAY={20,84,24,28,77},
    NIGHT={20,164,24,28},
  },
  ["ROUTE_28"]={
    MORNING={114,77,78,84,85,217,232},
    DAY={114,77,78,84,85,217,232},
    NIGHT={114,77,78,215,217,232},
  },
  ["VIRIDIAN_FOREST__SLASH__ROUTE_2_FOREST_AREA"]={
    MORNING={10,11,12,13,14,15,16,165,166,25},
    DAY={10,11,12,13,14,16,17,25},
    NIGHT={163,167,164,168,25},
  },
}

local function spawnAvailabilityMapKey(map)
  if not map then return nil end
  local id=tostring(map.id or (map.def and map.def.id) or ""):upper()
  -- Exact/submap keys first (tower floors, cave floors/sides, etc.).
  local best=nil
  for k in pairs(SPAWN_AVAILABILITY) do
    local raw=k:gsub("__SLASH__","_")
    if id==raw or id:find(raw,1,true) then
      if not best or #k>#best then best=k end
    end
  end
  if best then return best end
  -- Common engine aliases.
  if id:find("MT_MOON",1,true) then return "MOUNT_MOON" end
  if id:find("MT_SILVER",1,true) then
    if id:find("OUTSIDE",1,true) then return "SILVER_CAVE_OUTSIDE" end
    if id:find("ROOM_1",1,true) then return "SILVER_CAVE_ROOM_1" end
    if id:find("ROOM_2",1,true) then return "SILVER_CAVE_ROOM_2" end
    if id:find("ROOM_3",1,true) then return "SILVER_CAVE_ROOM_3" end
  end
  if id:find("VIRIDIAN_FOREST",1,true) or id:find("ROUTE_2_FOREST",1,true) then
    return "VIRIDIAN_FOREST__SLASH__ROUTE_2_FOREST_AREA"
  end
  return nil
end

local function availabilityResolverHas(mapId,dex)
  if not (mod.world and type(mod.world.effectiveEncounters)=="function") then return false end
  local ok,res=pcall(mod.world.effectiveEncounters,mod.world,mapId,"grass")
  if not (ok and type(res)=="table") then return false end
  local api=mod.exports and (mod.exports.cobblemon_main or mod.exports.cobblemon_importer)
  for species in pairs(res.dist or {}) do
    local d=nil
    if api and type(api.dexOfSpecies)=="function" then
      local ok2,v=pcall(api.dexOfSpecies,species); if ok2 then d=tonumber(v) end
    end
    if not d then d=tonumber(species) end
    if d and math.floor(d)==dex then return true end
  end
  return false
end

local function currentEcologyDayPart()
  -- Same native encounter clock probe already used by the stable overworld code.
  if availabilityResolverHas("ROUTE_29",163) then return "NIGHT" end
  if availabilityResolverHas("ROUTE_30",165) then return "MORNING" end
  return "DAY"
end

local function currentAvailability(map)
  local key=spawnAvailabilityMapKey(map)
  local row=key and SPAWN_AVAILABILITY[key] or nil
  if not row then return nil,key end
  local list=row[currentEcologyDayPart()] or row.DAY or row.MORNING or row.NIGHT or {}
  local set={}
  for _,dex in ipairs(list) do set[dex]=true end
  return set,key
end

local function filterEcologyPools(map,playPool,huntPool,rivalPool)
  local allowed=select(1,currentAvailability(map))
  if not allowed then return playPool,huntPool,rivalPool end
  local p,h,r={},{},{}
  for _,g in ipairs(playPool or {}) do
    local ok=true; for _,dex in ipairs(g) do if not allowed[dex] then ok=false;break end end
    if ok then p[#p+1]=g end
  end
  for _,pair in ipairs(huntPool or {}) do
    if allowed[pair.pred] and allowed[pair.prey] then h[#h+1]=pair end
  end
  for _,pair in ipairs(rivalPool or {}) do
    if allowed[pair[1]] and allowed[pair[2]] then r[#r+1]=pair end
  end
  return p,h,r
end

local function ecologyMapKey(map)
  if not map then return nil end
  local id=tostring(map.id or (map.def and map.def.id) or ""):upper()

  -- Routes are exact and intentionally do not share one global route pool.
  local r=id:match("(ROUTE_?%d+)")
  if r and ROUTE_ECOLOGY[r] then return r end

  if id:find("ILEX_FOREST",1,true) then return "ILEX_FOREST" end
  if id:find("NATIONAL_PARK",1,true) then return "NATIONAL_PARK" end
  if id:find("LAKE_OF_RAGE",1,true) then return "LAKE_OF_RAGE" end
  if id:find("ICE_PATH",1,true) then return "ICE_PATH" end
  if id:find("SPROUT_TOWER",1,true) then return "SPROUT_TOWER" end
  if id:find("RUINS_OF_ALPH",1,true) then return "RUINS_OF_ALPH" end
  if id:find("UNION_CAVE",1,true) then return "UNION_CAVE" end
  if id:find("SLOWPOKE_WELL",1,true) then return "SLOWPOKE_WELL" end
  if id:find("BURNED_TOWER",1,true) then return "BURNED_TOWER" end
  if id:find("TOHJO_FALLS",1,true) then return "TOHJO_FALLS" end
  if id:find("VICTORY_ROAD",1,true) then return "VICTORY_ROAD" end
  if id:find("DIGLETTS_CAVE",1,true) then return "DIGLETTS_CAVE" end
  if id:find("ROCK_TUNNEL",1,true) then return "ROCK_TUNNEL" end
  if id:find("MT_MOON",1,true) then return "MT_MOON" end
  if id:find("CERULEAN_CAVE",1,true) then return "CERULEAN_CAVE" end
  if id:find("SEAFOAM",1,true) then return "SEAFOAM_ISLANDS" end

  if id:find("MT_MORTAR",1,true) or id:find("MOUNT_MORTAR",1,true) then
    return "MOUNT_MORTAR"
  end

  if id:find("DARK_CAVE",1,true) then
    if id:find("BLACKTHORN",1,true) then return "DARK_CAVE_BLACKTHORN" end
    if id:find("VIOLET",1,true) then return "DARK_CAVE_VIOLET" end
    -- Gen2 Dark Cave maps without a side suffix: keep the Violet-side list as
    -- the conservative default until the engine exposes a more specific ID.
    return "DARK_CAVE_VIOLET"
  end

  if id:find("MT_SILVER",1,true) then
    if id:find("OUTSIDE",1,true) then return "MT_SILVER_OUTSIDE" end
    return "MT_SILVER_CAVE"
  end

  if id:find("VIRIDIAN_FOREST",1,true) or id:find("ROUTE_2_FOREST",1,true) then
    return "VIRIDIAN_FOREST__SLASH__ROUTE_2_FOREST_AREA"
  end

  return nil
end

local function ecologyData(map)
  local key=ecologyMapKey(map)
  return key and ROUTE_ECOLOGY[key] or nil,key
end

local events={}
local MAX_EVENTS=3
local event=nil
local clock=4.0
local mapId=nil
local Voxel3D=nil
local BLACK=nil
local servicesReady=false
local battleLock=false

local function rnd(a,b) return (love and love.math and love.math.random) and love.math.random(a,b) or math.random(a,b) end
local function rnd01() return (love and love.math and love.math.random) and love.math.random() or math.random() end
local function importer()
  local a=mod.exports and (mod.exports.cobblemon_main or mod.exports.cobblemon_importer)
  return a
end
local function wildAPI() return mod.exports and mod.exports.cobblemon_overworld_wilds or {} end
local function companion() return mod.exports and mod.exports.voxel_companion end
local function enabled() return groundEcologyEnabled() end
local function playerCell(ow)
  local p=ow and ow.player
  return p and tonumber(p.cellX),p and tonumber(p.cellY or p.cellZ)
end
local function biome(map)
  if not map then return nil end
  local id=tostring(map.id or (map.def and map.def.id) or ""):upper()
  local ts=tostring((map.def and map.def.tileset) or map.tileset or ""):upper()

  -- Both Johto and Kanto route IDs in the Gen2 recomp use ROUTE_##.
  if id:match("^ROUTE_?%d+") then return "route" end
  if id:find("NATIONAL_PARK",1,true) then return "route" end

  if id:find("ILEX_FOREST",1,true) or id:find("FOREST",1,true)
     or ts:find("FOREST",1,true) then return "forest" end

  if id:find("DARK_CAVE",1,true) or id:find("UNION_CAVE",1,true)
     or id:find("SLOWPOKE_WELL",1,true) or id:find("WHIRL_ISLAND",1,true)
     or id:find("ICE_PATH",1,true) or id:find("MT_MORTAR",1,true)
     or id:find("MT_SILVER",1,true) or id:find("VICTORY_ROAD",1,true)
     or id:find("ROCK_TUNNEL",1,true) or id:find("MT_MOON",1,true)
     or id:find("CERULEAN_CAVE",1,true) or id:find("CAVE",1,true)
     or ts:find("CAVE",1,true) or ts:find("CAVERN",1,true) then return "cave" end

  -- Burned Tower behaves more like a ruin/cave for ambient ecology.
  if id:find("BURNED_TOWER",1,true) then return "cave" end

  if ts=="INTERIOR" or ts=="HOUSE" or ts=="FACILITY" or ts=="MANSION"
     or id:find("GATE",1,true) or id:find("BUILDING",1,true) then return "building" end
  return nil
end
local function route(map) return biome(map)=="route" end
local function walkable(map,x,z)
  return map and map.inBounds and map:inBounds(x,z) and map.isWalkableCell and map:isWalkableCell(x,z)
end
local function treeEdge(map,x,z)
  if not walkable(map,x,z) then return false end
  local dirs={{1,0},{-1,0},{0,1},{0,-1}}
  for _,d in ipairs(dirs) do
    local nx,nz=x+d[1],z+d[2]
    if map.inBounds and map:inBounds(nx,nz) and not walkable(map,nx,nz) then return true end
  end
  return false
end
local function nearestTreeEdge(map,cx,cz,radius)
  local bestX,bestZ,bestD=nil,nil,nil
  radius=radius or ECOLOGY_EXIT_TREE_RADIUS
  for dz=-radius,radius do
    for dx=-radius,radius do
      local d=math.abs(dx)+math.abs(dz)
      if d>0 and d<=radius then
        local x,z=cx+dx,cz+dz
        if treeEdge(map,x,z) then
          if not bestD or d<bestD then bestX,bestZ,bestD=x,z,d end
        end
      end
    end
  end
  return bestX,bestZ
end
local function beginTreeExit(ow,ev)
  if not ev or ev.exiting then return end
  ev.exiting=true;ev.exitTimer=ECOLOGY_EXIT_TIMEOUT
  for idx,m in ipairs(ev.members or {}) do
    if not (m.flyingClaimed or m.carried) then
      local tx,tz=nearestTreeEdge(ow.map,m.cx,m.cz,ECOLOGY_EXIT_TREE_RADIUS)
      if tx then
        -- Stagger group destinations where possible so they do not stack.
        if idx>1 then
          local dirs={{1,0},{-1,0},{0,1},{0,-1}}
          local d=dirs[((idx-2)%#dirs)+1]
          local ax,az=tx+d[1],tz+d[2]
          if treeEdge(ow.map,ax,az) then tx,tz=ax,az end
        end
        m.tx,m.tz=tx*CELL+8,tz*CELL+8;m.mode="tree_exit";m.exitTreeX=tx;m.exitTreeZ=tz
      else
        m.mode="exit" -- existing off-screen/away fallback when no foliage edge exists
        m.tx,m.tz=nil,nil
      end
    end
  end
end
local function occupied(ow,x,z)
  local px,pz=playerCell(ow); if px==x and pz==z then return true end
  for _,e in ipairs(ow and ow.entities or {}) do
    if tonumber(e.cellX)==x and tonumber(e.cellY or e.cellZ)==z then return true end
  end
  return false
end
local function pos(cx,cz,y) return cx*CELL+8,y or 0,cz*CELL+8 end
local function candidate(ow)
  local px,pz=playerCell(ow); if not px then return nil end
  for _=1,100 do
    local dx,dz=rnd(-MAX_R,MAX_R),rnd(-MAX_R,MAX_R)
    local d=math.abs(dx)+math.abs(dz)
    local x,z=px+dx,pz+dz
    if d>=MIN_R and d<=MAX_R and walkable(ow.map,x,z) and not occupied(ow,x,z) then return x,z end
  end
end
local function makeActor(dex,cx,cz,y)
  local api=importer(); if not api or type(api.createActor)~="function" then return nil end
  local x,yy,z=pos(cx,cz,y)
  local a=api.createActor(dex,{manual=true,visible=false,x=x,y=yy,z=z})
  if not a then return nil end
  if a.setGroundY then a:setGroundY(yy) end
  a:setAnimation("idle"); a:setVisible(false)
  return {dex=dex,actor=a,x=x,y=yy,z=z,groundY=yy,cx=cx,cz=cz,tx=nil,tz=nil,mode="idle",
          timer=0,contact=false,phase=rnd01()*6.28,
          randomFlight=nil,
          flightCooldown=RANDOM_FLY_MIN_GAP+rnd01()*(RANDOM_FLY_MAX_GAP-RANDOM_FLY_MIN_GAP)}
end
local function destroyMember(m)
  if m and m.actor then pcall(function() m.actor:destroy() end); m.actor=nil end
end
local function clear()
  for _,e in ipairs(events) do
    for _,m in ipairs(e.members or {}) do destroyMember(m) end
  end
  events={}
  battleLock=false
end
local function black()
  if BLACK then return BLACK end
  if not (love and love.image and love.graphics) then return nil end
  local ok,d=pcall(love.image.newImageData,1,1); if not ok then return nil end
  pcall(d.setPixel,d,0,0,0,0,0,1)
  local ok2,i=pcall(love.graphics.newImage,d); if ok2 then BLACK=i end
  return BLACK
end
local function draw(m)
  if not (m.actor and Voxel3D and type(Voxel3D.draw)=="function") then return end
  local mat=m.actor:matrix()
  local b=black()
  local api=importer()
  local outline=not api or type(api.outlineEnabled)~="function" or api.outlineEnabled()
  if outline and b and love.graphics.setDepthMode then
    pcall(love.graphics.setDepthMode,"lequal",false)
    for _,p in ipairs(m.actor.rig.parts or {}) do if p.outlineMesh then pcall(Voxel3D.draw,p.outlineMesh,b,mat,0,mat) end end
    pcall(love.graphics.setDepthMode,"lequal",true)
  end
  for _,p in ipairs(m.actor.rig.parts or {}) do if p.mesh and p.texture then pcall(Voxel3D.draw,p.mesh,p.texture,mat,0,mat) end end
end
local function setTarget(m,cx,cz)
  m.tcx,m.tcz=cx,cz
  m.tx,m.ty,m.tz=pos(cx,cz,m.y)
end
local function moveToward(m,dt,speed)
  if not m.tx then return true end
  local dx,dz=m.tx-m.x,m.tz-m.z
  local d=math.sqrt(dx*dx+dz*dz)
  if d<0.5 then
    m.x,m.z=m.tx,m.tz; m.cx,m.cz=m.tcx,m.tcz
    m.tx,m.tz=nil,nil; return true
  end
  local q=math.min(d,speed*dt)
  m.x=m.x+dx/d*q; m.z=m.z+dz/d*q
  m.actor:setYaw(math.atan2(dx,dz))
  return false
end
local function randomStep(ow,m)
  local dirs={{1,0},{-1,0},{0,1},{0,-1}}
  for _=1,8 do
    local d=dirs[rnd(1,4)]; local x,z=m.cx+d[1],m.cz+d[2]
    if walkable(ow.map,x,z) and not occupied(ow,x,z) then setTarget(m,x,z); return end
  end
end
local function awayStep(ow,m,px,pz)
  local best,score=nil,-1e9
  for _,d in ipairs({{1,0},{-1,0},{0,1},{0,-1}}) do
    local x,z=m.cx+d[1],m.cz+d[2]
    if walkable(ow.map,x,z) then
      local s=(x-px)^2+(z-pz)^2+rnd01()
      if s>score then score=s;best={x,z} end
    end
  end
  if best then setTarget(m,best[1],best[2]) end
end

local function spawn(ow,world)
  if not groundEcologyEnabled() then return false end
  local bio=biome(ow.map)
  if not bio then return false end

  local mapData,mapKey=ecologyData(ow.map)
  -- If this map is in the supplied per-map table, use only that table.
  -- Empty tables intentionally mean "no ecology here".
  if mapKey and mapData and #(mapData.play or {})==0
     and #(mapData.hunt or {})==0 and #(mapData.rival or {})==0 then
    return false
  end

  local cx,cz=candidate(ow); if not cx then return false end
  local y=(world and world.player and world.player.y) or 0
  local e={members={},age=0,battlePause=false,biome=bio,mapKey=mapKey}

  local playPool=mapData and mapData.play or nil
  local huntPool=mapData and mapData.hunt or nil
  local rivalPool=mapData and mapData.rival or nil

  -- Maps not present in the supplied table retain the old biome fallback.
  if not mapData then
    huntPool=PREDATOR_PREY_BY_BIOME[bio] or PREDATOR_PREY_BY_BIOME.route
    rivalPool=RIVAL_POOLS[bio] or RIVAL_POOLS.route
  end

  -- Filter only species/group selection. All known-good Ground Ecology actor,
  -- movement, touch, battle, flying, and lifecycle code below is unchanged.
  if mapData then
    playPool,huntPool,rivalPool=filterEcologyPools(ow.map,playPool,huntPool,rivalPool)
  end

  -- These six species are handled exclusively by FlyingOverworld's real
  -- swoop/carry hunt controller.  Do not also spawn them as GroundEcology
  -- predators, otherwise the same species can appear in two hunt systems.
  local flyingHuntPredator={ [17]=true,[18]=true,[22]=true,[164]=true,[178]=true,[227]=true }
  if huntPool and #huntPool>0 then
    local groundOnly={}
    for _,pair in ipairs(huntPool) do
      if not flyingHuntPredator[tonumber(pair.pred)] then
        groundOnly[#groundOnly+1]=pair
      end
    end
    huntPool=groundOnly
  end

  local canNature=(bio=="route" or bio=="forest" or bio=="cave")
  local hasHunt=canNature and huntPool and #huntPool>0
  local hasPlay=(playPool and #playPool>0) or (not mapData and PLAY_POOLS[bio] and #PLAY_POOLS[bio]>0)
  local hasRival=rivalPool and #rivalPool>0
  if not hasHunt and not hasPlay and not hasRival then return false end

  local roll=rnd01()
  local kind
  if hasHunt and roll<0.34 then kind="hunt"
  elseif hasPlay and roll<0.68 then kind="play"
  elseif hasRival then kind="rival"
  elseif hasPlay then kind="play"
  elseif hasHunt then kind="hunt"
  else kind="rival" end

  if kind=="hunt" then
    e.kind="hunt"
    local pair=huntPool[rnd(1,#huntPool)]
    e.name=pair.name
    local predm=makeActor(pair.pred,cx,cz,y)
    local prey=nil
    if walkable(ow.map,cx+1,cz) then prey=makeActor(pair.prey,cx+1,cz,y) end
    if not prey and walkable(ow.map,cx,cz+1) then prey=makeActor(pair.prey,cx,cz+1,y) end
    if not predm or not prey then destroyMember(predm);destroyMember(prey);return false end
    predm.role="pred";prey.role="prey"; e.members={predm,prey}

  elseif kind=="play" then
    e.kind="play"
    if mapData then
      -- Supplied PLAY entries are exact 2-3 member groups.
      local group=playPool[rnd(1,#playPool)]
      local offsets={{0,0},{1,0},{0,1},{-1,0},{0,-1}}
      for i,dex in ipairs(group) do
        local o=offsets[i] or offsets[1]
        local m=nil
        if walkable(ow.map,cx+o[1],cz+o[2]) then m=makeActor(dex,cx+o[1],cz+o[2],y) end
        if m then m.role="play";e.members[#e.members+1]=m end
      end
    else
      -- Original biome fallback for maps not in the supplied table.
      local pool=PLAY_POOLS[bio] or PLAY_POOLS.route
      local n=rnd(2,3)
      local first=pool[rnd(1,#pool)]
      local sameSpecies=(rnd01()<0.68)
      for i=1,n do
        local dex
        if i==1 or sameSpecies then dex=first
        else dex=(rnd01()<0.45) and first or pool[rnd(1,#pool)] end
        local offsets={{0,0},{1,0},{0,1},{-1,0},{0,-1}}
        local o=offsets[i] or offsets[1]
        local m=nil
        if walkable(ow.map,cx+o[1],cz+o[2]) then m=makeActor(dex,cx+o[1],cz+o[2],y) end
        if m then m.role="play";e.members[#e.members+1]=m end
      end
    end
    if #e.members<2 then for _,m in ipairs(e.members) do destroyMember(m) end return false end

  else
    e.kind="rival"
    local pair=rivalPool[rnd(1,#rivalPool)]
    local m1=makeActor(pair[1],cx,cz,y)
    local m2=nil
    if walkable(ow.map,cx+1,cz) then m2=makeActor(pair[2],cx+1,cz,y) end
    if not m2 and walkable(ow.map,cx,cz+1) then m2=makeActor(pair[2],cx,cz+1,y) end
    if not m1 or not m2 then destroyMember(m1);destroyMember(m2);return false end
    m1.role="rival";m2.role="rival";m1.partner=m2;m2.partner=m1
    m1.timer=.25+rnd01()*.5;m2.timer=.45+rnd01()*.5
    e.members={m1,m2}
  end

  events[#events+1]=e
  event=e
  return true
end

local function resultRemovesPokemon(result)
  -- Engine versions expose battle outcome differently. Recognize the common
  -- KO/catch markers; unknown/escape/win outcomes are treated as survivor.
  if type(result)=="string" then
    local s=result:lower()
    return s:find("caught",1,true) or s:find("capture",1,true) or s:find("faint",1,true) or s=="ko"
  elseif type(result)=="table" then
    if result.caught or result.captured or result.fainted or result.ko or result.wildFainted then return true end
    local s=tostring(result.result or result.outcome or result.reason or ""):lower()
    return s:find("caught",1,true) or s:find("capture",1,true) or s:find("faint",1,true) or s=="ko"
  end
  return false
end
local function removeMember(target,ev)
  ev=ev or event
  if not ev then return end
  for i=#ev.members,1,-1 do
    if ev.members[i]==target then
      destroyMember(target)
      table.remove(ev.members,i)
      break
    end
  end
end


-- v0.7.2.81: existing PLAY / PREY actors can be claimed by the existing
-- FlyingOverworld hunt controller. This does not change how GroundEcology
-- spawns its events; it only exposes small actors as live prey targets.
local FLYING_PREY_SMALL={
 [1]=true,[4]=true,[7]=true,[10]=true,[11]=true,[13]=true,[14]=true,[19]=true,[21]=true,[25]=true,[27]=true,
 [29]=true,[32]=true,[35]=true,[37]=true,[39]=true,[41]=true,[43]=true,[46]=true,[48]=true,[52]=true,[54]=true,
 [56]=true,[58]=true,[60]=true,[63]=true,[66]=true,[69]=true,[72]=true,[74]=true,[77]=true,[79]=true,[81]=true,[90]=true,
 [96]=true,[98]=true,[102]=true,[104]=true,[116]=true,[118]=true,[120]=true,[133]=true,[137]=true,[138]=true,
 [140]=true,[152]=true,[155]=true,[158]=true,[161]=true,[165]=true,[167]=true,[170]=true,[173]=true,[174]=true,[175]=true,
 [179]=true,[183]=true,[187]=true,[190]=true,[191]=true,[193]=true,[194]=true,[198]=true,[200]=true,[204]=true,[209]=true,
 [211]=true,[215]=true,[216]=true,[220]=true,[223]=true,[225]=true,[228]=true,[231]=true,[238]=true,[239]=true,[240]=true,
 [246]=true,
}
local function flyingPreyEligible(m,ev)
  if not m or not ev or m.carried or m.flyingClaimed or ev.battlePause then return false end
  if m.role=="prey" then return true end
  return ev.kind=="play" and FLYING_PREY_SMALL[tonumber(m.dex)]==true
end
local function groundMemberAlive(m)
  if not m or not m.actor then return false end
  for _,ev in ipairs(events or {}) do
    for _,o in ipairs(ev.members or {}) do if o==m then return true end end
  end
  return false
end
local function nearestFlyingPrey(x,z,radius)
  -- Flying hunters prioritize ecology actors over ordinary route roamers:
  -- PLAY first, then the prey member of PREDATOR/PREY. Distance only breaks
  -- ties inside the same priority class.
  local best,bestD,bestPriority=nil,math.huge,math.huge
  local r=tonumber(radius) or CELL*10
  x,z=tonumber(x) or 0,tonumber(z) or 0
  for _,ev in ipairs(events or {}) do
    for _,m in ipairs(ev.members or {}) do
      if flyingPreyEligible(m,ev) then
        local dx,dz=(m.x or 0)-x,(m.z or 0)-z
        local d=math.sqrt(dx*dx+dz*dz)
        local priority=(ev.kind=="play") and 1 or ((ev.kind=="hunt" and m.role=="prey") and 2 or 3)
        if d<=r and (priority<bestPriority or (priority==bestPriority and d<bestD)) then
          m.current=m -- same live actor/position object expected by FlyingOverworld
          m._groundEvent=ev
          best,bestD,bestPriority=m,d,priority
        end
      end
    end
  end
  return best,bestD,bestPriority
end
local function groundBeginFlee(m,fromX,fromZ,duration)
  if not groundMemberAlive(m) then return false end
  m.flyingClaimed=true;m.mode="flying_flee";m.timer=tonumber(duration) or 4.0
  local ev=m._groundEvent
  if ev and ev.kind=="hunt" and m.role=="prey" then
    ev.flyingStolen=true
    for _,o in ipairs(ev.members or {}) do
      if o~=m and o.role=="pred" then o.mode="stolen_idle";o.timer=1.5;o.tx=nil;o.tz=nil end
    end
  end
  local ow=Game and Game.overworld
  if ow then awayStep(ow,m,tonumber(fromX) or m.cx,tonumber(fromZ) or m.cz) end
  return true
end
local function groundUpdateThreat(m,fromX,fromZ)
  if not groundMemberAlive(m) then return false end
  local ow=Game and Game.overworld
  if ow and not m.tx then awayStep(ow,m,tonumber(fromX) or m.cx,tonumber(fromZ) or m.cz) end
  return true
end
local function groundSetCarried(m,x,y,z,yaw)
  if not groundMemberAlive(m) then return false end
  m.flyingClaimed=true;m.carried=true;m.tx=nil;m.tz=nil
  m.x,m.y,m.z=tonumber(x) or m.x,tonumber(y) or m.y,tonumber(z) or m.z
  if m.actor then m.actor:setPosition(m.x,m.y,m.z);m.actor:setYaw(tonumber(yaw) or 0);m.actor:setAnimation("idle") end
  return true
end
local function groundConsume(m)
  local ev=m and m._groundEvent
  if not ev then return false end
  removeMember(m,ev)
  return true
end
local function groundDropAndFlee(m,yaw)
  if not groundMemberAlive(m) then return false end
  m.carried=nil;m.flyingClaimed=nil;m.current=m;m.mode="scatter";m.timer=3.2
  local ow=Game and Game.overworld
  if ow then
    local hx=(m.x or 0)-math.sin(tonumber(yaw) or 0)*CELL
    local hz=(m.z or 0)-math.cos(tonumber(yaw) or 0)*CELL
    awayStep(ow,m,hx,hz)
  end
  return true
end



local function touch(world,m)
  local p=world and world.player; if not p then return false end
  local px,pz=tonumber(p.x),tonumber(p.z)
  if not px or not pz then return false end
  local dx,dz=m.x-px,m.z-pz
  return dx*dx+dz*dz<=TOUCH_RADIUS*TOUCH_RADIUS
end
local function playerWorld(world)
  local p=world and world.player
  return p and tonumber(p.x),p and tonumber(p.z)
end
local function alertPlayGroup(ow,world,ev)
  ev=ev or event
  if not event or ev.kind~="play" or ev.playFlee then return false end
  local px,pz=playerWorld(world); if not px then return false end
  for _,m in ipairs(ev.members) do
    local dx,dz=m.x-px,m.z-pz
    if dx*dx+dz*dz<=PLAY_ALERT_RADIUS*PLAY_ALERT_RADIUS then
      ev.playFlee=true
      ev.playFleeTimer=5.0
      local pcx,pcz=playerCell(ow)
      for _,o in ipairs(ev.members) do
        o.mode="play_flee";o.timer=5.0;o.contact=false
        if pcx then awayStep(ow,o,pcx,pcz) end
      end
      return true
    end
  end
  return false
end

local function beginBattle(ow,world,m,ev)
  local api=wildAPI()
  ev=ev or event
  if battleLock or not ev or not api or type(api.startDexEncounter)~="function" then return false end
  battleLock=true;ev.battlePause=true;m.contact=true
  local started=api.startDexEncounter(m.dex,5,function(result)
    if resultRemovesPokemon(result) then
      removeMember(m,ev)
    else
      m.mode="scatter";m.timer=3.2
    end
    local px,pz=playerCell(ow)
    for _,o in ipairs(ev.members or {}) do
      o.mode="scatter";o.timer=math.max(o.timer or 0,3.2);o.contact=true
      if px then awayStep(ow,o,px,pz) end
    end
    ev.battlePause=false
    ev.age=math.max(ev.age or 0,EVENT_LIFE-5)
    battleLock=false
  end)
  if not started then battleLock=false;ev.battlePause=false;m.contact=false end
  return started
end

local function updateMember(ow,m,dt,ev)
  ev=ev or event
  if m.mode=="stolen_idle" then
    m.timer=(m.timer or 0)-dt
    m.tx,m.tz=nil,nil
    if m.timer<=0 then m.mode="stolen_roam";m.timer=.25+rnd01()*.7 end
  elseif m.mode=="stolen_roam" then
    m.timer=(m.timer or 0)-dt
    if not m.tx and m.timer<=0 then randomStep(ow,m);m.timer=.35+rnd01()*.7 end
    moveToward(m,dt,WALK)
  elseif m.mode=="play_flee" then
    m.timer=(m.timer or 0)-dt
    local px,pz=playerCell(ow)
    if not m.tx and px then awayStep(ow,m,px,pz) end
    moveToward(m,dt,PLAY_FLEE_SPEED)
    -- Keep the play group escaping as a loose pack: a member that gets too
    -- far ahead briefly eases off while the others catch up.
    local cx,cz,n=0,0,0
    for _,o in ipairs(ev.members or {}) do cx=cx+o.x;cz=cz+o.z;n=n+1 end
    if n>1 then
      cx,cz=cx/n,cz/n
      local dx,dz=m.x-cx,m.z-cz
      if dx*dx+dz*dz>PLAY_REGROUP_RADIUS*PLAY_REGROUP_RADIUS then
        m.tx,m.tz=nil,nil
      end
    end
    if m.timer<=0 then m.mode="exit" end
  elseif m.mode=="flying_flee" then
    m.timer=(m.timer or 0)-dt
    if not m.tx then local px,pz=playerCell(ow);if px then awayStep(ow,m,px,pz) end end
    moveToward(m,dt,RUN)
    if m.timer<=0 and not m.carried then m.mode=nil;m.flyingClaimed=nil end
  elseif m.mode=="scatter" then
    m.timer=m.timer-dt
    if not m.tx then local px,pz=playerCell(ow);if px then awayStep(ow,m,px,pz) end end
    moveToward(m,dt,RUN)
    if m.timer<=0 then m.mode="exit" end
  elseif m.mode=="tree_exit" then
    moveToward(m,dt,RUN*0.82)
    local tx,tz=m.exitTreeX,m.exitTreeZ
    if tx and tz then
      local wx,wz=tx*CELL+8,tz*CELL+8
      local dx,dz=m.x-wx,m.z-wz
      if dx*dx+dz*dz<=ECOLOGY_EXIT_REACH*ECOLOGY_EXIT_REACH then
        m.exitDone=true;m.tx,m.tz=nil,nil
      end
    end
  elseif m.mode=="exit" then
    if not m.tx then local px,pz=playerCell(ow);if px then awayStep(ow,m,px,pz) end end
    moveToward(m,dt,RUN)
  elseif ev.kind=="rival" then
    local other=m.partner
    m.timer=(m.timer or 0)-dt
    if other and m.timer<=0 then
      local dx,dz=other.x-m.x,other.z-m.z
      local dist=math.sqrt(dx*dx+dz*dz)
      m.actor:setYaw(math.atan2(dx,dz))
      if dist>CELL*1.15 and not m.tx then
        local sx=dx==0 and 0 or (dx>0 and 1 or -1)
        local sz=dz==0 and 0 or (dz>0 and 1 or -1)
        local nx,nz=m.cx+sx,m.cz+(sx==0 and sz or 0)
        if walkable(ow.map,nx,nz) then setTarget(m,nx,nz) end
      elseif dist<CELL*0.62 and not m.tx then
        awayStep(ow,m,other.cx,other.cz)
      else
        -- Short attack burst, then idle/reposition. Offset timers stop both
        -- rivals from looking mechanically synchronized.
        m.actor:setAnimation("attack")
        m.timer=.65+rnd01()*1.15
      end
    end
    moveToward(m,dt,WALK*1.25)
  elseif ev.kind=="hunt" then
    local other=ev.members[m==ev.members[1] and 2 or 1]
    if other then
      if m.role=="prey" then
        local dx,dz=m.x-other.x,m.z-other.z
        if dx*dx+dz*dz<(CELL*3)^2 and not m.tx then
          local px,pz=other.cx,other.cz;awayStep(ow,m,px,pz)
        end
      elseif not m.tx then
        local dx,dz=other.cx-m.cx,other.cz-m.cz
        local sx=dx==0 and 0 or (dx>0 and 1 or -1)
        local sz=dz==0 and 0 or (dz>0 and 1 or -1)
        local nx,nz=m.cx+sx,m.cz+(sx==0 and sz or 0)
        if walkable(ow.map,nx,nz) then setTarget(m,nx,nz) end
      end
    end
    moveToward(m,dt,m.role=="prey" and RUN*0.78 or WALK*1.35)
  else
    m.timer=m.timer-dt
    if not m.tx and m.timer<=0 then randomStep(ow,m);m.timer=.35+rnd01()*.7 end
    moveToward(m,dt,WALK*1.15)
  end
  local moving=m.tx~=nil
  local canFly=m.actor and m.actor.model and m.actor.model.states and m.actor.model.states.fly
  local visualAir=false
  local visualHop=false

  -- PLAY / hunt / rough-play visuals borrow only the actor Y + animation layer.
  -- X/Z movement, event logic and touch encounters remain exactly as before.
  local activeEcology=(ev.kind=="play" or ev.kind=="hunt" or ev.kind=="rival")
  -- Flying-capable birds are NOT forced airborne just because an ecology event is active.
  -- Their existing random-flight state controls Y. Animation is selected from actual height below.
  local birdFlight=false
  local levitating=LEVITATORS[m.dex] and not m.carried
  local hopping=activeEcology and (HOPPERS[m.dex] or (ECOLOGY_BIRDS[m.dex] and not TRUE_FLYING_BIRDS[m.dex])) and not m.carried

  if birdFlight and m.groundY~=nil then
    -- Birds stay visibly airborne while participating in ecology. The existing
    -- X/Z chase/play movement supplies the path; this only lifts the actor.
    m.phase=(m.phase or 0)+dt*3.2
    local target=m.groundY+PLAY_FLY_HEIGHT+math.sin(m.phase)*0.22
    local cur=m.y or m.groundY
    local step=RANDOM_FLY_VERTICAL_SPEED*1.8*dt
    if cur<target then cur=math.min(target,cur+step) else cur=math.max(target,cur-step) end
    m.y=cur
    visualAir=true
    -- Suppress the unrelated random-flight timer while ecology itself is flying.
    m.randomFlight=nil
    m.flightCooldown=RANDOM_FLY_MIN_GAP+rnd01()*(RANDOM_FLY_MAX_GAP-RANDOM_FLY_MIN_GAP)
  elseif levitating and m.groundY~=nil then
    m.phase=(m.phase or 0)+dt*2.1
    m.y=m.groundY+LEVITATE_HEIGHT+math.sin(m.phase)*0.20
    visualAir=true
    m.randomFlight=nil
  elseif hopping and m.groundY~=nil then
    m.phase=(m.phase or 0)+dt*(moving and 7.0 or 4.5)
    -- abs(sin) returns to the ground every hop, so these remain ground actors.
    m.y=m.groundY+math.abs(math.sin(m.phase))*PLAY_HOP_HEIGHT
    visualHop=true
    m.randomFlight=nil
  else
    -- Preserve the original random-flight behavior byte-for-byte in spirit for
    -- every species outside the new interaction-specific visual profiles.
    if canFly and not m.carried and m.groundY~=nil then
      if not m.randomFlight then
        m.flightCooldown=(m.flightCooldown or 0)-dt
        if m.flightCooldown<=0 then
          m.randomFlight={
            phase="takeoff",
            height=RANDOM_FLY_MIN_HEIGHT+rnd01()*(RANDOM_FLY_MAX_HEIGHT-RANDOM_FLY_MIN_HEIGHT)+(((m.dex==187 or m.dex==188 or m.dex==189) and HOPPIP_FAMILY_FLIGHT_BONUS) or 0),
            timer=RANDOM_FLY_MIN_TIME+rnd01()*(RANDOM_FLY_MAX_TIME-RANDOM_FLY_MIN_TIME),
            bob=rnd01()*6.28318,
          }
        end
      end

      local rf=m.randomFlight
      if rf then
        if rf.phase=="takeoff" then
          local target=m.groundY+rf.height
          m.y=math.min(target,(m.y or m.groundY)+RANDOM_FLY_VERTICAL_SPEED*dt)
          if m.y>=target-0.02 then rf.phase="airborne" end
        elseif rf.phase=="airborne" then
          rf.timer=rf.timer-dt
          rf.bob=(rf.bob or 0)+dt*2.3
          m.y=m.groundY+rf.height+math.sin(rf.bob)*0.12
          if rf.timer<=0 then rf.phase="landing" end
        elseif rf.phase=="landing" then
          m.y=math.max(m.groundY,(m.y or m.groundY)-RANDOM_FLY_VERTICAL_SPEED*dt)
          if m.y<=m.groundY+0.02 then
            m.y=m.groundY
            m.randomFlight=nil
            m.flightCooldown=RANDOM_FLY_MIN_GAP+rnd01()*(RANDOM_FLY_MAX_GAP-RANDOM_FLY_MIN_GAP)
          end
        end
      else
        m.y=m.groundY
      end
    elseif not m.carried and m.groundY~=nil then
      m.y=m.groundY
    end
  end

  -- Grounded/near-ground birds use idle/walk; only real elevation uses fly.
  local airborne=visualAir or (m.groundY~=nil and (m.y or m.groundY)>m.groundY+3.0 and not visualHop)
  m.actor:setPosition(m.x,m.y,m.z)
  m.actor:setVisible(false)
  if not (ev.kind=="rival" and not moving and (m.timer or 0)>0.45) then
    local anim
    if airborne then
      anim="fly"
    else
      anim=moving and "walk" or "idle"
    end
    if m._lastAnim~=anim then
      m.actor:setAnimation(anim)
      m._lastAnim=anim
    end
  end
  m.actor:update(dt)
end

local comp=companion()
if not comp then error("RUMBLE_GROUND_ECOLOGY: voxel companion unavailable",0) end
local imp=importer()
if imp and type(imp.Voxel3D)=="function" then local ok,v=pcall(imp.Voxel3D);if ok then Voxel3D=v end end

local spec={
 api=1,id="rumble.ground.ecology",name="Cobblemon Ground Ecology",version="0.3.0-gen2",priority=27,
 requires={"render_phases","world_snapshot"},optional={},
 attach=function() servicesReady=true end,
 worldChanged=function() clear();mapId=nil;clock=2.0+rnd01()*3.0 end,
 render={opaque_after_terrain=function(context)
   local world=context and context.world
   local ow=(mod.game and mod.game.world) or (Game and Game.overworld)
   if not groundEcologyEnabled() then
     if #events>0 then clear() end
     return
   end
   if not (servicesReady and world and ow and ow.map and ow.player) then return end
   if mapId~=ow.map.id then
     clear();mapId=ow.map.id
     clock=2.0+rnd01()*3.0
   end
   if not biome(ow.map) then
     if #events>0 then clear() end
     return
   end

   local dt=(context.frame and context.frame.dt) or 1/60

   -- Each event now updates independently.
   for i=#events,1,-1 do
     local ev=events[i]
     event=ev
     if not ev.battlePause then
       -- A prey actor claimed by FlyingOverworld must survive until the carry
       -- sequence explicitly consumes or drops it. Freeze this ecology event's
       -- normal lifetime/forced PLAY cleanup while any member is claimed.
       local flyingClaimActive=false
       for _,fm in ipairs(ev.members or {}) do
         if fm.flyingClaimed or fm.carried then flyingClaimActive=true;break end
       end
       if not flyingClaimActive then ev.age=(ev.age or 0)+dt end
       if ev.kind=="play" then alertPlayGroup(ow,world,ev) end
       if ev.playFlee and not flyingClaimActive then
         ev.playFleeTimer=(ev.playFleeTimer or 0)-dt
         if ev.playFleeTimer<=0 then ev.age=EVENT_LIFE+1 end
       end
       for _,m in ipairs(ev.members or {}) do
         local hit=touch(world,m)
         if hit and not m.contact then
           if beginBattle(ow,world,m,ev) then return end
         elseif not hit then
           m.contact=false
         end
       end
       for _,m in ipairs(ev.members or {}) do updateMember(ow,m,dt,ev) end
     end
     for _,m in ipairs(ev.members or {}) do draw(m) end
     local protectedByFlying=false
     for _,fm in ipairs(ev.members or {}) do
       if fm.flyingClaimed or fm.carried then protectedByFlying=true;break end
     end
     if #(ev.members or {})==0 then
       table.remove(events,i)
     elseif not protectedByFlying and (ev.age or 0)>EVENT_LIFE and not ev.exiting then
       beginTreeExit(ow,ev)
     elseif ev.exiting then
       ev.exitTimer=(ev.exitTimer or ECOLOGY_EXIT_TIMEOUT)-dt
       for mi=#(ev.members or {}),1,-1 do
         local em=ev.members[mi]
         if em.exitDone then destroyMember(em);table.remove(ev.members,mi) end
       end
       if #(ev.members or {})==0 or (ev.exitTimer or 0)<=0 then
         for _,em in ipairs(ev.members or {}) do destroyMember(em) end
         table.remove(events,i)
       end
     end
   end
   event=nil

   clock=clock-dt
   if clock<=0 then
     if #events<MAX_EVENTS and rnd01()<EVENT_CHANCE then spawn(ow,world) end
     clock=RESPAWN_MIN+rnd01()*(RESPAWN_MAX-RESPAWN_MIN)
   end
  end},
  invalidate=function() clear();mapId=nil end,
 dispose=function() clear();if BLACK and BLACK.release then pcall(BLACK.release,BLACK) end;BLACK=nil end,
}
local h,err=comp.register(spec)
if not h then error("RUMBLE_GROUND_ECOLOGY registration failed: "..tostring(err),0) end
mod.exports.cobblemon_ground_ecology={api=1,clear=clear}


-- Shared ecology snapshot for flying hunters. FlyingOverworld may inspect live
-- play groups without taking ownership of them.
_G.RUMBLE_GROUND_ECOLOGY=_G.RUMBLE_GROUND_ECOLOGY or {}
_G.RUMBLE_GROUND_ECOLOGY.events=function() return events end
_G.RUMBLE_GROUND_ECOLOGY.nearestFlyingPrey=nearestFlyingPrey
_G.RUMBLE_GROUND_ECOLOGY.isAlive=groundMemberAlive
_G.RUMBLE_GROUND_ECOLOGY.beginFlee=groundBeginFlee
_G.RUMBLE_GROUND_ECOLOGY.updateThreat=groundUpdateThreat
_G.RUMBLE_GROUND_ECOLOGY.setCarried=groundSetCarried
_G.RUMBLE_GROUND_ECOLOGY.consume=groundConsume
_G.RUMBLE_GROUND_ECOLOGY.dropAndFlee=groundDropAndFlee
_G.RUMBLE_GROUND_ECOLOGY.playGroups=function()
  local out={}
  for _,e in ipairs(events) do
    if e.kind=="play" and not e.battlePause then out[#out+1]=e end
  end
  return out
end

_G.RUMBLE_GROUND_ECOLOGY.enabled=groundEcologyEnabled
