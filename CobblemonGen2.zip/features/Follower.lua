local mod = ...

local function liveGame()
  local g=mod and mod.game
  return type(g)=="table" and g or nil
end
local Game=setmetatable({}, {
  __index=function(_,k)
    local g=liveGame()
    if not g then return nil end
    if k=="overworld" then return g.overworld or g.world end
    return g[k]
  end,
  __newindex=function(_,k,v)
    local g=liveGame(); if g then g[k]=v end
  end
})

local CELL = 16
local FOLLOW_SPEED = 105
local TELEPORT_DISTANCE = 96

local followers = {}
local trail = {}
local lastMap = nil
local lastPlayerCell = nil
local lastSurfing = nil
local normalPlayerRender = nil

-- Cache only presentation fields from the render-world player while on land.
-- The world passed to render_phases is a snapshot, so overriding these fields
-- changes presentation without touching native Surf movement/collision state.
local function cacheNormalPlayerPresentation(player)
  if type(player)~="table" then return end
  local c={}
  for k,v in pairs(player) do
    local n=string.lower(tostring(k))
    if n=="sprite" or n=="spriteid" or n=="sprite_id" or n=="graphic" or n=="graphics"
       or n=="appearance" or n=="avatar" or n=="texture" or n=="animation" or n=="anim" then
      c[k]=v
    end
  end
  normalPlayerRender=c
end

local function forceNormalPlayerPresentation(player)
  if type(player)~="table" then return end
  -- Presentation only: never change Surf state/physics. Restore the cached
  -- land sprite/graphic fields on whichever player object the renderer exposes.
  if normalPlayerRender then
    for k,v in pairs(normalPlayerRender) do player[k]=v end
  end
end
local function forceLiveNormalPlayerPresentation()
  local ow=Game and Game.overworld
  local p=ow and ow.player
  if type(p)=="table" then forceNormalPlayerPresentation(p) end
end

local lastCollisionMap = nil
local stackNextSpawn = false
local servicesReady = false
local BLACK_TEXTURE = nil
local Voxel3D = nil

-- While the trainer is Surfing, Water-type followers are allowed, plus the
-- explicit Spinarak/Ariados exception. Flying-type followers are allowed only
-- when their Cobblemon model has an authored `fly` state. This is type/state
-- based, not HM-learnset based.
local WATER_TYPE_DEX = {
  [7]=true,[8]=true,[9]=true,[54]=true,[55]=true,[60]=true,[61]=true,[62]=true,
  [72]=true,[73]=true,[79]=true,[80]=true,[86]=true,[87]=true,[90]=true,[91]=true,
  [98]=true,[99]=true,[116]=true,[117]=true,[118]=true,[119]=true,[120]=true,[121]=true,
  [129]=true,[130]=true,[131]=true,[134]=true,[138]=true,[139]=true,[140]=true,[141]=true,
  [158]=true,[159]=true,[160]=true,[170]=true,[171]=true,[183]=true,[184]=true,[186]=true,
  [194]=true,[195]=true,[199]=true,[211]=true,[222]=true,[223]=true,[224]=true,
  [226]=true,[230]=true,[245]=true,
}

local FLYING_TYPE_DEX = {
  [6]=true,[12]=true,[16]=true,[17]=true,[18]=true,[21]=true,[22]=true,[41]=true,[42]=true,
  [83]=true,[84]=true,[85]=true,[123]=true,[130]=true,[142]=true,[144]=true,[145]=true,
  [146]=true,[149]=true,[163]=true,[164]=true,[165]=true,[166]=true,[169]=true,[176]=true,
  [177]=true,[178]=true,[187]=true,[188]=true,[189]=true,[193]=true,[198]=true,[207]=true,
  [225]=true,[226]=true,[227]=true,[249]=true,[250]=true,
}

local FLY_OK_CACHE = {}

-- Spinarak / Ariados are explicit Surf-follower exceptions.
local SURF_EXCEPTION_DEX = { [167]=true, [168]=true }

-- Serpentine followers explicitly allowed to accompany the trainer on water,
-- but (like every Surf follower) they still need an authored surf/fly state.
local SURF_SNAKE_DEX = {
  [23]=true,  -- Ekans
  [24]=true,  -- Arbok
  [147]=true, -- Dratini
  [148]=true, -- Dragonair
}

local function actorHasState(entry, state)
  if not (entry and entry.actor and state) then return false end
  local model=entry.actor.model
  return model and model.states and model.states[state]~=nil or false
end

local function actorHasProperFly(entry)
  local ok=actorHasState(entry, "fly")
  if entry and entry.dex then FLY_OK_CACHE[entry.dex]=ok and true or false end
  return ok and true or false
end

local function surfFollowerAllowed(dex, entry)
  dex=tonumber(dex)
  if not dex then return false end
  if WATER_TYPE_DEX[dex] or SURF_EXCEPTION_DEX[dex] or SURF_SNAKE_DEX[dex] then return true end
  if not FLYING_TYPE_DEX[dex] then return false end
  local cached=FLY_OK_CACHE[dex]
  if cached~=nil then return cached end
  return actorHasProperFly(entry)
end

-- ------------------------------------------------------------
-- Setting: OFF / 1 / 2 / 3 / 4 / 5 / 6
-- ------------------------------------------------------------

local COUNT_KEY = "follower_count"
local COUNT_CHOICES = {0, 1, 2, 3, 4, 5, 6}


local function getCount()
  local value = 1
  local loader = Game and Game.mods
  local stored = loader and loader.modOptions and loader.modOptions[mod.id]

  if stored and stored[COUNT_KEY] ~= nil then
    value = tonumber(stored[COUNT_KEY]) or 1
  else
    local opts = Game and Game.save and Game.save.options
    stored = opts and opts.modOptions and opts.modOptions[mod.id]
    if stored and stored[COUNT_KEY] ~= nil then
      value = tonumber(stored[COUNT_KEY]) or 1
    end
  end

  value = math.floor(value)
  if value < 0 then value = 0 end
  if value > 6 then value = 6 end
  return value
end

local function setCount(game, value)
  value = math.max(0, math.min(6, math.floor(tonumber(value) or 0)))
  local opts = game and game.save and game.save.options
  if opts then
    opts.modOptions = opts.modOptions or {}
    opts.modOptions[mod.id] = opts.modOptions[mod.id] or {}
    opts.modOptions[mod.id][COUNT_KEY] = value
  end
  local loader = game and game.mods
  if loader then
    loader.modOptions = loader.modOptions or {}
    loader.modOptions[mod.id] = loader.modOptions[mod.id] or {}
    loader.modOptions[mod.id][COUNT_KEY] = value
  end
  if game and game.writeOptions then pcall(game.writeOptions, game) end
end

local function optionRow()
  return {
    id = mod.id .. ":" .. COUNT_KEY,
    label = "COBBLEMON FOLLOWERS",
    value = function()
      local n = getCount()
      return n == 0 and "OFF" or tostring(n)
    end,
    step = function(game, dir)
      local n = getCount()
      n = n + (dir or 1)
      if n > 6 then n = 0 end
      if n < 0 then n = 6 end
      setCount(game, n)
      return true
    end
  }
end


-- ------------------------------------------------------------
-- APIs
-- ------------------------------------------------------------

local function log(level, fmt, ...)
  if not mod.log then return end
  local fn = mod.log[level]
  if type(fn) == "function" then pcall(fn, mod.log, fmt, ...) end
end

local function findImporter()
  local api = mod.exports and (mod.exports.cobblemon_main or mod.exports.cobblemon_importer)
  if api and tonumber(api.api)==1 and type(api.createActor)=="function" then return api end
  if not (mod and type(mod.find)=="function") then return nil end
  local ok,host=pcall(mod.find,"COBBLEMONE_GEN2")
  if not ok or not host then return nil end
  api=host.exports and (host.exports.cobblemon_main or host.exports.cobblemon_importer)
  if not api or tonumber(api.api)~=1 or type(api.createActor)~="function" then return nil end
  return api
end

local function findDramaless()
  local api=mod.exports and mod.exports.voxel_companion
  local importer=mod.exports and (mod.exports.cobblemon_main or mod.exports.cobblemon_importer)
  if api and tonumber(api.api)==1 and type(api.register)=="function" then
    if importer and type(importer.Voxel3D)=="function" then
      local okv,v=pcall(importer.Voxel3D)
      if okv and v and type(v.draw)=="function" then Voxel3D=v end
    end
    return api
  end
  if not (mod and type(mod.find)=="function") then return nil end
  local ok,host=pcall(mod.find,"COBBLEMONE_GEN2")
  if not ok or not host then return nil end
  api=host.exports and host.exports.voxel_companion
  importer=host.exports and (host.exports.cobblemon_main or host.exports.cobblemon_importer)
  if not api or tonumber(api.api)~=1 or type(api.register)~="function" then return nil end
  if importer and type(importer.Voxel3D)=="function" then
    local okv,v=pcall(importer.Voxel3D)
    if okv and v and type(v.draw)=="function" then Voxel3D=v end
  end
  return api
end

local function outlineEnabled()
  local api=findImporter()
  if api and type(api.outlineEnabled)=="function" then
    local ok,v=pcall(api.outlineEnabled)
    if ok then return v~=false end
  end
  return false
end

local function blackTexture()
  if BLACK_TEXTURE then return BLACK_TEXTURE end
  if not (love and love.image and love.graphics
      and love.image.newImageData and love.graphics.newImage) then return nil end
  local ok, data = pcall(love.image.newImageData, 1, 1)
  if not ok or not data then return nil end
  pcall(data.setPixel, data, 0, 0, 0, 0, 0, 1)
  local ok2, img = pcall(love.graphics.newImage, data)
  if ok2 and img then BLACK_TEXTURE = img end
  return BLACK_TEXTURE
end

-- ------------------------------------------------------------
-- Party helpers
-- ------------------------------------------------------------

local function dexOfPartySlot(slot)
  local save = Game and Game.save
  local party = save and save.party
  local mon = type(party) == "table" and party[slot] or nil
  if not mon then return nil end

  local species = mon.species
  if type(species) == "number" then
    local n = math.floor(species)
    if n >= 1 and n <= 493 then return n end
  end

  local data = Game and Game.data
  local pokemon = data and data.pokemon
  local key = species and tostring(species):upper() or nil
  local def = pokemon and key and (pokemon[species] or pokemon[key])
  local dex = def and tonumber(def.dex)
  if dex then
    dex = math.floor(dex)
    if dex >= 1 and dex <= 493 then return dex end
  end
  return nil
end

local function yawForFacing(facing)
  if facing == "right" then return math.pi * 0.5 end
  if facing == "up" then return math.pi end
  if facing == "left" then return -math.pi * 0.5 end
  return 0
end

local function tileCenter(cx, cz, y)
  return {
    x = (tonumber(cx) or 0) * CELL + 8,
    y = tonumber(y) or 0,
    z = (tonumber(cz) or 0) * CELL + 8,
  }
end

local function playerCell(player)
  local cx = tonumber(player.cellX)
  local cz = tonumber(player.cellZ)
  if cx == nil then cx = math.floor(((tonumber(player.x) or 8) - 8) / CELL) end
  if cz == nil then cz = math.floor(((tonumber(player.z) or 8) - 8) / CELL) end
  return cx, cz
end

local function oneBehind(cx, cz, facing, steps)
  steps = steps or 1
  if facing == "down" then cz = cz - steps
  elseif facing == "up" then cz = cz + steps
  elseif facing == "right" then cx = cx - steps
  elseif facing == "left" then cx = cx + steps end
  return cx, cz
end

-- Followers use the same collision grid as the overworld instead of blindly
-- drawing through filler/black tiles.  This is especially important just after
-- a door/warp, where the cells behind the trainer can be outside the interior.
local function liveMap()
  local ow = Game and Game.overworld
  return ow and ow.map or nil
end

-- The live player.surfing flag is not present on every render path.  Keep it
-- when available, but also resolve Surf directly from the current map cell.
-- A normal player cannot occupy a true water cell unless they are Surfing, so
-- this gives the follower renderer a reliable fallback without depending on a
-- render snapshot field.
local FieldMoves = nil
do
  local ok, fm = pcall(require, "src.world.gen2.FieldMoves")
  if ok and type(fm)=="table" then FieldMoves=fm end
end


local function isWarpCell(map, cx, cz)
  if not (map and cx ~= nil and cz ~= nil and type(map.isWarpTileCell)=="function") then return false end
  local ok,v=pcall(map.isWarpTileCell,map,cx,cz)
  return ok and v==true or false
end

local function alignFollowersToTrail()
  for slot=1,6 do
    local e=followers[slot]
    local t=trail[slot]
    if e and t then
      e.current={x=t.x,y=t.y,z=t.z}
      e.target={x=t.x,y=t.y,z=t.z,facing=t.facing}
      if e.actor then
        if type(e.actor.setPosition)=="function" then pcall(e.actor.setPosition,e.actor,t.x,t.y,t.z) end
        if type(e.actor.setYaw)=="function" then pcall(e.actor.setYaw,e.actor,yawForFacing(t.facing or "down")) end
      end
    end
  end
end

local function playerIsSurfing(renderPlayer, renderWorld)
  -- Gen2's own FieldMoves check is authoritative. Battle Art itself uses this
  -- exact API for native Surf detection, so prefer it over render snapshots.
  local function stateSurfing(world)
    if not (FieldMoves and type(FieldMoves.isSurfing)=="function" and world) then return false end
    local st=world.playerState
    if st==nil then return false end
    local ok,v=pcall(FieldMoves.isSurfing,st)
    return ok and v==true or false
  end

  if stateSurfing(renderWorld) then return true end
  local ow=Game and Game.overworld
  if stateSurfing(ow) then return true end

  local livePlayer=ow and ow.player
  if livePlayer and livePlayer.surfing==true then return true end
  if renderPlayer and renderPlayer.surfing==true then return true end

  -- Last-resort fallback for render paths that expose neither playerState nor
  -- the surfing flag: standing on a water cell means the trainer is Surfing.
  local map=ow and ow.map or (renderWorld and renderWorld.map) or nil
  if not (map and type(map.isWaterCell)=="function") then return false end
  local p=livePlayer or renderPlayer
  if not p then return false end
  local cx=tonumber(p.cellX)
  local cz=tonumber(p.cellY) or tonumber(p.cellZ)
  if cx==nil or cz==nil then
    cx=math.floor(((tonumber(p.x) or 8)-8)/CELL)
    cz=math.floor(((tonumber(p.z) or tonumber(p.y) or 8)-8)/CELL)
  end
  local ok,v=pcall(map.isWaterCell,map,cx,cz)
  return ok and v==true or false
end

local function inBounds(map, x, z)
  if not map then return false end
  if type(map.inBounds)=="function" then
    local ok,v=pcall(map.inBounds,map,x,z)
    if ok then return v==true end
  end
  local W,H=tonumber(map.widthCells),tonumber(map.heightCells)
  return W and H and x>=0 and z>=0 and x<W and z<H or false
end

local function safeCell(map, x, z)
  if not inBounds(map,x,z) then return false end
  if type(map.isWalkableCell)=="function" then
    local ok,v=pcall(map.isWalkableCell,map,x,z)
    return ok and v==true
  end
  return true
end

local function stepAllowed(map, x, z, dir)
  if not map or type(map.stepPermitted)~="function" then return true end
  local ok,v=pcall(map.stepPermitted,map,x,z,dir)
  return ok and v~=false
end

local function dirBetween(ax,az,bx,bz)
  if bx==ax+1 and bz==az then return "right" end
  if bx==ax-1 and bz==az then return "left" end
  if bz==az+1 and bx==ax then return "down" end
  if bz==az-1 and bx==ax then return "up" end
  return nil
end

-- ------------------------------------------------------------
-- Actors
-- ------------------------------------------------------------

local function destroyActor(entry)
  if not entry or not entry.actor then return end
  local ok = pcall(function() entry.actor:destroy() end)
  if not ok then
    local importer = findImporter()
    if importer and type(importer.destroyActor) == "function" then
      pcall(importer.destroyActor, entry.actor)
    end
  end
end

local function clearFollowers()
  for _, entry in ipairs(followers) do destroyActor(entry) end
  followers = {}
end

local function makeActor(slot, dex, pos, facing)
  local importer = findImporter()
  if not importer then return nil end
  local actor, err = importer.createActor(dex, {
    manual = true,
    visible = false,
    x = pos.x, y = pos.y, z = pos.z,
    yaw = yawForFacing(facing),
  })
  if not actor then
    log("warn", "Follower slot %d failed dex=%s: %s", slot, tostring(dex), tostring(err))
    return nil
  end
  actor:setAnimation("idle")
  actor:setPosition(pos.x, pos.y, pos.z)
  actor:setYaw(yawForFacing(facing))
  actor:setVisible(false)
  return {
    slot = slot,
    dex = dex,
    actor = actor,
    current = {x=pos.x, y=pos.y, z=pos.z},
    target = {x=pos.x, y=pos.y, z=pos.z, facing=facing},
    lastAnim = "idle",
  }
end

local function stackTrailAtPlayer(player)
  trail = {}
  local cx, cz = playerCell(player)
  local facing = player.facing or "down"
  local y = tonumber(player.y) or 0
  local pos = tileCenter(cx, cz, y)
  for i = 1, 6 do
    trail[i] = {x=pos.x, y=pos.y, z=pos.z, facing=facing}
  end
  lastPlayerCell = {cx=cx, cz=cz, y=y, facing=facing}
end

local function ensureFollowers(player, surfing)
  local wanted = getCount()
  if wanted == 0 then
    if #followers > 0 then clearFollowers() end
    return
  end

  local cx, cz = playerCell(player)
  local facing = player.facing or "down"
  surfing = surfing == true

  for slot = 1, 6 do
    local shouldExist = slot <= wanted
    local dex = shouldExist and dexOfPartySlot(slot) or nil
    local entry = followers[slot]

    if not dex then
      if entry then destroyActor(entry); followers[slot] = nil end
    else
      -- While Surfing: Water types and Spinarak/Ariados are always allowed.
      -- Flying types are allowed only when the loaded model actually has a
      -- proper `fly` state. Everything else (e.g. Ampharos) is suppressed.
      if surfing then
        if WATER_TYPE_DEX[dex] or SURF_EXCEPTION_DEX[dex] or SURF_SNAKE_DEX[dex] then
          if not entry or entry.dex~=dex then
            if entry then destroyActor(entry) end
            local pos
            if stackNextSpawn then
              pos=tileCenter(cx,cz,player.y)
            else
              local sx,sz=oneBehind(cx,cz,facing,slot)
              pos=tileCenter(sx,sz,player.y)
            end
            entry=makeActor(slot,dex,pos,facing)
            followers[slot]=entry
          end
          -- No idle/walk fallback on water. A permitted species must still
          -- have a real authored Surf or Fly state to be rendered while Surfing.
          if entry and dex~=73 and not actorHasState(entry, "surf") and not actorHasState(entry, "fly") then
            destroyActor(entry); followers[slot]=nil; entry=nil
          end
        elseif FLYING_TYPE_DEX[dex] then
          if entry and entry.dex==dex then
            if not actorHasProperFly(entry) then
              destroyActor(entry); followers[slot]=nil; entry=nil
            end
          elseif FLY_OK_CACHE[dex]==false then
            if entry then destroyActor(entry) end
            followers[slot]=nil; entry=nil
          else
            if entry then destroyActor(entry) end
            local pos
            if stackNextSpawn then
              pos=tileCenter(cx,cz,player.y)
            else
              local sx,sz=oneBehind(cx,cz,facing,slot)
              pos=tileCenter(sx,sz,player.y)
            end
            local probe=makeActor(slot,dex,pos,facing)
            if probe and actorHasProperFly(probe) then
              followers[slot]=probe; entry=probe
            else
              if probe then destroyActor(probe) end
              followers[slot]=nil; entry=nil
            end
          end
        else
          if entry then destroyActor(entry) end
          followers[slot]=nil; entry=nil
        end
      elseif not entry or entry.dex ~= dex then
        if entry then destroyActor(entry) end
        local pos
        if stackNextSpawn then
          pos = tileCenter(cx, cz, player.y)
        else
          local sx, sz = oneBehind(cx, cz, facing, slot)
          pos = tileCenter(sx, sz, player.y)
        end
        followers[slot] = makeActor(slot, dex, pos, facing)
      end
    end
  end

  -- Remove any entries beyond the selected count.
  for slot = wanted + 1, 6 do
    if followers[slot] then
      destroyActor(followers[slot])
      followers[slot] = nil
    end
  end
end

-- ------------------------------------------------------------
-- Trail logic
-- ------------------------------------------------------------

local function resetTrail(player, map)
  trail = {}
  local cx, cz = playerCell(player)
  local facing = player.facing or "down"
  local y = tonumber(player.y) or 0
  map = map or liveMap()

  -- Never manufacture a follower chain through the black/filler space behind
  -- an interior entrance. Walk backward only while each cell is genuinely
  -- reachable. Once the chain hits a wall/out-of-map cell, keep the remaining
  -- followers on the last safe tile; they spread naturally as the player moves.
  local px,pz=cx,cz
  local fallback=tileCenter(cx,cz,y)
  for i = 1, 6 do
    local bx,bz=oneBehind(px,pz,facing,1)
    local dir=dirBetween(px,pz,bx,bz)
    if safeCell(map,bx,bz) and (not dir or stepAllowed(map,px,pz,dir)) then
      px,pz=bx,bz
      fallback=tileCenter(px,pz,y)
    end
    trail[i] = {x=fallback.x, y=fallback.y, z=fallback.z, facing=facing}
  end

  lastPlayerCell = {cx=cx, cz=cz, y=y, facing=facing}
end

local function updateTrail(player, map)
  local cx, cz = playerCell(player)
  local facing = player.facing or "down"
  local y = tonumber(player.y) or 0

  if not lastPlayerCell then
    resetTrail(player, map)
    return
  end

  if cx ~= lastPlayerCell.cx or cz ~= lastPlayerCell.cz then
    -- The first follower goes to the exact tile the trainer left.
    -- Older trail entries shift backward for followers 2-6.
    map = map or liveMap()
    -- A player cell from the previous frame should normally be valid.  Around
    -- warps, however, snapshot timing can briefly expose an out-of-map/filler
    -- coordinate. Do not feed that coordinate into the follower train.
    if safeCell(map,lastPlayerCell.cx,lastPlayerCell.cz) then
      local old = tileCenter(lastPlayerCell.cx, lastPlayerCell.cz, lastPlayerCell.y)
      table.insert(trail, 1, {
        x=old.x, y=old.y, z=old.z, facing=facing
      })
    else
      local here=tileCenter(cx,cz,y)
      table.insert(trail,1,{x=here.x,y=here.y,z=here.z,facing=facing})
    end
    while #trail > 6 do table.remove(trail) end
  end

  lastPlayerCell = {cx=cx, cz=cz, y=y, facing=facing}

  for slot = 1, 6 do
    local e = followers[slot]
    local t = trail[slot]
    if e and t then
      e.target = {x=t.x, y=t.y, z=t.z, facing=t.facing}
    end
  end
end

-- ------------------------------------------------------------
-- Movement
-- ------------------------------------------------------------

local function moveEntry(entry, dt, map, surfing)
  if not (entry and entry.actor and entry.current and entry.target) then return end
  dt = math.max(0, math.min(0.1, tonumber(dt) or (1/60)))

  local c, t = entry.current, entry.target
  local finalX,finalZ=t.x,t.z
  local ccx=math.floor(((tonumber(c.x) or 8)-8)/CELL+0.5)
  local ccz=math.floor(((tonumber(c.z) or 8)-8)/CELL+0.5)
  local tcx=math.floor(((tonumber(finalX) or 8)-8)/CELL+0.5)
  local tcz=math.floor(((tonumber(finalZ) or 8)-8)/CELL+0.5)

  -- The trail is made from cells the trainer actually occupied, but a lagging
  -- follower can otherwise cut diagonally across the corner of a wall while
  -- catching up. Aim first at a legal neighbouring cell, one grid step at a
  -- time, so the rendered model follows the collision grid too.
  local aimX,aimZ=finalX,finalZ
  if map and (ccx~=tcx or ccz~=tcz) then
    local candidates={}
    local sx=(tcx>ccx and 1) or (tcx<ccx and -1) or 0
    local sz=(tcz>ccz and 1) or (tcz<ccz and -1) or 0
    if sx~=0 then candidates[#candidates+1]={ccx+sx,ccz,sx>0 and "right" or "left"} end
    if sz~=0 then candidates[#candidates+1]={ccx,ccz+sz,sz>0 and "down" or "up"} end
    local chosen=nil
    for _,n in ipairs(candidates) do
      if safeCell(map,n[1],n[2]) and stepAllowed(map,ccx,ccz,n[3]) then chosen=n break end
    end
    if chosen then
      local wp=tileCenter(chosen[1],chosen[2],t.y)
      aimX,aimZ=wp.x,wp.z
    elseif safeCell(map,tcx,tcz) then
      -- Do not tunnel through a blocked edge. Hold position until the historical
      -- trail advances to a reachable cell; the normal long-distance recovery
      -- below can still catch up after transitions.
      aimX,aimZ=c.x,c.z
    end
  end

  local dx, dz = aimX - c.x, aimZ - c.z
  local fullDx,fullDz=finalX-c.x,finalZ-c.z
  local fullDist=math.sqrt(fullDx*fullDx+fullDz*fullDz)
  local dist = math.sqrt(dx*dx + dz*dz)
  local moving = dist > 0.15

  if fullDist > TELEPORT_DISTANCE then
    -- Recovery is allowed only onto a valid target tile. This avoids teleporting
    -- a delayed follower into black map filler after a warp.
    if not map or safeCell(map,tcx,tcz) then
      c.x, c.y, c.z = finalX, t.y, finalZ
    end
    moving = false
  elseif moving then
    local catchup = 1.0
    if fullDist > CELL * 2.25 then
      catchup = 2.0
    elseif fullDist > CELL * 1.75 then
      catchup = 1.75
    elseif fullDist > CELL * 1.25 then
      catchup = 1.35
    end
    local step = math.min(dist, FOLLOW_SPEED * catchup * dt)
    c.x = c.x + dx / dist * step
    c.z = c.z + dz / dist * step
    c.y = c.y + ((t.y or c.y) - c.y) * math.min(1, dt * 16)
  elseif ccx==tcx and ccz==tcz then
    c.x, c.y, c.z = finalX, t.y, finalZ
  end

  local yaw = moving and math.atan2(dx, dz) or yawForFacing(t.facing)
  entry.actor:setPosition(c.x, c.y, c.z)
  entry.actor:setYaw(yaw)
  entry.actor:setVisible(false)

  local anim
  if surfing then
    -- Tentacruel is the one explicit Surf-animation exception: its authored
    -- aquatic locomotion T-poses in this renderer, so it follows in normal idle.
    if tonumber(entry.dex)==73 then
      anim="idle"
    elseif actorHasState(entry, "surf") then
      anim="surf"
    elseif actorHasState(entry, "fly") then
      anim="fly"
    else
      -- Never show a land/idle pose on the water. ensureFollowers normally
      -- removes these before render; keep this guard so a stale actor cannot
      -- flash for one frame during a Surf transition.
      entry.actor:setVisible(false)
      return
    end
  else
    anim=moving and "walk" or "idle"
  end
  if entry.lastAnim ~= anim then
    entry.actor:setAnimation(anim)
    entry.lastAnim = anim
  end
  entry.actor:update(dt)
end

-- ------------------------------------------------------------
-- Toon render
-- ------------------------------------------------------------

local function drawActor(entry)
  local actor = entry and entry.actor
  if not (actor and Voxel3D and type(Voxel3D.draw) == "function") then return end

  local matrix = actor:matrix()
  if type(Voxel3D.seams) == "function" then pcall(Voxel3D.seams, false) end
  if type(Voxel3D.glass) == "function" then pcall(Voxel3D.glass, false) end

  local black = blackTexture()
  if outlineEnabled() and black and love and love.graphics and love.graphics.setDepthMode then
    pcall(love.graphics.setDepthMode, "lequal", false)
    for _, part in ipairs(actor.rig.parts or {}) do
      if part.outlineMesh then
        pcall(Voxel3D.draw, part.outlineMesh, black, matrix, 0, matrix)
      end
    end
    pcall(love.graphics.setDepthMode, "lequal", true)
  end

  for _, part in ipairs(actor.rig.parts or {}) do
    if part.mesh and part.texture then
      pcall(Voxel3D.draw, part.mesh, part.texture, matrix, 0, matrix)
    end
  end

  -- Water reflection for Cobblemon followers. Mirror the already-animated model
  -- around the follower's water plane. This is render-only and has no collision.
  if lastSurfing==true then
    local importer=findImporter()
    local M=importer and importer.Mat4
    if M and M.mul and M.translate and M.scale then
      local wy=tonumber(actor.y) or 0
      local reflect=M.mul(M.mul(M.translate(0,2*wy,0),M.scale(1,-1,1)),matrix)
      for _, part in ipairs(actor.rig.parts or {}) do
        if part.mesh and part.texture then
          pcall(Voxel3D.draw, part.mesh, part.texture, reflect, 0, reflect)
        end
      end
    end
  end

  if type(Voxel3D.glass) == "function" then pcall(Voxel3D.glass, true) end
  if type(Voxel3D.seams) == "function" then pcall(Voxel3D.seams, true) end
end

-- ------------------------------------------------------------
-- Companion registration
-- ------------------------------------------------------------

local companion = findDramaless()
if not companion then
  error("RUMBLE_FOLLOWER: COBBLEMONE_GEN2 compatible voxel_companion API unavailable", 0)
end

local spec = {
  api = 1,
  id = "rumble.followers",
  name = "Cobblemon Pokemon Followers",
  version = "0.3.5",
  priority = 30,
  requires = {"render_phases", "world_snapshot"},
  optional = {},

  attach = function(_services)
    servicesReady = true
  end,

  worldChanged = function(_world)
    -- Do not blindly clear followers here. Gen1Recomp also fires worldChanged
    -- for seamless route/town connections. The render pass below distinguishes
    -- a real warp/door from a connected-map boundary using warp tiles.
  end,

  render = {
    opaque_after_terrain = function(context)
      local world = context and context.world
      -- Keep the render-world player as the positional source.  It has the
      -- cell/facing/position fields this follower renderer has always used.
      -- Read only the Surfing boolean from the live overworld player.
      local player = world and world.player
      local surfing = playerIsSurfing(player, world)
      if not (servicesReady and player and world and world.id) then return end

      -- Render-only Surf override: preserve the normal trainer presentation and
      -- suppress the native Lapras/Surf player graphic.  Detection happened
      -- before this override, and the live FieldMoves/playerState is untouched.
      if surfing then
        forceNormalPlayerPresentation(player)
        forceLiveNormalPlayerPresentation()
      else
        cacheNormalPlayerPresentation(player)
      end

      local mapChanged = (lastMap ~= nil and lastMap ~= world.id)
      local leftWater = (lastSurfing == true and surfing == false)
      local collisionMap = liveMap()

      if mapChanged then
        local pcx,pcz=playerCell(player)
        local oldWarp = lastPlayerCell and isWarpCell(lastCollisionMap,lastPlayerCell.cx,lastPlayerCell.cz) or false
        local newWarp = isWarpCell(collisionMap,pcx,pcz)
        if oldWarp or newWarp then
          -- Door / cave entrance / true map warp: discard the old map-local
          -- trail and stack everyone on the trainer until fresh interior trail
          -- cells are created. This prevents the black-space follower train.
          clearFollowers()
          stackTrailAtPlayer(player)
          stackNextSpawn = true
        else
          -- Seamless connection (e.g. New Bark Town <-> Route 29): do not stack.
          -- Map-local coordinates changed, so rebuild a valid formation directly
          -- behind the trainer on the new map and keep the existing actors.
          resetTrail(player, collisionMap)
          alignFollowersToTrail()
          stackNextSpawn = false
        end
      elseif leftWater then
        -- Surf -> land: returning hidden followers start together on the trainer,
        -- never back on the water tile they were suppressed from.
        clearFollowers()
        stackTrailAtPlayer(player)
        stackNextSpawn = true
      end

      lastMap = world.id
      ensureFollowers(player, surfing)
      if stackNextSpawn then
        -- Keep this frame fully stacked; do not manufacture behind-the-player
        -- history at a doorway or shore transition.
        stackTrailAtPlayer(player)
      else
        updateTrail(player, collisionMap)
      end

      -- Surf mount presentation (experimental): reuse follower slot 1 as the
      -- mount.  Do not spawn a second Pokemon and do not alter native Surf
      -- movement/collision.  While Surfing, pin the existing first permitted
      -- follower to the trainer's exact world position so the trainer sprite is
      -- drawn over the Pokemon instead of the Pokemon trailing one tile behind.
      -- Other followers continue to use the normal trail.
      if surfing then
        local mount=followers[1]
        if mount and surfFollowerAllowed(mount.dex,mount) then
          local px=tonumber(player.x)
          local py=tonumber(player.y)
          local pz=tonumber(player.z)
          if px and pz then
            py=py or (mount.current and mount.current.y) or 0
            -- Put the Pokemon underneath the trainer instead of sharing the
            -- trainer sprite plane.  This is visual only; player collision stays native.
            local mountY=py-6.0
            mount.target={x=px,y=mountY,z=pz,facing=player.facing or "down"}
            -- Snap X/Z so the mount cannot lag behind the rider while turning.
            -- Y stays on the native water/player plane; model-authored offsets
            -- remain inside the Cobblemon actor itself.
            mount.current.x=px
            mount.current.z=pz
            mount.current.y=mountY
          end
        end
      end

      local frame = context.frame or {}
      local dt = frame.dt or (1/60)
      for slot = 1, 6 do
        local entry = followers[slot]
        if entry then
          moveEntry(entry, dt, collisionMap, surfing)
          drawActor(entry)
        end
      end
      stackNextSpawn = false
      lastSurfing = surfing
      lastCollisionMap = collisionMap
    end,
  },

  invalidate = function()
    trail = {}
    lastPlayerCell = nil
    lastSurfing = nil
    lastCollisionMap = nil
    stackNextSpawn = true
  end,

  dispose = function()
    clearFollowers()
    if BLACK_TEXTURE and BLACK_TEXTURE.release then
      pcall(BLACK_TEXTURE.release, BLACK_TEXTURE)
    end
    BLACK_TEXTURE = nil
  end,
}

local handle, err = companion.register(spec)
if not handle then
  error("RUMBLE_FOLLOWER registration failed: "..tostring(err), 0)
end

if mod.events and type(mod.events.on) == "function" then
  mod.events:on("mod.options_changed", function(payload)
    if payload and payload.mod == mod.id then
      -- Rebuild on next render so changing 1 -> 6 or OFF is immediate.
      clearFollowers()
      trail = {}
      lastPlayerCell = nil
    end
  end)
end

mod.exports.cobblemon_follower = {
  api = 1,
  version = "0.3.5",
  getCount = getCount,
  getFollower = function(slot)
    local e = followers[tonumber(slot) or 1]
    return e and e.actor or nil
  end,
  getLeadDex = function() return dexOfPartySlot(1) end,
}
