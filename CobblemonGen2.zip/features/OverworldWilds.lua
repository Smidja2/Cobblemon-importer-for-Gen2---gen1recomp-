local mod = ...
local function liveGame()
  local g=mod and mod.game
  return type(g)=="table" and g or nil
end
local Game=setmetatable({}, {
  __index=function(_,k)
    local g=liveGame()
    if not g then return nil end
    if k=="overworld" then return g.overworld or g.world end
    return g[k]
  end,
  __newindex=function(_,k,v)
    local g=liveGame(); if g then g[k]=v end
  end
})
local CELL = 16
local GRASS_TARGET = 3 -- .18 fallback only
local OUTSIDE_TARGET = 5 -- .18 fallback only
local MAX_WILDS = GRASS_TARGET + OUTSIDE_TARGET
local MIN_RADIUS = 3
local MAX_RADIUS = 8
local DESPAWN_RADIUS = 13 -- retained for .18 fallback; route-wide populations are not player-culled

-- Precomputed outdoor route dimensions (map blocks). These are data only;
-- the spawner does not rescan/count a route every frame. Route 29 uses the
-- 39x9 layout supplied/tested for this setup. Other entries follow GSC map data.
local ROUTE_SIZE = {
  ROUTE_1={10,18}, ROUTE_2={10,27}, ROUTE_3={30,9}, ROUTE_4={20,9},
  ROUTE_5={10,9}, ROUTE_6={10,9}, ROUTE_7={10,9}, ROUTE_8={20,9},
  ROUTE_9={30,9}, ROUTE_10_NORTH={10,9}, ROUTE_10_SOUTH={10,9},
  ROUTE_11={20,9}, ROUTE_12={10,27}, ROUTE_13={30,9}, ROUTE_14={10,18},
  ROUTE_15={20,9}, ROUTE_16={10,9}, ROUTE_17={10,45}, ROUTE_18={10,9},
  ROUTE_19={10,18}, ROUTE_20={30,9}, ROUTE_21={10,18}, ROUTE_22={20,9},
  ROUTE_23={10,9}, ROUTE_24={10,9}, ROUTE_25={30,9}, ROUTE_26={10,54},
  ROUTE_27={40,9}, ROUTE_28={20,9}, ROUTE_29={39,9}, ROUTE_30={10,27},
  ROUTE_31={20,9}, ROUTE_32={10,45}, ROUTE_33={10,9}, ROUTE_34={10,27},
  ROUTE_35={10,18}, ROUTE_36={30,9}, ROUTE_37={10,9}, ROUTE_38={20,9},
  ROUTE_39={10,18}, ROUTE_40={10,18}, ROUTE_41={25,27}, ROUTE_42={30,9},
  ROUTE_43={10,27}, ROUTE_44={30,9}, ROUTE_45={10,45}, ROUTE_46={10,18},
}
local POP_DENSITY = 25 -- about one normal overworld wild per 25 map blocks
local POP_MIN = 3
local POP_MAX = 18
local GRASS_SHARE = 0.70

local function populationTargets(map)
  local id=tostring(map and map.id or ''):upper()
  local sz=ROUTE_SIZE[id]
  if not sz then return GRASS_TARGET,OUTSIDE_TARGET end
  local total=math.floor((sz[1]*sz[2])/POP_DENSITY+0.5)
  total=math.max(POP_MIN,math.min(POP_MAX,total))
  local grassTarget=math.max(1,math.floor(total*GRASS_SHARE+0.5))
  local outsideTarget=math.max(0,total-grassTarget)
  return grassTarget,outsideTarget
end
local SPAWN_DELAY = 0.55
local INITIAL_SPAWN_TARGET = MAX_WILDS
local INITIAL_SPAWN_ATTEMPTS = 48
local WALK_SPEED = 34
local FLEE_SPEED = 54
local FLEE_REPATH = 0.18
local WANDER_MIN = 0.80
local WANDER_MAX = 2.40
local FLY_ENTRY_HEIGHT = 46
local FLY_SETTLE_HEIGHT = 15
local FLY_ENTRY_TIME = 0.70
local LEVITATE_SETTLE_HEIGHT = 10
local LEVITATE_ENTRY_HEIGHT = 28
local LEVITATE_ENTRY_TIME = 0.52
local GHOST_TOSS_HEIGHT = 24
local GHOST_TOSS_TIME = 0.46
local GROUND_EMERGE_DEPTH = 9
local GROUND_EMERGE_TIME = 0.42
local BUCKETS = {51,102,141,166,191,216,229,242,253,256}


-- Unified Cobblemon option: Overworld Wilds YES / NO
local WILDS_KEY="overworld_wilds"
local function wildsEnabled()
  local loader=Game and Game.mods
  local stored=loader and loader.modOptions and loader.modOptions[mod.id]
  local v=stored and stored[WILDS_KEY]

  if v==nil then
    local opts=Game and Game.save and Game.save.options
    stored=opts and opts.modOptions and opts.modOptions[mod.id]
    v=stored and stored[WILDS_KEY]
  end

  if v==nil then return true end
  return v~=false and v~=0 and v~="NO" and v~="OFF"
end
local function setWilds(game,value)
  local opts=game and game.save and game.save.options
  if opts then
    opts.modOptions=opts.modOptions or {}; opts.modOptions[mod.id]=opts.modOptions[mod.id] or {}
    opts.modOptions[mod.id][WILDS_KEY]=value
  end
  local loader=game and game.mods
  if loader then
    loader.modOptions=loader.modOptions or {}; loader.modOptions[mod.id]=loader.modOptions[mod.id] or {}
    loader.modOptions[mod.id][WILDS_KEY]=value
  end
  if game and game.writeOptions then pcall(game.writeOptions,game) end
end

local wilds = {}
local mapId = nil
local spawnClock = 0
local needsInitialFill = true
local servicesReady = false
local Voxel3D = nil
local BLACK_TEXTURE = nil

local function rnd(a,b)
  if love and love.math and love.math.random then return love.math.random(a,b) end
  return math.random(a,b)
end
local function rnd01()
  if love and love.math and love.math.random then return love.math.random() end
  return math.random()
end

local function findImporter()
  local api = mod.exports and (mod.exports.cobblemon_main or mod.exports.cobblemon_importer)
  if api and tonumber(api.api)==1 and type(api.createActor)=="function" then return api end
  if not (mod and type(mod.find)=="function") then return nil end
  local ok,host=pcall(mod.find,"COBBLEMONE_GEN2")
  if not ok or not host then return nil end
  api=host.exports and (host.exports.cobblemon_main or host.exports.cobblemon_importer)
  if not api or tonumber(api.api)~=1 or type(api.createActor)~="function" then return nil end
  return api
end

local function findDramaless()
  local api=mod.exports and mod.exports.voxel_companion
  local importer=mod.exports and (mod.exports.cobblemon_main or mod.exports.cobblemon_importer)
  if api and tonumber(api.api)==1 and type(api.register)=="function" then
    if importer and type(importer.Voxel3D)=="function" then
      local okv,v=pcall(importer.Voxel3D)
      if okv and v and type(v.draw)=="function" then Voxel3D=v end
    end
    return api
  end
  if not (mod and type(mod.find)=="function") then return nil end
  local ok,host=pcall(mod.find,"COBBLEMONE_GEN2")
  if not ok or not host then return nil end
  api=host.exports and host.exports.voxel_companion
  importer=host.exports and (host.exports.cobblemon_main or host.exports.cobblemon_importer)
  if not api or tonumber(api.api)~=1 or type(api.register)~="function" then return nil end
  if importer and type(importer.Voxel3D)=="function" then
    local okv,v=pcall(importer.Voxel3D)
    if okv and v and type(v.draw)=="function" then Voxel3D=v end
  end
  return api
end

local function outlineEnabled()
  local api=findImporter()
  if api and type(api.outlineEnabled)=="function" then
    local ok,v=pcall(api.outlineEnabled)
    if ok then return v~=false end
  end
  return false
end

local function blackTexture()
  if BLACK_TEXTURE then return BLACK_TEXTURE end
  if not (love and love.image and love.graphics and love.image.newImageData and love.graphics.newImage) then return nil end
  local ok, data = pcall(love.image.newImageData,1,1)
  if not ok or not data then return nil end
  pcall(data.setPixel,data,0,0,0,0,0,1)
  local ok2,img=pcall(love.graphics.newImage,data)
  if ok2 and img then BLACK_TEXTURE=img end
  return BLACK_TEXTURE
end

local function dexOfSpecies(species)
  if type(species)=="number" then
    local n=math.floor(species)
    if n>=1 and n<=251 then return n end
  end
  if species~=nil and mod and mod.content and mod.content.pokemon
      and type(mod.content.pokemon.get)=="function" then
    local ok,rec=pcall(mod.content.pokemon.get,mod.content.pokemon,species)
    local dex=ok and rec and tonumber(rec.dex) or nil
    if dex then
      dex=math.floor(dex)
      if dex>=1 and dex<=493 then return dex end
    end
  end
  local data=Game and Game.data
  local pokemon=data and data.pokemon
  if type(pokemon)~="table" or species==nil then return nil end
  local key=tostring(species):upper()
  local def=pokemon[species] or pokemon[key]
  local dex=def and tonumber(def.dex)
  if dex then
    dex=math.floor(dex)
    if dex>=1 and dex<=493 then return dex end
  end
  for k,v in pairs(pokemon) do
    if type(v)=="table" then
      local n=tostring(v.name or v.species or ""):upper()
      if n==key then
        local d=tonumber(v.dex) or tonumber(k)
        if d and d>=1 and d<=251 then return math.floor(d) end
      end
    end
  end
  return nil
end

local function speciesOfDex(dex)
  dex=tonumber(dex)
  if not dex then return nil end
  dex=math.floor(dex)
  if mod and mod.content and mod.content.pokemon and type(mod.content.pokemon.get)=="function" then
    -- Numeric lookup is supported by the Gen2 pokemon content registry in the
    -- same runtime used by the working Tohjo spawner.
    local ok,rec=pcall(mod.content.pokemon.get,mod.content.pokemon,dex)
    if ok and rec and tonumber(rec.dex)==dex then return rec.id or rec.species or dex end
  end
  local data=Game and Game.data
  local pokemon=data and data.pokemon
  if type(pokemon)~="table" then return nil end
  for k,v in pairs(pokemon) do
    if type(v)=="table" then
      local d=tonumber(v.dex) or tonumber(k)
      if d and math.floor(d)==dex then
        return v.id or v.species or k
      end
    end
  end
  return nil
end



-- v0.7.2.60: hardcoded visible-overworld species tables.
-- IMPORTANT: the native resolver is used ONLY as a time-of-day probe here.
-- Species selection for listed maps comes from this table, while the existing
-- map/division placement, population management and actor movement stay intact.
local HARDCODED_OVERWORLD = {
  ROUTE_29 = {
    MORNING={16,19,161}, DAY={16,19,161}, NIGHT={163,19},
  },
  ROUTE_30 = {
    MORNING={10,13,16}, DAY={10,13,16}, NIGHT={163},
  },
  ROUTE_38 = {
    MORNING={19,20,81,209,128,241},
    DAY={19,20,81,209,128,241},
    NIGHT={19,20,81,52},
  },
}

local function resolverHas(map,dex)
  if not (mod.world and type(mod.world.effectiveEncounters)=="function") then return false end
  local ok,res=pcall(mod.world.effectiveEncounters,mod.world,map,"grass")
  if not (ok and type(res)=="table") then return false end
  for sp in pairs(res.dist or {}) do
    if dexOfSpecies(sp)==dex then return true end
  end
  return false
end

local function currentDayPart()
  -- Proven native encounter resolver as a clock probe; no invented clock API.
  -- Route 29 exposes Hoothoot at night. Route 30's Ledyba distinguishes
  -- morning in Crystal; if neither probe is active, use DAY.
  if resolverHas("ROUTE_29",163) then return "NIGHT" end
  if resolverHas("ROUTE_30",165) then return "MORNING" end
  return "DAY"
end

local function hardcodedEncounter(id)
  local row=HARDCODED_OVERWORLD[tostring(id or ""):upper()]
  if not row then return nil end
  local part=currentDayPart()
  local pool=row[part] or row.DAY or row.MORNING or row.NIGHT
  if type(pool)~="table" or #pool==0 then return nil end
  return {__hardcoded=true,id=id,part=part,pool=pool}
end

local function ensureEncounterAlias()
  local data=Game and Game.data
  if data and data.encounters==nil and data.gen2Encounters~=nil then
    data.encounters=data.gen2Encounters
  end
end
local function encounterDef(id)
  ensureEncounterAlias()
  local hard=hardcodedEncounter(id)
  if hard then return hard end
  -- Unlisted maps temporarily keep the existing native resolver until their
  -- MORNING/DAY/NIGHT tables are added.
  if mod.world and type(mod.world.effectiveEncounters)=="function" then
    local ok,res=pcall(mod.world.effectiveEncounters,mod.world,id,"grass")
    if ok and type(res)=="table" and next(res.dist or {}) then
      return {__gen2=true,id=id,res=res}
    end
  end
  local e=Game and Game.data and Game.data.encounters
  return type(e)=="table" and e[id] or nil
end
local function grassTable(enc)
  if enc and (enc.__gen2 or enc.__hardcoded) then return enc end
  local t=enc and enc.grass
  if type(t)~="table" or type(t.slots)~="table" or #t.slots==0 then return nil end
  if (tonumber(t.rate) or 0)<=0 then return nil end
  return t
end
local function gen2Level(mapId,species)
  local e=Game and Game.data and Game.data.encounters
  local row=e and e.grass and e.grass[mapId]
  local slots=row and row.slots
  local sum,n,any=0,0,nil
  local function scan(list)
    for _,slot in ipairs(list or {}) do
      if type(slot)=="table" and slot.level then
        any=any or slot.level
        if slot.species==species then sum=sum+slot.level;n=n+1 end
      end
    end
  end
  if type(slots)=="table" then
    if slots[1] then scan(slots) else for _,list in pairs(slots) do if type(list)=="table" then scan(list) end end end
  end
  return n>0 and math.floor(sum/n+0.5) or any or 5
end
local function pickEncounter(enc)
  local t=grassTable(enc)
  if not t then return nil end
  if t.__hardcoded then
    local dex=t.pool[rnd(1,#t.pool)]
    local species=speciesOfDex(dex)
    if not species then return nil end
    return dex,gen2Level(t.id,species),species
  end
  if t.__gen2 then
    local dist=t.res and t.res.dist or {}
    local total=0; for _,wt in pairs(dist) do total=total+(tonumber(wt) or 0) end
    if total<=0 then return nil end
    local roll=rnd01()*total
    local species
    for sp,wt in pairs(dist) do roll=roll-(tonumber(wt) or 0); if roll<=0 then species=sp;break end end
    species=species or next(dist)
    return dexOfSpecies(species),gen2Level(t.id,species),species
  end
  local buckets=t.buckets or BUCKETS
  local p=rnd(0,255)
  for i,thr in ipairs(buckets) do
    if p<thr then
      local slot=t.slots[i] or t.slots[#t.slots]
      if slot and slot.species then return dexOfSpecies(slot.species),slot.level or 1,slot.species end
      return nil
    end
  end
  local slot=t.slots[#t.slots]
  if slot and slot.species then return dexOfSpecies(slot.species),slot.level or 1,slot.species end
  return nil
end

local VISUAL_AERIAL={
  [12]=true,[15]=true,[16]=true,[17]=true,[18]=true,[21]=true,[22]=true,
  [41]=true,[42]=true,[49]=true,[83]=true,
  [163]=true,[164]=true,[165]=true,[166]=true,[169]=true,[176]=true,
  [177]=true,[178]=true,[187]=true,[188]=true,[189]=true,[193]=true,
  [198]=true,[225]=true,[226]=true,[227]=true,
}
-- Slow local hoverers: they levitate above valid terrain instead of walking.
local VISUAL_LEVITATING={
  [81]=true,[82]=true,       -- Magnemite / Magneton
  [92]=true,[93]=true,       -- Gastly / Haunter
  [109]=true,[110]=true,     -- Koffing / Weezing
}
local GHOST_LEVITATING={ [92]=true,[93]=true }

local function speciesDef(species,dex)
  local pokemon=Game and Game.data and Game.data.pokemon
  if type(pokemon)~="table" then return nil end
  return pokemon[species] or pokemon[tostring(species or ""):upper()] or pokemon[dex]
end
local function aerialDex(dex,species)
  if VISUAL_AERIAL[dex] then return true end
  local def=speciesDef(species,dex)
  if type(def)~="table" then return false end
  local types=def.types or def.type
  if type(types)=="string" then return types:upper():find("FLYING",1,true)~=nil end
  if type(types)=="table" then
    for _,t in pairs(types) do
      if tostring(t):upper()=="FLYING" then return true end
    end
  end
  return false
end

local WILDERNESS_HINTS={
  "FOREST","CAVE","MT_","MOON","ROCK_TUNNEL","DIGLETT","POKEMON_TOWER",
  "SEAFOAM","VICTORY_ROAD","POWER_PLANT","MANSION","UNKNOWN_DUNGEON","CERULEAN_CAVE",
  "ILEX_FOREST","DARK_CAVE","UNION_CAVE","SLOWPOKE_WELL","WHIRL_ISLAND",
  "ICE_PATH","MT_MORTAR","MT_SILVER","BURNED_TOWER","NATIONAL_PARK"
}
local WILDERNESS_TILESETS={FOREST=true,CAVERN=true,CEMETERY=true,FACILITY=true,MANSION=true}
local function routeMap(map)
  if not map then return false end
  local id=tostring(map.id or ""):upper()
  return id:match("^ROUTE_?%d+$")~=nil
end

local function wilderness(map)
  if not map then return false end
  local id=tostring(map.id or ""):upper()
  local ts=tostring(map.def and map.def.tileset or ""):upper()
  if WILDERNESS_TILESETS[ts] then return true end
  for _,h in ipairs(WILDERNESS_HINTS) do if id:find(h,1,true) then return true end end
  return false
end

local function cemeteryLike(map)
  if not map then return false end
  local id=tostring(map.id or ""):upper()
  local ts=tostring(map.def and map.def.tileset or ""):upper()
  return ts=="CEMETERY" or id:find("POKEMON_TOWER",1,true)~=nil
end

local function inBounds(map,x,z)
  return map and map.inBounds and map:inBounds(x,z)
end
local function grass(map,x,z)
  return inBounds(map,x,z) and map.isGrassCell and map:isGrassCell(x,z)
end
local function walkable(map,x,z)
  return inBounds(map,x,z) and map.isWalkableCell and map:isWalkableCell(x,z)
end
local function forestLike(map)
  if not map then return false end
  local id=tostring(map.id or ""):upper()
  local ts=tostring(map.def and map.def.tileset or ""):upper()
  return ts:find("FOREST",1,true)~=nil or id:find("FOREST",1,true)~=nil
end
local function treeEdge(map,x,z)
  if not walkable(map,x,z) then return false end
  -- Never spawn inside the tree/wall. A tree-edge spawn is a passable cell
  -- immediately beside at least one blocked cell, so the Pokemon appears to
  -- emerge from foliage while remaining on valid terrain.
  local dirs={{1,0},{-1,0},{0,1},{0,-1}}
  for _,d in ipairs(dirs) do
    local nx,nz=x+d[1],z+d[2]
    if inBounds(map,nx,nz) and not walkable(map,nx,nz) then return true end
  end
  return false
end

local function playerCell(ow)
  if mod.world and type(mod.world.current)=="function" then
    local ok,cur=pcall(mod.world.current,mod.world)
    if ok and type(cur)=="table" and cur.x~=nil and cur.y~=nil then
      return tonumber(cur.x),tonumber(cur.y)
    end
  end
  local p=ow and ow.player
  if not p then return nil,nil end
  return tonumber(p.cellX), tonumber(p.cellY or p.cellZ)
end

local function occupied(ow,x,z)
  local px,pz=playerCell(ow)
  if px==x and pz==z then return true end
  for _,e in ipairs(ow and ow.entities or {}) do
    if e then
      local ex=tonumber(e.cellX)
      local ez=tonumber(e.cellY or e.cellZ)
      if ex==x and ez==z then return true end
    end
  end
  for _,w in ipairs(wilds) do
    if w.cellX==x and w.cellZ==z then return true end
    if w.targetX==x and w.targetZ==z then return true end
  end
  return false
end

local function nearbyGrass(ow)
  local map=ow.map
  local px,pz=playerCell(ow)
  if not px then return false end
  for dz=-MAX_RADIUS,MAX_RADIUS do
    for dx=-MAX_RADIUS,MAX_RADIUS do
      if grass(map,px+dx,pz+dz) then return true end
    end
  end
  return false
end

local function candidate(ow,useWalkable,preferOutsideGrass)
  local map=ow and ow.map
  -- widthCells/heightCells are existing live-map fields used by the Gen2
  -- overworld API. Pick across the WHOLE current map instead of around player.
  local W=map and tonumber(map.widthCells)
  local H=map and tonumber(map.heightCells)
  if W and H and W>0 and H>0 then
    W,H=math.floor(W),math.floor(H)
    for _=1,180 do
      local x,z=rnd(0,W-1),rnd(0,H-1)
      local ok
      if useWalkable then
        ok=walkable(map,x,z)
        if ok and preferOutsideGrass then ok=not grass(map,x,z) end
      else
        ok=grass(map,x,z)
      end
      if ok and not occupied(ow,x,z) then return x,z end
    end
  end

  -- Exact v0.7.2.18 player-centered fallback if map dimensions are unavailable
  -- or the route-wide random attempts cannot find a valid tile.
  local px,pz=playerCell(ow)
  if not px then return nil end
  for _=1,100 do
    local dx=rnd(-MAX_RADIUS,MAX_RADIUS)
    local dz=rnd(-MAX_RADIUS,MAX_RADIUS)
    local d=math.abs(dx)+math.abs(dz)
    if d>=MIN_RADIUS and d<=MAX_RADIUS then
      local x,z=px+dx,pz+dz
      local ok
      if useWalkable then
        ok=walkable(map,x,z)
        if ok and preferOutsideGrass then ok=not grass(map,x,z) end
      else
        ok=grass(map,x,z)
      end
      if ok and not occupied(ow,x,z) then return x,z end
    end
  end
  return nil
end

local function candidateTreeEdge(ow)
  local px,pz=playerCell(ow)
  if not px then return nil end
  for _=1,120 do
    local dx=rnd(-MAX_RADIUS,MAX_RADIUS)
    local dz=rnd(-MAX_RADIUS,MAX_RADIUS)
    local d=math.abs(dx)+math.abs(dz)
    if d>=MIN_RADIUS and d<=MAX_RADIUS then
      local x,z=px+dx,pz+dz
      if treeEdge(ow.map,x,z) and not occupied(ow,x,z) then return x,z end
    end
  end
  return nil
end

local function yawForFacing(f)
  if f=="right" then return math.pi*0.5 end
  if f=="up" then return math.pi end
  if f=="left" then return -math.pi*0.5 end
  return 0
end
local function tilePos(x,z,y)
  return x*CELL+8, tonumber(y) or 0, z*CELL+8
end

local function destroyWild(w)
  if not (w and w.actor) then return end
  local ok=pcall(function() w.actor:destroy() end)
  if not ok then
    local imp=findImporter()
    if imp and type(imp.destroyActor)=="function" then pcall(imp.destroyActor,w.actor) end
  end
end
local function clearWilds()
  for _,w in ipairs(wilds) do destroyWild(w) end
  wilds={}
  spawnClock=0
  needsInitialFill=true
end

local RANDOM_AIR_MIN_GAP=4.0
local RANDOM_AIR_MAX_GAP=11.0
local RANDOM_AIR_MIN_TIME=4.0
local RANDOM_AIR_MAX_TIME=9.0
local RANDOM_AIR_MIN_HEIGHT=2.0
local RANDOM_AIR_MAX_HEIGHT=4.5
local RANDOM_AIR_VERTICAL_SPEED=2.0

local function spawnOne(ow,world,instant,poolKind)
  local enc=encounterDef(ow.map.id)
  if not grassTable(enc) then return false end

  -- Species is chosen first so its movement type controls HOW it enters the
  -- overworld, while the encounter table remains the sole source of WHAT can
  -- spawn on this map.
  local dex,level,species=pickEncounter(enc)
  if not dex or not species then return false end
  local isAerial=aerialDex(dex,species)
  local isLevitating=VISUAL_LEVITATING[dex] or false
  local isGhostLevitator=GHOST_LEVITATING[dex] or false
  local isCocoon=(dex==11 or dex==14) -- Metapod / Kakuna

  local useWalkable=false
  local cx,cz

  -- Population is deliberately split into two independent route pools:
  -- exactly three grass occupants and five safe non-grass occupants. Species
  -- still come from this map's real grass encounter distribution.
  if poolKind=="grass" then
    useWalkable=false
    cx,cz=candidate(ow,false,false)
  elseif poolKind=="outside" then
    useWalkable=true
    cx,cz=candidate(ow,true,true)
  else
    return false
  end

  -- If a route has no suitable cell for the requested pool, do not silently
  -- move that slot into the other pool; refill will retry later.

  if not cx then return false end
  local imp=findImporter()
  if not imp then return false end
  local py=(world and world.player and world.player.y) or 0
  local x,floorY,z=tilePos(cx,cz,py)
  local settleY=isLevitating and (floorY+LEVITATE_SETTLE_HEIGHT) or floorY
  local ghostToss=(not instant) and isGhostLevitator and cemeteryLike(ow.map)
  local entryKind=isAerial and "fly_down"
      or (isLevitating and (ghostToss and "ghost_toss" or "levitate_in") or "emerge")
  local entryStartY
  if isAerial then
    entryStartY=floorY+FLY_ENTRY_HEIGHT
  elseif isLevitating then
    -- In cemeteries Gastly/Haunter burst upward from the slab/floor; elsewhere
    -- levitating species simply rise smoothly into their hover position.
    entryStartY=ghostToss and floorY or (floorY-GROUND_EMERGE_DEPTH)
  else
    entryStartY=floorY-GROUND_EMERGE_DEPTH
  end
  local startY=instant and settleY or entryStartY
  local facing=({"down","left","up","right"})[rnd(1,4)]
  local actor=imp.createActor(dex,{manual=true,visible=false,x=x,y=startY,z=z,yaw=yawForFacing(facing)})
  if not actor then return false end
  if actor.setGroundY then actor:setGroundY(floorY) end
  actor:setAnimation(isAerial and "fly" or "idle")
  actor:setPosition(x,startY,z)
  actor:setYaw(yawForFacing(facing))
  actor:setVisible(false)
  wilds[#wilds+1]={
    dex=dex,species=species,level=level,actor=actor,cellX=cx,cellZ=cz,pool=poolKind,
    current={x=x,y=startY,z=z},target=nil,facing=facing,
    nextMove=WANDER_MIN+rnd01()*(WANDER_MAX-WANDER_MIN),lastAnim=isAerial and "fly" or "idle",
    useWalkable=useWalkable,
    routeRoamer=routeMap(ow.map) and useWalkable,
    aerial=isAerial,levitating=isLevitating,ghostLevitator=isGhostLevitator,
    stationary=isCocoon,spawnY=floorY,settleY=settleY,
    randomFlight=nil,
    flightCooldown=RANDOM_AIR_MIN_GAP+rnd01()*(RANDOM_AIR_MAX_GAP-RANDOM_AIR_MIN_GAP),
    entry=(not instant) and {kind=entryKind,time=0,
      duration=isAerial and FLY_ENTRY_TIME or (isLevitating and (ghostToss and GHOST_TOSS_TIME or LEVITATE_ENTRY_TIME) or GROUND_EMERGE_TIME),
      startY=entryStartY,endY=settleY} or nil,
  }
  return true
end

local DIRS={{1,0,"right"},{-1,0,"left"},{0,1,"down"},{0,-1,"up"}}
local function chooseMove(w,ow)
  if rnd01()<0.35 then return end
  local d=DIRS[rnd(1,#DIRS)]
  local nx,nz=w.cellX+d[1],w.cellZ+d[2]
  local valid
  if w.pool=="outside" then valid=walkable(ow.map,nx,nz) and not grass(ow.map,nx,nz)
  else valid=grass(ow.map,nx,nz) end
  if not valid or occupied(ow,nx,nz) then return end
  local x,y,z=tilePos(nx,nz,w.current.y)
  w.target={x=x,y=y,z=z}
  w.targetX,w.targetZ=nx,nz
  w.facing=d[3]
end

local function wildIsAlive(target)
  if not target then return false end
  for _,w in ipairs(wilds) do
    if w==target then return true end
  end
  return false
end

local function chooseFleeMove(w,ow)
  if not (w and ow and ow.map and w.flee) then return false end
  local best,bestScore=nil,-math.huge
  local threatX=tonumber(w.flee.x) or w.current.x
  local threatZ=tonumber(w.flee.z) or w.current.z

  for _,d in ipairs(DIRS) do
    local nx,nz=w.cellX+d[1],w.cellZ+d[2]
    local valid=(w.pool=="outside") and (walkable(ow.map,nx,nz) and not grass(ow.map,nx,nz)) or grass(ow.map,nx,nz)
    if valid and not occupied(ow,nx,nz) then
      local tx,ty,tz=tilePos(nx,nz,w.current.y)
      local dx,dz=tx-threatX,tz-threatZ
      local score=dx*dx+dz*dz+rnd01()*40
      if score>bestScore then
        bestScore=score
        best={nx=nx,nz=nz,x=tx,y=ty,z=tz,facing=d[3]}
      end
    end
  end

  if not best then return false end
  w.target={x=best.x,y=best.y,z=best.z}
  w.targetX,w.targetZ=best.nx,best.nz
  w.facing=best.facing
  w.flee.repath=FLEE_REPATH
  return true
end

local function beginFlee(w,fromX,fromZ,duration)
  if not wildIsAlive(w) then return false end
  w.flee=w.flee or {}
  w.flee.x=tonumber(fromX) or w.current.x
  w.flee.z=tonumber(fromZ) or w.current.z
  w.flee.timer=math.max(tonumber(duration) or 3.5,w.flee.timer or 0)
  w.flee.repath=0
  return true
end

local function updateThreat(w,fromX,fromZ)
  if not (w and w.flee) then return false end
  w.flee.x=tonumber(fromX) or w.flee.x
  w.flee.z=tonumber(fromZ) or w.flee.z
  return true
end

local function nearestDex(dex,x,z,radius)
  dex=tonumber(dex)
  local best,bestD=nil,math.huge
  local r=tonumber(radius) or CELL*10
  for _,w in ipairs(wilds) do
    if w.dex==dex and w.current then
      local dx=w.current.x-(tonumber(x) or 0)
      local dz=w.current.z-(tonumber(z) or 0)
      local d=math.sqrt(dx*dx+dz*dz)
      if d<=r and d<bestD then
        best,bestD=w,d
      end
    end
  end
  return best,bestD
end

-- ESCAPE_NO_ENCOUNTER_GUARD: escape state returns before normal collision/encounter AI.
local function updateWild(w,ow,dt)
  dt=math.max(0,math.min(0.1,tonumber(dt) or 1/60))
  if w.escapeFinished then
    w.current=nil
    if w.actor then w.actor:destroy(); w.actor=nil end
    return
  end

  if w.entry then
    local e=w.entry
    e.time=(e.time or 0)+dt
    local t=math.min(1,e.time/math.max(0.01,e.duration or 0.5))
    -- Smoothstep keeps the arrival from snapping at either end.
    local q=t*t*(3-2*t)
    if e.kind=="ghost_toss" then
      -- Quick upward burst, slight overshoot, then settle back to hover height.
      local base=e.startY or w.current.y
      local target=e.endY or w.current.y
      local linear=base+(target-base)*q
      w.current.y=linear+math.sin(math.pi*t)*GHOST_TOSS_HEIGHT
    else
      w.current.y=(e.startY or w.current.y)+((e.endY or w.current.y)-(e.startY or w.current.y))*q
    end
    if e.kind=="fly_down" then
      -- Small forward drift makes aerial encounters read as flying in rather
      -- than vertically teleporting down.
      local yaw=yawForFacing(w.facing)
      w.current.x=w.current.x+math.sin(yaw)*7*dt*(1-t)
      w.current.z=w.current.z+math.cos(yaw)*7*dt*(1-t)
      w.actor:setYaw(yaw)
      if w.lastAnim~="fly" then w.actor:setAnimation("fly");w.lastAnim="fly" end
    else
      if w.lastAnim~="idle" then w.actor:setAnimation("idle");w.lastAnim="idle" end
    end
    w.actor:setPosition(w.current.x,w.current.y,w.current.z)
    w.actor:setVisible(false)
    w.actor:update(dt)
    if t>=1 then
      w.current.y=e.endY or w.current.y
      w.entry=nil
      w.nextMove=0.35+rnd01()*0.65
    end
    return
  end

  if w.escapeNoEncounter then
    local e=w.escapeNoEncounter
    e.time=(e.time or 0)+dt
    if e.phase=="fall" then
      e.vy=(e.vy or 0)-70*dt
      w.current.y=w.current.y+e.vy*dt
      w.current.x=w.current.x+(e.vx or 0)*dt
      w.current.z=w.current.z+(e.vz or 0)*dt
      if w.current.y<=(e.floorY or 0) then
        w.current.y=e.floorY or 0
        e.phase="flee"; e.time=0
      end
      w.actor:setVisible(true)
      w.actor:setPosition(w.current.x,w.current.y,w.current.z)
      w.actor:setYaw(e.yaw or 0)
      if w.lastAnim~="idle" then w.actor:setAnimation("idle"); w.lastAnim="idle" end
      w.actor:update(dt)
      return
    end

    local speed=e.speed or 34
    w.current.x=w.current.x+math.sin(e.yaw or 0)*speed*dt
    w.current.z=w.current.z+math.cos(e.yaw or 0)*speed*dt
    w.actor:setVisible(true)
    w.actor:setPosition(w.current.x,w.current.y,w.current.z)
    w.actor:setYaw(e.yaw or 0)
    if w.lastAnim~="walk" then w.actor:setAnimation("walk"); w.lastAnim="walk" end
    w.actor:update(dt)
    if e.time>4.0 then w.escapeFinished=true end
    return
  end

  if w.carried then
    local c=w.carried
    c.stale=(c.stale or 0)+dt
    if c.stale>0.75 then
      -- Carrier vanished/interrupted without normal cleanup: never leave this
      -- wild permanently suspended at the last carried coordinates.
      w.carried=nil
      w.actor:setVisible(true)
      return
    end
    w.target,w.targetX,w.targetZ=nil,nil,nil
    w.flee=nil
    w.current.x,w.current.y,w.current.z=c.x,c.y,c.z
    w.actor:setPosition(c.x,c.y,c.z)
    w.actor:setYaw(c.yaw or 0)
    w.actor:setVisible(false)
    if w.lastAnim~="idle" then w.actor:setAnimation("idle");w.lastAnim="idle" end
    w.actor:update(dt)
    return
  end

  if w.flee then
    w.flee.timer=(w.flee.timer or 0)-dt
    w.flee.repath=(w.flee.repath or 0)-dt
    if w.flee.timer<=0 then
      w.flee=nil
      w.nextMove=0.25+rnd01()*0.5
    elseif (not w.target) or w.flee.repath<=0 then
      chooseFleeMove(w,ow)
    end
  end

  if w.stationary and not w.flee then
    w.target,w.targetX,w.targetZ=nil,nil,nil
    w.nextMove=999999
  elseif w.target then
    local c,t=w.current,w.target
    local dx,dz=t.x-c.x,t.z-c.z
    local dist=math.sqrt(dx*dx+dz*dz)
    if dist<=0.15 then
      c.x,c.y,c.z=t.x,t.y,t.z
      w.cellX,w.cellZ=w.targetX,w.targetZ
      w.target,w.targetX,w.targetZ=nil,nil,nil
      if w.flee and w.flee.timer>0 then chooseFleeMove(w,ow) end
    else
      local speed=w.flee and FLEE_SPEED or WALK_SPEED
      local step=math.min(dist,speed*dt)
      c.x=c.x+dx/dist*step
      c.z=c.z+dz/dist*step
    end
  elseif w.flee and w.flee.timer>0 then
    chooseFleeMove(w,ow)
  else
    w.nextMove=w.nextMove-dt
    if w.nextMove<=0 then
      w.nextMove=WANDER_MIN+rnd01()*(WANDER_MAX-WANDER_MIN)
      chooseMove(w,ow)
    end
  end

  local moving=w.target~=nil
  local yaw=moving and math.atan2(w.target.x-w.current.x,w.target.z-w.current.z) or yawForFacing(w.facing)

  -- True levitators (Magnemite/Gastly/etc.) remain continuously above ground.
  if w.levitating and not w.carried then
    local hoverSpeed=1.55
    local hoverAmp=0.8
    w.hoverPhase=(w.hoverPhase or rnd01()*6.28318)+dt*hoverSpeed
    w.current.y=(w.settleY or w.current.y)+math.sin(w.hoverPhase)*hoverAmp
  elseif w.aerial and not w.carried then
    -- Flying types are ground-first. They periodically take a short random
    -- flight, then descend and resume native ground idle/walk.
    if not w.randomFlight then
      w.flightCooldown=(w.flightCooldown or 0)-dt
      if w.flightCooldown<=0 then
        w.randomFlight={
          phase="takeoff",
          height=RANDOM_AIR_MIN_HEIGHT+rnd01()*(RANDOM_AIR_MAX_HEIGHT-RANDOM_AIR_MIN_HEIGHT),
          timer=RANDOM_AIR_MIN_TIME+rnd01()*(RANDOM_AIR_MAX_TIME-RANDOM_AIR_MIN_TIME),
          bob=rnd01()*6.28318,
        }
      end
    end

    local rf=w.randomFlight
    if rf then
      if rf.phase=="takeoff" then
        local target=w.spawnY+rf.height
        w.current.y=math.min(target,w.current.y+RANDOM_AIR_VERTICAL_SPEED*dt)
        if w.current.y>=target-0.02 then rf.phase="airborne" end
      elseif rf.phase=="airborne" then
        rf.timer=rf.timer-dt
        rf.bob=(rf.bob or 0)+dt*2.2
        w.current.y=w.spawnY+rf.height+math.sin(rf.bob)*0.12
        if rf.timer<=0 then rf.phase="landing" end
      elseif rf.phase=="landing" then
        w.current.y=math.max(w.spawnY,w.current.y-RANDOM_AIR_VERTICAL_SPEED*dt)
        if w.current.y<=w.spawnY+0.02 then
          w.current.y=w.spawnY
          w.randomFlight=nil
          w.flightCooldown=RANDOM_AIR_MIN_GAP+rnd01()*(RANDOM_AIR_MAX_GAP-RANDOM_AIR_MIN_GAP)
        end
      end
    else
      w.current.y=w.spawnY
    end
  end

  local airborne=w.levitating or (w.aerial and w.current.y>w.spawnY+0.20)
  w.actor:setPosition(w.current.x,w.current.y,w.current.z)
  w.actor:setYaw(yaw)
  w.actor:setVisible(false)

  local anim
  if airborne then
    -- Above ground means native flight animation, whether translating
    -- horizontally or briefly hovering in place.
    anim="fly"
  else
    anim=moving and "walk" or "idle"
  end
  if w.lastAnim~=anim then w.actor:setAnimation(anim);w.lastAnim=anim end
  w.actor:update(dt)
end

local function poolCount(kind)
  local n=0
  for _,w in ipairs(wilds) do if w.pool==kind then n=n+1 end end
  return n
end

local function cullFar(ow)
  -- Route-wide population must persist at the far end of a route. Map changes
  -- already clear the population through worldChanged/mapId handling.
  return
end

local encounterLock = false

local function removeWildAt(index)
  local w=wilds[index]
  if not w then return nil end
  destroyWild(w)
  table.remove(wilds,index)
  return w
end

local pendingFinish=nil
local function queueGen2Wild(species,level,onFinish)
  local ow=Game and Game.overworld
  if not (ow and species) or encounterLock then return false end
  encounterLock=true
  pendingFinish=onFinish
  if mod.world and type(mod.world.queueScript)=="function" then
    local ok=pcall(mod.world.queueScript,mod.world,{{"start_battle","wild",species,tonumber(level) or 5}})
    if ok then return true end
  end
  if type(ow.startBattle)=="function" then
    local ok=pcall(ow.startBattle,ow,{wild={species=species,level=tonumber(level) or 5}})
    if ok then return true end
  end
  encounterLock=false; pendingFinish=nil
  return false
end
if mod.events and type(mod.events.on)=="function" then
  mod.events:on("battle.ended",function(ev)
    if encounterLock then
      encounterLock=false
      local cb=pendingFinish; pendingFinish=nil
      if type(cb)=="function" then pcall(cb,ev and (ev.result or ev)) end
    end
  end)
end

local function startVisibleEncounter(ow,w)
  if not (ow and w and w.species) then return false end
  return queueGen2Wild(w.species,w.level,nil)
end

local function startDexEncounter(dex,level,onFinish)
  local species=speciesOfDex(dex)
  if not species then return false end
  return queueGen2Wild(species,level,onFinish)
end

local VISIBLE_TOUCH_RADIUS=10

-- Route wild contact now mirrors WaterEcology's proven lifecycle exactly:
-- the same tracked wild object owns its current world position and dex, and
-- that stored position is what contact checks against before startDexEncounter.
local function touchVisibleWild(world,w)
  local p=world and world.player
  local pos=w and w.current
  if not (p and pos) then return false end
  local px,pz=tonumber(p.x),tonumber(p.z)
  local wx,wz=tonumber(pos.x),tonumber(pos.z)
  if not (px and pz and wx and wz) then return false end
  local dx,dz=wx-px,wz-pz
  return dx*dx+dz*dz<=VISIBLE_TOUCH_RADIUS*VISIBLE_TOUCH_RADIUS
end

local function beginVisibleBattle(w)
  if encounterLock or not w then return false end
  local started=startDexEncounter(w.dex,w.level,nil)
  return started and true or false
end

local function checkVisibleEncounter(ow,world)
  if encounterLock or not (ow and ow.player) then return false end
  for i=#wilds,1,-1 do
    local w=wilds[i]
    local hit=touchVisibleWild(world,w)
    if hit and not w.contact then
      w.contact=true
      if beginVisibleBattle(w) then
        removeWildAt(i)
        return true
      end
    elseif not hit and w then
      w.contact=false
    end
  end
  return false
end

local function drawWild(w)
  if not (w and w.actor and Voxel3D and type(Voxel3D.draw)=="function") then return end
  local actor=w.actor
  local matrix=actor:matrix()
  if type(Voxel3D.seams)=="function" then pcall(Voxel3D.seams,false) end
  if type(Voxel3D.glass)=="function" then pcall(Voxel3D.glass,false) end
  local black=blackTexture()
  if outlineEnabled() and black and love and love.graphics and love.graphics.setDepthMode then
    pcall(love.graphics.setDepthMode,"lequal",false)
    for _,part in ipairs(actor.rig.parts or {}) do
      if part.outlineMesh then pcall(Voxel3D.draw,part.outlineMesh,black,matrix,0,matrix) end
    end
    pcall(love.graphics.setDepthMode,"lequal",true)
  end
  for _,part in ipairs(actor.rig.parts or {}) do
    if part.mesh and part.texture then pcall(Voxel3D.draw,part.mesh,part.texture,matrix,0,matrix) end
  end
  if type(Voxel3D.glass)=="function" then pcall(Voxel3D.glass,true) end
  if type(Voxel3D.seams)=="function" then pcall(Voxel3D.seams,true) end
end

local companion=findDramaless()
if not companion then error("RUMBLE_OVERWORLD_WILDS: COBBLEMONE_GEN2 compatible voxel_companion API unavailable",0) end

local spec={
  api=1,id="rumble.overworld.wilds",name="Cobblemon Overworld Wilds",version="0.1.6",priority=25,
  requires={"render_phases","world_snapshot"},optional={},
  attach=function(_) servicesReady=true end,
  worldChanged=function(_) encounterLock=false;clearWilds();mapId=nil end,
  render={
    opaque_after_terrain=function(context)
      local world=context and context.world
      local ow=Game and Game.overworld
      if not wildsEnabled() then
        if #wilds>0 then clearWilds() end
        return
      end
      if not (servicesReady and world and ow and ow.map) then return end
      local px,pz=playerCell(ow)
      if px==nil or pz==nil then return end
      -- This population is a route feature. GroundEcology continues to own
      -- its separate prey/play events and is left untouched.
      if not routeMap(ow.map) then
        if #wilds>0 then clearWilds() end
        mapId=ow.map.id
        return
      end
      if mapId~=ow.map.id then clearWilds();mapId=ow.map.id end
      local enc=encounterDef(ow.map.id)
      if not grassTable(enc) then
        if #wilds>0 then clearWilds() end
        return
      end
      local dt=(context.frame and context.frame.dt) or 1/60

      -- Touching a visible wild starts a normal engine wild battle against
      -- THAT displayed species/level.
      if checkVisibleEncounter(ow,world) then return end

      cullFar(ow)
      for _,w in ipairs(wilds) do updateWild(w,ow,dt) end

      -- A moving wild can finish onto the trainer's tile this same frame.
      if checkVisibleEncounter(ow,world) then return end

      -- Seed several visible wilds when a valid map first loads instead of
      -- making the player watch the population appear one-by-one. Refills after
      -- despawn/encounter still use the normal staggered delay.
      local grassTarget,outsideTarget=populationTargets(ow.map)
      if needsInitialFill then
        local attempts=0
        local maxAttempts=math.max(INITIAL_SPAWN_ATTEMPTS,(grassTarget+outsideTarget)*12)
        while poolCount("grass")<grassTarget and attempts<maxAttempts do
          spawnOne(ow,world,true,"grass")
          attempts=attempts+1
        end
        attempts=0
        while poolCount("outside")<outsideTarget and attempts<maxAttempts do
          spawnOne(ow,world,true,"outside")
          attempts=attempts+1
        end
        needsInitialFill=false
        spawnClock=SPAWN_DELAY
      else
        spawnClock=spawnClock-dt
        if spawnClock<=0 then
          if poolCount("grass")<grassTarget then
            spawnOne(ow,world,false,"grass")
          elseif poolCount("outside")<outsideTarget then
            spawnOne(ow,world,false,"outside")
          end
          spawnClock=SPAWN_DELAY
        end
      end
      for _,w in ipairs(wilds) do drawWild(w) end
    end,
  },
  invalidate=function() encounterLock=false;clearWilds();mapId=nil end,
  dispose=function()
    clearWilds()
    if BLACK_TEXTURE and BLACK_TEXTURE.release then pcall(BLACK_TEXTURE.release,BLACK_TEXTURE) end
    BLACK_TEXTURE=nil
  end,
}
local handle,err=companion.register(spec)
if not handle then error("RUMBLE_OVERWORLD_WILDS registration failed: "..tostring(err),0) end

local function setCarried(w,x,y,z,yaw)
  if not wildIsAlive(w) then return false end
  w.carried=w.carried or {}
  w.carried.x=tonumber(x) or w.current.x
  w.carried.y=tonumber(y) or w.current.y
  w.carried.z=tonumber(z) or w.current.z
  w.carried.yaw=tonumber(yaw) or 0
  w.carried.stale=0
  w.flee=nil
  w.target,w.targetX,w.targetZ=nil,nil,nil
  return true
end

local function dropAndFlee(w,yaw)
  if not wildIsAlive(w) then return false end
  local c=w.carried
  w.carried=nil
  w.flee=nil
  w.target,w.targetX,w.targetZ=nil,nil,nil
  local floorY=tonumber(w.spawnY) or tonumber(w.y) or 0
  local heading=tonumber(yaw) or (c and tonumber(c.yaw)) or 0
  w.escapeNoEncounter={
    phase="fall",time=0,floorY=floorY,vy=-8,
    vx=math.sin(heading)*8,vz=math.cos(heading)*8,
    yaw=heading,speed=34,
  }
  if w.actor then w.actor:setVisible(true) end
  return true
end

local function consumeWild(w)
  if not w then return false end
  for i=#wilds,1,-1 do
    if wilds[i]==w then
      destroyWild(w)
      table.remove(wilds,i)
      return true
    end
  end
  return false
end

mod.exports.cobblemon_overworld_wilds={
  api=2,version="0.2.2",
  count=function() return #wilds end,
  clear=clearWilds,
  nearestDex=nearestDex,
  isAlive=wildIsAlive,
  beginFlee=beginFlee,
  updateThreat=updateThreat,
  setCarried=setCarried,
  dropAndFlee=dropAndFlee,
  consumeWild=consumeWild,
  startDexEncounter=startDexEncounter,
}
